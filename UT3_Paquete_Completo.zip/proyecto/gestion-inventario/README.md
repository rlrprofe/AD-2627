# Gestión de inventario · Proyecto transversal UT3

Requisitos: **JDK 21**, **Maven**; **MySQL** solamente para el modo JDBC.

## Construcción

```bash
mvn clean package
```

## Modo CSV (predeterminado)

```bash
java -jar target/gestion-inventario-1.0-SNAPSHOT.jar
```

El archivo `datos/productos.csv` se interpreta respecto al directorio de trabajo actual.

## Modo MySQL

1. Ejecuta `sql/inventario.sql` en MySQL.
2. Crea un usuario MySQL con permisos sobre la base `inventario`.
3. Configura variables de entorno locales. En PowerShell:

```powershell
$env:INVENTARIO_STORAGE="mysql"
$env:INVENTARIO_DB_URL="jdbc:mysql://localhost:3306/inventario"
$env:INVENTARIO_DB_USER="inventario_app"
$env:INVENTARIO_DB_PASSWORD="TU_CLAVE_LOCAL"
java -jar target/gestion-inventario-1.0-SNAPSHOT.jar
```

No incluyas contraseñas en el repositorio.

## Pruebas

```bash
mvn test
```

## Limitaciones deliberadas

El CSV simplificado no admite separadores `;` ni saltos de línea dentro de nombres; reescribe el fichero completo, sin protección frente a accesos simultáneos. Se utiliza `double` para el precio por sencillez docente; en una aplicación financiera sería preferible `BigDecimal`.
