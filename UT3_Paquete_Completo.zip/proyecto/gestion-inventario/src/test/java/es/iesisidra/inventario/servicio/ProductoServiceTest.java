package es.iesisidra.inventario.servicio;
import es.iesisidra.inventario.dao.ProductoDAO;
import es.iesisidra.inventario.modelo.Producto;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class ProductoServiceTest {
    static class DaoMemoria implements ProductoDAO {
        private final Map<Integer,Producto> datos=new HashMap<>();
        public void insertar(Producto p){datos.put(p.id(),p);}
        public Optional<Producto> buscarPorId(int id){return Optional.ofNullable(datos.get(id));}
        public List<Producto> listar(){return new ArrayList<>(datos.values());}
        public boolean actualizar(Producto p){if(!datos.containsKey(p.id()))return false;datos.put(p.id(),p);return true;}
        public boolean eliminar(int id){return datos.remove(id)!=null;}
    }
    @Test void altaValida(){ProductoService s=new ProductoService(new DaoMemoria());s.alta(new Producto(1,"Teclado",19.95,12));assertTrue(s.buscar(1).isPresent());}
    @Test void rechazaPrecioNegativo(){ProductoService s=new ProductoService(new DaoMemoria());assertThrows(IllegalArgumentException.class,()->s.alta(new Producto(2,"Raton",-1,3)));}
    @Test void rechazaIdDuplicado(){ProductoService s=new ProductoService(new DaoMemoria());s.alta(new Producto(1,"Teclado",19.95,12));assertThrows(IllegalArgumentException.class,()->s.alta(new Producto(1,"Otro",10,2)));}
}
