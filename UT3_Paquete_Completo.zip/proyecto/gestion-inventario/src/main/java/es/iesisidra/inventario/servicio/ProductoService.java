package es.iesisidra.inventario.servicio;
import es.iesisidra.inventario.dao.ProductoDAO;
import es.iesisidra.inventario.modelo.Producto;
import java.util.List;
import java.util.Optional;
public class ProductoService {
    private final ProductoDAO dao;
    public ProductoService(ProductoDAO dao) { this.dao = dao; }
    public void alta(Producto p) {
        validar(p);
        if (dao.buscarPorId(p.id()).isPresent()) throw new IllegalArgumentException("El ID ya existe");
        dao.insertar(p);
    }
    public Optional<Producto> buscar(int id) { return dao.buscarPorId(id); }
    public List<Producto> listar() { return dao.listar(); }
    public boolean modificar(Producto p) { validar(p); return dao.actualizar(p); }
    public boolean baja(int id) { return dao.eliminar(id); }
    private void validar(Producto p) {
        if (p.id() <= 0 || p.nombre() == null || p.nombre().isBlank() ||
            !Double.isFinite(p.precio()) || p.precio() < 0 || p.stock() < 0)
            throw new IllegalArgumentException("Datos de producto no válidos");
    }
}
