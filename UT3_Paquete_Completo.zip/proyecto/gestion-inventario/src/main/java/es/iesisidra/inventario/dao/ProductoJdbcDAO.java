package es.iesisidra.inventario.dao;
import es.iesisidra.inventario.modelo.Producto;
import es.iesisidra.inventario.util.ConexionBD;
import java.sql.*;
import java.util.*;
public class ProductoJdbcDAO implements ProductoDAO {
    @Override public void insertar(Producto p) {
        String sql = "INSERT INTO producto(id,nombre,precio,stock) VALUES(?,?,?,?)";
        try (Connection c = ConexionBD.abrir(); PreparedStatement ps = c.prepareStatement(sql)) {
            asignar(ps,p); ps.executeUpdate();
        } catch (SQLException e) { throw new IllegalStateException("Error al insertar en MySQL",e); }
    }
    @Override public Optional<Producto> buscarPorId(int id) {
        String sql = "SELECT id,nombre,precio,stock FROM producto WHERE id=?";
        try (Connection c = ConexionBD.abrir(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1,id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? Optional.of(leer(rs)) : Optional.empty(); }
        } catch (SQLException e) { throw new IllegalStateException("Error al buscar en MySQL",e); }
    }
    @Override public List<Producto> listar() {
        String sql = "SELECT id,nombre,precio,stock FROM producto ORDER BY id";
        try (Connection c = ConexionBD.abrir(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<Producto> lista = new ArrayList<>();
            while (rs.next()) lista.add(leer(rs));
            return lista;
        } catch (SQLException e) { throw new IllegalStateException("Error al listar MySQL",e); }
    }
    @Override public boolean actualizar(Producto p) {
        String sql = "UPDATE producto SET nombre=?, precio=?, stock=? WHERE id=?";
        try (Connection c = ConexionBD.abrir(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1,p.nombre()); ps.setDouble(2,p.precio()); ps.setInt(3,p.stock()); ps.setInt(4,p.id());
            return ps.executeUpdate()>0;
        } catch (SQLException e) { throw new IllegalStateException("Error al actualizar MySQL",e); }
    }
    @Override public boolean eliminar(int id) {
        try (Connection c = ConexionBD.abrir(); PreparedStatement ps = c.prepareStatement("DELETE FROM producto WHERE id=?")) {
            ps.setInt(1,id); return ps.executeUpdate()>0;
        } catch (SQLException e) { throw new IllegalStateException("Error al eliminar de MySQL",e); }
    }
    private static void asignar(PreparedStatement ps, Producto p) throws SQLException {
        ps.setInt(1,p.id()); ps.setString(2,p.nombre()); ps.setDouble(3,p.precio()); ps.setInt(4,p.stock());
    }
    private static Producto leer(ResultSet rs) throws SQLException {
        return new Producto(rs.getInt("id"),rs.getString("nombre"),rs.getDouble("precio"),rs.getInt("stock"));
    }
}
