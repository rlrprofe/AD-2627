package es.iesisidra.inventario.dao;
import es.iesisidra.inventario.modelo.Producto;
import java.util.List;
import java.util.Optional;
/** Contrato de persistencia de productos, independiente del soporte. */
public interface ProductoDAO {
    /** Inserta un producto. Lanza una excepción si el identificador ya existe. */
    void insertar(Producto producto);
    /** @return producto encontrado o Optional vacío */
    Optional<Producto> buscarPorId(int id);
    /** @return productos almacenados */
    List<Producto> listar();
    /** @return true si el producto existía y fue actualizado */
    boolean actualizar(Producto producto);
    /** @return true si el producto existía y fue eliminado */
    boolean eliminar(int id);
}
