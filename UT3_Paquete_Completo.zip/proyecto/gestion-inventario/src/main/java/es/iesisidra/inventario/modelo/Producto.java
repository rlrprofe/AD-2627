package es.iesisidra.inventario.modelo;
public record Producto(int id, String nombre, double precio, int stock) { }
