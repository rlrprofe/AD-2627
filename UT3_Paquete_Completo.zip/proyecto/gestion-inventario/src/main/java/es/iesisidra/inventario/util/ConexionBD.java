package es.iesisidra.inventario.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public final class ConexionBD {
    private ConexionBD() { }
    public static Connection abrir() throws SQLException {
        String url = System.getenv().getOrDefault("INVENTARIO_DB_URL", "jdbc:mysql://localhost:3306/inventario");
        String usuario = System.getenv().getOrDefault("INVENTARIO_DB_USER", "inventario_app");
        String clave = System.getenv("INVENTARIO_DB_PASSWORD");
        if (clave == null) throw new IllegalStateException("Falta INVENTARIO_DB_PASSWORD");
        return DriverManager.getConnection(url, usuario, clave);
    }
}
