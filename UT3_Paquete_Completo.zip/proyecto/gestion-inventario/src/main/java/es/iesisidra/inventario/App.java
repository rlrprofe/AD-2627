package es.iesisidra.inventario;
import es.iesisidra.inventario.dao.*;
import es.iesisidra.inventario.modelo.Producto;
import es.iesisidra.inventario.servicio.ProductoService;
import java.nio.file.Path;
import java.util.Scanner;
public class App {
    private static ProductoDAO crearDao() {
        String modo = System.getenv().getOrDefault("INVENTARIO_STORAGE", "csv");
        return switch (modo.toLowerCase()) {
            case "csv" -> new ProductoFicheroDAO(Path.of("datos","productos.csv"));
            case "mysql" -> new ProductoJdbcDAO();
            default -> throw new IllegalArgumentException("Persistencia desconocida: " + modo);
        };
    }
    public static void main(String[] args) {
        ProductoService servicio = new ProductoService(crearDao());
        try (Scanner sc = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n1. Alta  2. Buscar  3. Listar  4. Modificar  5. Eliminar  0. Salir");
                int opcion = entero(sc,"Opción: ");
                if (opcion == 0) break;
                try {
                    switch (opcion) {
                        case 1 -> { servicio.alta(leerProducto(sc)); System.out.println("Producto registrado"); }
                        case 2 -> System.out.println(servicio.buscar(entero(sc,"ID: ")).map(Object::toString).orElse("No encontrado"));
                        case 3 -> servicio.listar().forEach(System.out::println);
                        case 4 -> System.out.println(servicio.modificar(leerProducto(sc)) ? "Modificado" : "No encontrado");
                        case 5 -> System.out.println(servicio.baja(entero(sc,"ID: ")) ? "Eliminado" : "No encontrado");
                        default -> System.out.println("Opción no válida");
                    }
                } catch (IllegalArgumentException | IllegalStateException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }
    private static Producto leerProducto(Scanner sc) {
        int id = entero(sc,"ID: ");
        System.out.print("Nombre: "); String nombre = sc.nextLine();
        double precio = decimal(sc,"Precio (punto decimal): ");
        int stock = entero(sc,"Stock: ");
        return new Producto(id,nombre,precio,stock);
    }
    private static int entero(Scanner sc,String etiqueta) {
        while (true) {
            System.out.print(etiqueta);
            try { return Integer.parseInt(sc.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Introduce un entero válido"); }
        }
    }
    private static double decimal(Scanner sc,String etiqueta) {
        while (true) {
            System.out.print(etiqueta);
            try { return Double.parseDouble(sc.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Introduce un número válido (ej.: 19.95)"); }
        }
    }
}
