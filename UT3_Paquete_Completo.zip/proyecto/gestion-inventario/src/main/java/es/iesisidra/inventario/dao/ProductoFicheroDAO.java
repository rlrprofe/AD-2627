package es.iesisidra.inventario.dao;
import es.iesisidra.inventario.modelo.Producto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
public class ProductoFicheroDAO implements ProductoDAO {
    private final Path ruta;
    public ProductoFicheroDAO(Path ruta) { this.ruta = ruta; }
    @Override public List<Producto> listar() {
        if (!Files.exists(ruta)) return new ArrayList<>();
        try {
            List<Producto> productos = new ArrayList<>();
            for (String linea : Files.readAllLines(ruta, StandardCharsets.UTF_8)) {
                if (linea.isBlank() || linea.equals("id;nombre;precio;stock")) continue;
                String[] c = linea.split(";", -1);
                if (c.length != 4) throw new IllegalStateException("CSV incorrecto: " + linea);
                productos.add(new Producto(Integer.parseInt(c[0]), c[1], Double.parseDouble(c[2]), Integer.parseInt(c[3])));
            }
            return productos;
        } catch (IOException e) { throw new IllegalStateException("Error al leer CSV", e); }
    }
    @Override public Optional<Producto> buscarPorId(int id) {
        return listar().stream().filter(p -> p.id() == id).findFirst();
    }
    @Override public void insertar(Producto p) {
        List<Producto> productos = listar();
        if (productos.stream().anyMatch(x -> x.id() == p.id())) throw new IllegalArgumentException("El ID ya existe");
        productos.add(p);
        guardar(productos);
    }
    @Override public boolean actualizar(Producto p) {
        List<Producto> productos = listar();
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).id() == p.id()) {
                productos.set(i, p); guardar(productos); return true;
            }
        }
        return false;
    }
    @Override public boolean eliminar(int id) {
        List<Producto> productos = listar();
        boolean eliminado = productos.removeIf(p -> p.id() == id);
        if (eliminado) guardar(productos);
        return eliminado;
    }
    private void guardar(List<Producto> productos) {
        try {
            Path carpeta = ruta.toAbsolutePath().getParent();
            if (carpeta != null) Files.createDirectories(carpeta);
            List<String> lineas = new ArrayList<>();
            lineas.add("id;nombre;precio;stock");
            for (Producto p : productos) {
                if (p.nombre().contains(";") || p.nombre().contains("\n") || p.nombre().contains("\r"))
                    throw new IllegalArgumentException("Nombre incompatible con el CSV simplificado");
                lineas.add(p.id() + ";" + p.nombre() + ";" + p.precio() + ";" + p.stock());
            }
            Files.write(ruta, lineas, StandardCharsets.UTF_8);
        } catch (IOException e) { throw new IllegalStateException("Error al guardar CSV", e); }
    }
}
