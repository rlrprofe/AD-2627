CREATE DATABASE IF NOT EXISTS inventario CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventario;
CREATE TABLE IF NOT EXISTS producto (
 id INT PRIMARY KEY,
 nombre VARCHAR(150) NOT NULL,
 precio DOUBLE NOT NULL,
 stock INT NOT NULL
);
INSERT INTO producto (id,nombre,precio,stock) VALUES (1,'Teclado',19.95,12),(2,'Raton',9.50,20)
ON DUPLICATE KEY UPDATE id=id;
