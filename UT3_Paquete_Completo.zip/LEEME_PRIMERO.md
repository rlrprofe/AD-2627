# Actualización de la UT3 de MkDocs

## Sustituir los contenidos

Copia los siete archivos de `docs/ut3/` en la carpeta `docs/ut3/` de tu sitio MkDocs, **sobrescribiendo solo los archivos 01 a 07**.

**No reemplaces** `docs/ut3/index.md`, `docs/ut3/08-actividades-descargas.md` ni `mkdocs.yml`.

## Proyecto Java

El proyecto completo está en `proyecto/gestion-inventario/`. Puedes publicarlo como recurso de descarga en el apartado 3.8 de la UT3, preferiblemente como un ZIP independiente.

## Verificación

Desde la raíz de MkDocs:

```bash
mkdocs build --strict --site-dir C:\Temp\AD-2627-site
```

Desde la raíz del proyecto Java, con JDK 21 y Maven instalados:

```bash
mvn clean package
```

## Nota

La imagen de Maven del anexo no se modifica. La página 3.2 enlaza al anexo ya existente.
