# Instalación en MkDocs

1. Copia los ocho archivos `.md` de `docs/ut3/` a la carpeta `docs/ut3/` de tu sitio. Sustituye los existentes (haz copia de seguridad antes).
2. Copia los dos ZIP de `docs/descargas/ut3/` a esa misma ruta dentro de tu sitio. **No hace falta descomprimirlos dentro de `docs`**.
3. Mantén `docs/ut3/index.md` y `mkdocs.yml` tal como están.
4. Ejecuta `mkdocs build --strict --site-dir C:\Temp\AD-2627-site` y publica después.

Los apartados 3.2 a 3.7 enlazan únicamente al proyecto inicial. El proyecto completo se enlaza al final de 3.8.
