# Demo 1 - Consultas JPQL (MySQL)

Proyecto demo para el bloque **Consultas con HQL/JPQL**.

## Configuración
- MySQL local
- BD: demo_jpa_jpql
- usuario: root
- contraseña: CAMBIAR_PASSWORD

1) Ejecuta `src/main/resources/sql/01_crear_bd.sql`  
2) Ejecuta:

```bash
mvn -q clean compile exec:java
```

## Escenarios incluidos
1. SELECT básico
2. WHERE con parámetro
3. ORDER BY
4. Consulta sobre relación (navegación)
5. Paginación
6. LazyInitializationException (provocar)
7. JOIN FETCH (solución)
