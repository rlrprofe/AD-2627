package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="pedidos")
public class Pedido {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false,length=120)
    private String concepto;

    @Column(nullable=false)
    private Double total;

    @Column(nullable=false)
    private LocalDate fecha;

    @ManyToOne(fetch=FetchType.LAZY) //Define una relación Muchos a Uno.
    @JoinColumn(name="cliente_id", nullable=false, foreignKey=@ForeignKey(name="FK_pedidos_cliente"))
    /*
     * @JoinColumn Esta anotación define cómo se materializa la relación en la base de datos
     * name = "cliente_id" Indica el nombre de la columna de clave foránea en la tabla pedidos.
     * nullable = false Indica que la columna no puede ser NULL.
     * foreignKey = @ForeignKey(name = "FK_pedidos_cliente") Define explícitamente:
            -que la columna es una clave foránea
            -el nombre de la FK en la base de datos
     */
    private Cliente cliente;

    public Pedido() {}
    public Pedido(String concepto, Double total, LocalDate fecha){
        this.concepto=concepto; this.total=total; this.fecha=fecha;
    }

    public void setCliente(Cliente cliente){ this.cliente=cliente; }
    public Long getId(){ return id; }
    public LocalDate getFecha(){ return fecha; }

    @Override public String toString(){
        return "Pedido{id=" + id + ", concepto='" + concepto + "', total=" + total + ", fecha=" + fecha + "}";
    }
}
