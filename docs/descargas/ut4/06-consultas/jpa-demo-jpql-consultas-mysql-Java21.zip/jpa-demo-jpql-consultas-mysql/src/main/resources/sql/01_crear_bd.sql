DROP DATABASE IF EXISTS demo_jpa_jpql;
CREATE DATABASE demo_jpa_jpql CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
