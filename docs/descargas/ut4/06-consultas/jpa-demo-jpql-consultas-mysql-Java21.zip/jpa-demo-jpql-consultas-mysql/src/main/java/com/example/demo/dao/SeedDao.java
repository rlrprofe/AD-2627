package com.example.demo.dao;

import com.example.demo.model.Cliente;
import com.example.demo.model.Pedido;
import com.example.demo.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import java.time.LocalDate;

//Este fichero se encarga de insertar datos de prueba solo si la base de datos está vacía.
public class SeedDao {
    public void seedIfEmpty(){
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try{
            Long count = em.createQuery("SELECT COUNT(c) FROM Cliente c", Long.class).getSingleResult();
            if(count != null && count > 0) return;

            tx.begin();
            Cliente ana = new Cliente("Ana","ana.jpql@demo.es");
            ana.addPedido(new Pedido("Teclado",39.90, LocalDate.now().minusDays(10)));
            ana.addPedido(new Pedido("Ratón",19.90, LocalDate.now().minusDays(8)));

            Cliente luis = new Cliente("Luis","luis.jpql@demo.es");
            luis.addPedido(new Pedido("Monitor",179.00, LocalDate.now().minusDays(20)));

            em.persist(ana); em.persist(luis);
            tx.commit();
        }catch(Exception e){
            if(tx.isActive()) tx.rollback();
            throw e;
        }finally{
            em.close();
        }
    }
}
