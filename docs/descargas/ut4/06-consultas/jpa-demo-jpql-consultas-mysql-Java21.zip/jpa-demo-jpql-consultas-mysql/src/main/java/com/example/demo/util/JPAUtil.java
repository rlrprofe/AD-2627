package com.example.demo.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public final class JPAUtil {
    private static final EntityManagerFactory EMF =
            Persistence.createEntityManagerFactory("demoPU");
    private JPAUtil() {}
    public static EntityManagerFactory getEmf() { return EMF; }
    public static void shutdown() { if (EMF.isOpen()) EMF.close(); }
}
