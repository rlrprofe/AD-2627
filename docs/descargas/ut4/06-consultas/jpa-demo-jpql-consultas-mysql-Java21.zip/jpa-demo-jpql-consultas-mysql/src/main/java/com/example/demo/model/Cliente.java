package com.example.demo.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="clientes", uniqueConstraints=@UniqueConstraint(name="UK_clientes_email", columnNames="email"))
/*
 * La línea anterior especifica:
 *  - Nombre de la tabla concreto 'clientes'
 *  - Restricción a nivel de tabla  en la tabla clientes no se permite que dos filas tengan el mismo valor en la columna email
 *      - Nombre restricción  UK_clientes_email
 *      - la columna email
 */
public class Cliente {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false,length=80)
    private String nombre;

    @Column(nullable=false,length=120)
    private String email;

    // 1-N LAZY para poder demostrar LazyInitializationException + JOIN FETCH
    /*
     * mappedBy = "cliente" (concepto CLAVE)  Indica que este lado NO es el propietario de la relación. cliente es el nombre del atributo en la clase Pedido Ese atributo es el que realmente contiene la clave foránea
     * fetch = FetchType.LAZY Indica que la colección pedidos no se carga automáticamente al cargar un Cliente.
     * cascade = CascadeType.ALL Las operaciones realizadas sobre Cliente se propagan automáticamente a sus Pedido.
     * orphanRemoval = true Indica que si un Pedido deja de estar asociado a su Cliente se elimina de la colección entonces Hibernate lo borra automáticamente de la base de datos.
     */
    @OneToMany(mappedBy="cliente", fetch=FetchType.LAZY, cascade=CascadeType.ALL, orphanRemoval=true)
    private List<Pedido> pedidos = new ArrayList<>();

    public Cliente() {}
    public Cliente(String nombre, String email) { this.nombre=nombre; this.email=email; }

    public void addPedido(Pedido p){ pedidos.add(p); p.setCliente(this); }

    public Long getId(){ return id; }
    public String getNombre(){ return nombre; }
    public String getEmail(){ return email; }
    public List<Pedido> getPedidos(){ return pedidos; }

    @Override public String toString(){
        return "Cliente{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
