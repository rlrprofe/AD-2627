package com.example.demo;

import com.example.demo.dao.SeedDao;
import com.example.demo.model.Cliente;
import com.example.demo.model.Pedido;
import com.example.demo.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

//Fichero con consultas de prueba modularizadas en distintos métodos
public class DemoConsultasJPQL {

    public static void main(String[] args) {
        System.out.println("=== DEMO JPQL: consultas progresivas (MySQL) ===");
        new SeedDao().seedIfEmpty();

        escenario1_selectBasico();
        escenario2_whereParametro();
        escenario3_orderBy();
        escenario4_relacion();
        escenario5_paginacion();
        escenario6_lazyException();
        escenario7_joinFetch();

        JPAUtil.shutdown();
        System.out.println("\nFin.");
    }

    private static void escenario1_selectBasico() {
        System.out.println("\n--- 1) SELECT c FROM Cliente c ---");
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            List<Cliente> clientes = em.createQuery("SELECT c FROM Cliente c", Cliente.class).getResultList();
            for (Cliente c : clientes) {
                System.out.println(c);
            }

        } finally {
            em.close();
        }
    }

    private static void escenario2_whereParametro() {
        System.out.println("\n--- 2) WHERE con parámetro ---");
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            List<Cliente> clientes = em.createQuery(
                    "SELECT c FROM Cliente c WHERE c.nombre = :nombre", Cliente.class)
                    .setParameter("nombre", "Ana")
                    .getResultList();
            for (Cliente c : clientes) {
                System.out.println(c);
            }

        } finally {
            em.close();
        }
    }

    private static void escenario3_orderBy() {
        System.out.println("\n--- 3) ORDER BY ---");
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            List<Cliente> clientes = em.createQuery(
                    "SELECT c FROM Cliente c ORDER BY c.nombre ASC", Cliente.class)
                    .getResultList();
            for (Cliente c : clientes) {
                System.out.println(c);
            }

        } finally {
            em.close();
        }
    }

    private static void escenario4_relacion() {
        System.out.println("\n--- 4) Relación: pedidos de un cliente ---");
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            Long idCliente = em.createQuery("SELECT c.id FROM Cliente c ORDER BY c.id", Long.class)
                    .setMaxResults(1).getSingleResult();

            List<Pedido> pedidos = em.createQuery(
                    "SELECT p FROM Pedido p WHERE p.cliente.id = :id ORDER BY p.fecha DESC", Pedido.class)
                    .setParameter("id", idCliente)
                    .getResultList();

            // pedidos.forEach(System.out::println);
            for (Pedido p : pedidos) {
                System.out.println(p);
            }

        } finally {
            em.close();
        }
    }

    private static void escenario5_paginacion() {
        System.out.println("\n--- 5) Paginación (setFirstResult/setMaxResults) ---");
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Cliente> q = em.createQuery("SELECT c FROM Cliente c ORDER BY c.id", Cliente.class);
            List<Cliente> pagina1 = q.setFirstResult(0).setMaxResults(1).getResultList();
            System.out.println("Página 1:");
            pagina1.forEach(System.out::println);

            List<Cliente> pagina2 = em.createQuery("SELECT c FROM Cliente c ORDER BY c.id", Cliente.class)
                    .setFirstResult(1).setMaxResults(1).getResultList();
            System.out.println("Página 2:");
            pagina2.forEach(System.out::println);
        } finally {
            em.close();
        }
    }

    private static void escenario6_lazyException() {
        System.out.println("\n--- 6) LazyInitializationException (provocar) ---");

        Cliente c;
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            c = em.createQuery("SELECT c FROM Cliente c ORDER BY c.id", Cliente.class)
                    .setMaxResults(1).getSingleResult();
            System.out.println("Cliente managed: " + c);
            // NO tocamos c.getPedidos() aquí.
        } finally {
            em.close();
        }

        System.out.println("EM cerrado -> Cliente detached. Accedemos a pedidos LAZY...");
        try {
            System.out.println("Pedidos: " + c.getPedidos().size());
        } catch (Exception ex) {
            System.out.println("EXCEPCIÓN esperada: " + ex.getClass().getSimpleName());
        }
    }

    private static void escenario7_joinFetch() {
        System.out.println("\n--- 7) JOIN FETCH (solución) ---");

        Cliente c;
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            c = em.createQuery(
                    "SELECT DISTINCT c FROM Cliente c LEFT JOIN FETCH c.pedidos ORDER BY c.id", Cliente.class)
                    .setMaxResults(1).getSingleResult();
            System.out.println("Dentro del EM, pedidos: " + c.getPedidos().size());
        } finally {
            em.close();
        }

        // EM cerrado, pero la colección ya está inicializada
        System.out.println("EM cerrado, pedidos: " + c.getPedidos().size());
    }
}
