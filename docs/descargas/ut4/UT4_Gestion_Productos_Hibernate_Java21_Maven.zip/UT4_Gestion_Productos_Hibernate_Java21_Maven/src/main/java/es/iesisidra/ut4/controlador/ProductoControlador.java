package es.iesisidra.ut4.controlador;
import es.iesisidra.ut4.servicio.ProductoService;
import es.iesisidra.ut4.vista.ConsolaVista;
public final class ProductoControlador {
    private final ConsolaVista vista;private final ProductoService servicio;
    public ProductoControlador(ConsolaVista vista,ProductoService servicio){this.vista=vista;this.servicio=servicio;}
    public void iniciar(){boolean seguir=true;while(seguir){try{seguir=ejecutar(vista.menu());}catch(RuntimeException e){vista.error(e.getMessage());}}}
    private boolean ejecutar(int opcion){switch(opcion){case 0-> {return false;}case 1->alta();case 2->buscar();case 3->listar();case 4->modificar();case 5->eliminar();case 6->filtrar();case 7->vista.mensaje("Total: "+servicio.contar());default->vista.error("Opción incorrecta");}return true;}
    private String nombre(){return vista.texto("Nombre: ");}
    private double precio(){return vista.decimal("Precio: ");}
    private int stock(){return vista.entero("Stock: ");}
    private void alta(){vista.mostrar(servicio.alta(nombre(),precio(),stock()));}
    private void buscar(){servicio.buscar(vista.id()).ifPresentOrElse(vista::mostrar,()->vista.mensaje("No encontrado"));}
    private void listar(){servicio.listar().forEach(vista::mostrar);}
    private void modificar(){long id=vista.id();vista.mensaje(servicio.modificar(id,nombre(),precio(),stock())?"Modificado":"No encontrado");}
    private void eliminar(){vista.mensaje(servicio.eliminar(vista.id())?"Eliminado":"No encontrado");}
    private void filtrar(){servicio.filtrar(vista.decimal("Precio mínimo: ")).forEach(vista::mostrar);}
}
