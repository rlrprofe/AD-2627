package es.iesisidra.ut4;
import es.iesisidra.ut4.config.JpaUtil;
import es.iesisidra.ut4.dao.ProductoJpaDAO;
import es.iesisidra.ut4.servicio.ProductoService;
import es.iesisidra.ut4.vista.ConsolaVista;
import es.iesisidra.ut4.controlador.ProductoControlador;
import java.util.Scanner;
public final class App {
    private App(){}
    public static void main(String[] args){
        try(JpaUtil jpa=new JpaUtil();Scanner sc=new Scanner(System.in)){
            new ProductoControlador(new ConsolaVista(sc),new ProductoService(new ProductoJpaDAO(jpa))).iniciar();
        }catch(RuntimeException e){System.err.println("No se pudo iniciar la aplicación: "+e.getMessage());}
    }
}
