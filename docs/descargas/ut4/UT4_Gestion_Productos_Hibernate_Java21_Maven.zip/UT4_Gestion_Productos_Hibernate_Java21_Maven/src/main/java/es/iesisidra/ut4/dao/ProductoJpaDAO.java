package es.iesisidra.ut4.dao;
import es.iesisidra.ut4.config.JpaUtil;
import es.iesisidra.ut4.modelo.Producto;
import jakarta.persistence.*;
import java.util.*;
import java.util.function.Function;
public final class ProductoJpaDAO implements ProductoDAO {
    private final JpaUtil jpa;
    public ProductoJpaDAO(JpaUtil jpa){this.jpa=jpa;}
    private <T> T consultar(Function<EntityManager,T> accion){
        EntityManager em=jpa.abrir();
        try{return accion.apply(em);}finally{em.close();}
    }
    private <T> T transaccion(Function<EntityManager,T> accion){
        EntityManager em=jpa.abrir();
        EntityTransaction tx=em.getTransaction();
        try{tx.begin();T resultado=accion.apply(em);tx.commit();return resultado;}
        catch(RuntimeException e){if(tx.isActive())tx.rollback();throw e;}
        finally{em.close();}
    }
    @Override public Producto crear(Producto p){return transaccion(em->{em.persist(p);return p;});}
    @Override public Optional<Producto> buscar(long id){return consultar(em->Optional.ofNullable(em.find(Producto.class,id)));}
    @Override public List<Producto> listar(){return consultar(em->em.createQuery("SELECT p FROM Producto p ORDER BY p.id",Producto.class).getResultList());}
    @Override public List<Producto> buscarPorPrecioMinimo(double minimo){return consultar(em->em.createQuery("SELECT p FROM Producto p WHERE p.precio >= :minimo ORDER BY p.precio",Producto.class).setParameter("minimo",minimo).getResultList());}
    @Override public boolean modificar(long id,String nombre,double precio,int stock){return transaccion(em->{Producto p=em.find(Producto.class,id);if(p==null)return false;p.setNombre(nombre);p.setPrecio(precio);p.setStock(stock);return true;});}
    @Override public boolean eliminar(long id){return transaccion(em->{Producto p=em.find(Producto.class,id);if(p==null)return false;em.remove(p);return true;});}
    @Override public long contarConSqlNativo(){return consultar(em->((Number)em.createNativeQuery("SELECT COUNT(*) FROM productos").getSingleResult()).longValue());}
}
