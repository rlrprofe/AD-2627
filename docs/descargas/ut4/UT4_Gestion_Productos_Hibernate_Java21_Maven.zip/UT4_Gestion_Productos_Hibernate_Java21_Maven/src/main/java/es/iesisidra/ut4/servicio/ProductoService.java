package es.iesisidra.ut4.servicio;
import es.iesisidra.ut4.dao.ProductoDAO;
import es.iesisidra.ut4.modelo.Producto;
import java.util.*;
public final class ProductoService {
    private final ProductoDAO dao;
    public ProductoService(ProductoDAO dao){this.dao=dao;}
    public Producto alta(String nombre,double precio,int stock){validar(nombre,precio,stock);return dao.crear(new Producto(nombre,precio,stock));}
    public Optional<Producto> buscar(long id){return dao.buscar(id);}
    public List<Producto> listar(){return dao.listar();}
    public List<Producto> filtrar(double minimo){if(minimo<0)throw new IllegalArgumentException("Precio mínimo negativo");return dao.buscarPorPrecioMinimo(minimo);}
    public boolean modificar(long id,String nombre,double precio,int stock){validar(nombre,precio,stock);return dao.modificar(id,nombre,precio,stock);}
    public boolean eliminar(long id){return dao.eliminar(id);}
    public long contar(){return dao.contarConSqlNativo();}
    private void validar(String nombre,double precio,int stock){if(nombre==null||nombre.isBlank()||!Double.isFinite(precio)||precio<0||stock<0)throw new IllegalArgumentException("Datos de producto no válidos");}
}
