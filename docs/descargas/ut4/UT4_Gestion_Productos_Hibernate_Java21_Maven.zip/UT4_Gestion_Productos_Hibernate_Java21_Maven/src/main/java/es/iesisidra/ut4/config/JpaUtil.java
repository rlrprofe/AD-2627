package es.iesisidra.ut4.config;
import jakarta.persistence.*;
public final class JpaUtil implements AutoCloseable {
    private final EntityManagerFactory fabrica;
    public JpaUtil(){fabrica=Persistence.createEntityManagerFactory("inventarioPU",ConfiguracionBD.cargar());}
    public EntityManager abrir(){return fabrica.createEntityManager();}
    @Override public void close(){fabrica.close();}
}
