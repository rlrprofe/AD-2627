package es.iesisidra.ut4.config;
import java.io.*;import java.nio.file.*;import java.util.*;
public final class ConfiguracionBD {
    private ConfiguracionBD(){}
    public static Map<String,Object> cargar(){
        Path ruta=Path.of("config","bd.properties");
        Properties p=new Properties();
        try(InputStream in=Files.newInputStream(ruta)){p.load(in);}
        catch(IOException e){throw new IllegalStateException("No se puede leer "+ruta+". Copia bd.properties.example",e);}
        Map<String,Object> m=new HashMap<>();
        m.put("jakarta.persistence.jdbc.driver","com.mysql.cj.jdbc.Driver");
        m.put("jakarta.persistence.jdbc.url",obligatoria(p,"db.url"));
        m.put("jakarta.persistence.jdbc.user",obligatoria(p,"db.usuario"));
        m.put("jakarta.persistence.jdbc.password",obligatoria(p,"db.password"));
        return m;
    }
    private static String obligatoria(Properties p,String k){String v=p.getProperty(k,"").trim();if(v.isEmpty())throw new IllegalStateException("Falta propiedad: "+k);return v;}
}
