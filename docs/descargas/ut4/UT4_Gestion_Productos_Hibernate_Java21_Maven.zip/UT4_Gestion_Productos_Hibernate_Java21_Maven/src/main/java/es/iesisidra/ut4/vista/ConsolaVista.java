package es.iesisidra.ut4.vista;
import es.iesisidra.ut4.modelo.Producto;
import java.util.*;
public final class ConsolaVista {
    private final Scanner sc;
    public ConsolaVista(Scanner sc){this.sc=sc;}
    public int menu(){System.out.println("\n1 Alta | 2 Buscar | 3 Listar | 4 Modificar | 5 Eliminar | 6 Filtrar | 7 Contar (SQL) | 0 Salir");return entero("Opción: ");}
    public String texto(String pregunta){System.out.print(pregunta);return sc.nextLine().trim();}
    public int entero(String pregunta){while(true){try{return Integer.parseInt(texto(pregunta));}catch(NumberFormatException e){error("Escribe un entero.");}}}
    public long id(){while(true){try{return Long.parseLong(texto("ID: "));}catch(NumberFormatException e){error("ID no válido.");}}}
    public double decimal(String pregunta){while(true){try{return Double.parseDouble(texto(pregunta));}catch(NumberFormatException e){error("Escribe un decimal con punto.");}}}
    public void mostrar(Producto p){System.out.printf("%d | %s | %.2f | stock %d%n",p.getId(),p.getNombre(),p.getPrecio(),p.getStock());}
    public void mensaje(String s){System.out.println(s);}
    public void error(String s){System.err.println("Error: "+s);}
}
