package es.iesisidra.ut4.dao;
import es.iesisidra.ut4.modelo.Producto;
import java.util.*;
public interface ProductoDAO {
    Producto crear(Producto producto);
    Optional<Producto> buscar(long id);
    List<Producto> listar();
    List<Producto> buscarPorPrecioMinimo(double minimo);
    boolean modificar(long id,String nombre,double precio,int stock);
    boolean eliminar(long id);
    long contarConSqlNativo();
}
