# UT4 — Gestión de productos con Hibernate/JPA (Java 21)

Ejemplo didáctico de **MVC + servicio + DAO ORM**, con Maven, MySQL, Hibernate como proveedor JPA y configuración externa.

## Requisitos

- JDK 21, Maven y servidor MySQL.
- Ejecutar `sql/01_esquema.sql` en MySQL.
- Crear un usuario MySQL con permisos sobre `ut4_inventario`.
- Copiar `config/bd.properties.example` a `config/bd.properties` y editar URL, usuario y contraseña. No subir el fichero privado.
- Abrir una terminal **en la raíz del proyecto**.

```bash
mvn clean compile
mvn exec:java
```

La tabla se valida al arrancar (`hibernate.hbm2ddl.auto=validate`); el proyecto no destruye ni crea automáticamente el esquema.

## Organización

- `modelo`: entidad persistente `Producto`.
- `dao`: contrato `ProductoDAO` e implementación `ProductoJpaDAO`.
- `servicio`: reglas de negocio.
- `vista`: entrada/salida de consola.
- `controlador`: coordinación de opciones.
- `config`: carga del fichero de propiedades y gestión de la fábrica de entidades.
- `App`: ensamblaje de dependencias.

## Criterios trabajados

RA3 a–g (incluida una consulta SQL nativa en `contarConSqlNativo`) y RA6.e (componente DAO ORM).

## Precauciones

- El precio se representa con `double` para simplificar el ejemplo; en aplicaciones económicas reales conviene `BigDecimal`.
- La vista utiliza `Scanner`; el cierre del `EntityManager` se realiza en `finally` y la fábrica se cierra al salir.
- Se requiere MySQL real para ejecutar el programa. Este proyecto no incluye pruebas de integración automáticas ni una base de datos embebida.
