CREATE DATABASE IF NOT EXISTS ut4_inventario CHARACTER SET utf8mb4;
USE ut4_inventario;
CREATE TABLE IF NOT EXISTS productos (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  precio DOUBLE NOT NULL,
  stock INT NOT NULL
);
-- Crea un usuario con permisos limitados desde la administración de MySQL.
