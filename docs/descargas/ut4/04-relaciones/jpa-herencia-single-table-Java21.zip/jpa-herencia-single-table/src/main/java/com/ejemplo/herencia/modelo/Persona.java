/**
 * Clase base de la jerarquía de herencia.
 *
 * Esta clase representa el concepto general de Persona y será la
 * superclase de las entidades especializadas (Alumno, Profesor, etc.).
 *
 * En este ejemplo se utiliza la estrategia de herencia SINGLE_TABLE:
 * - Toda la jerarquía se almacena en una única tabla de base de datos.
 * - Hibernate decide qué subclase instanciar usando una columna
 *   discriminadora.
 */
package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;
/*
 * Indica la estrategia de herencia.
 *
 * SINGLE_TABLE significa que:
 * - Habrá una sola tabla para Persona, Alumno y Profesor.
 * - Los atributos específicos de las subclases se añaden como columnas
 *   adicionales (que pueden quedar a NULL).
 */

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)

/*
 * Define la columna discriminadora.
 *
 * Esta columna:
 * - Se añade a la tabla única.
 * - Indica el tipo real del objeto almacenado.
 * - Hibernate la usa para saber si una fila corresponde a un Alumno,
 * un Profesor u otra subclase.
 *
 * El valor concreto de esta columna se define en cada subclase mediante
 * 
 * @DiscriminatorValue.
 */
@DiscriminatorColumn(name = "tipo")
public abstract class Persona {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Clave primaria de la entidad. Es común a toda la jerarquía.
                                                        // Se genera automáticamente.En SINGLE_TABLE, esta columna
                                                        // identifica a cualquier tipo de Persona.
    protected Long id;

    protected String nombre; // Atributo común a todas las personas.Se almacena en la tabla única. Está
                             // presente tanto para Alumno como para Profesor.

    public Persona() { //Constructor por defecto obligatorio para JPA.
    }

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }
}
