package com.ejemplo.herencia.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Utilidad para crear y reutilizar la EntityManagerFactory.
 *
 * - La EntityManagerFactory se crea una sola vez.
 * - Abrir/cerrar la EMF es costoso.
 * - Se centraliza aquí siguiendo buenas prácticas.
 */
public final class JPAUtil {

    private static EntityManagerFactory emf;

    private JPAUtil() {
        // Evita instancias
    }

    public static EntityManagerFactory getEmf() {
        if (emf == null) {
            emf = Persistence.createEntityManagerFactory("demoPU");
        }
        return emf;
    }

    public static void close() {
        if (emf != null) {
            emf.close();
            emf = null;
        }
    }
}
