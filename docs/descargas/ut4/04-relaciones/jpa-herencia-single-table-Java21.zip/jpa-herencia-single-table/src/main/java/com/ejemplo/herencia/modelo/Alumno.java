/**
 * Clase Alumno.
 *
 * Representa una especialización de la clase Persona.
 * Un Alumno:
 * - ES una Persona (relación de herencia).
 * - Comparte los atributos comunes definidos en Persona.
 * - Añade atributos propios específicos del alumnado.
 *
 * En la estrategia SINGLE_TABLE:
 * - No existe una tabla "alumno".
 * - Los datos del alumno se almacenan en la misma tabla que Persona.
 */
package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;
/*
 * @Entity indica que esta clase forma parte del modelo persistente.
 *
 * Aunque no tenga tabla propia, Hibernate la gestiona como una entidad
 * y la diferencia del resto de subclases mediante el discriminador.
 */
@Entity


/*
 * Valor del discriminador asociado a esta subclase.
 *
 * - Este valor se almacenará en la columna "tipo" de la tabla única.
 * - Cuando Hibernate encuentre una fila con tipo = 'ALUMNO',
 *   creará una instancia de la clase Alumno.
 */
@DiscriminatorValue("ALUMNO")
public class Alumno extends Persona {

    private String curso;    //Atributo específico del Alumno. Solo tiene sentido para los alumnos.
                            //En la tabla única aparecerá como una columna adicional.
                            //Para filas que representen a un Profesor, este valor será NULL.

    public Alumno() {} //Constructor vacíos

    public Alumno(String nombre, String curso) {
        super(nombre);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }
}
