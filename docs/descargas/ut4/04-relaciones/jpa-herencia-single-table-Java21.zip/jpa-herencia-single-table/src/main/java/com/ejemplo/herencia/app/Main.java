/**
 * Clase principal de la aplicación de demostración.
 *
 * Este ejemplo muestra:
 * - Cómo obtener un EntityManager usando una clase utilitaria (JPAUtil).
 * - Cómo persistir entidades con herencia (SINGLE_TABLE).
 * - Cómo trabajar de forma polimórfica con una jerarquía de clases.
 *
 */
package com.ejemplo.herencia.app;

import com.ejemplo.herencia.modelo.*;
import com.ejemplo.herencia.util.JPAUtil;
import jakarta.persistence.EntityManager;

public class Main {

    public static void main(String[] args) {

        EntityManager em = JPAUtil.getEmf().createEntityManager();

        em.getTransaction().begin();

        /*
         * Creamos objetos utilizando referencias del tipo Persona.
         *
         * Esto demuestra el polimorfismo:
         * - a1 es un Alumno
         * - p1 es un Profesor
         * pero ambos se manejan como Persona.
         */

        Persona a1 = new Alumno("Ana", "2 DAM");
        Persona p1 = new Profesor("Luis", "Informática");


        /*
         * Persistimos los objetos.
         *
         * Hibernate:
         * - Inserta ambas filas en la misma tabla (SINGLE_TABLE).
         * - Rellena la columna discriminadora "tipo" con:
         *   - 'ALUMNO' para Ana
         *   - 'PROFESOR' para Luis
         */
        em.persist(a1);
        em.persist(p1);

        /*
         * Confirmamos la transacción.
         *
         * En este momento:
         * - Se ejecutan los INSERT en la base de datos.
         * - Las entidades pasan a estado MANAGED.
         */



        em.getTransaction().commit();
        /*
         * Cerramos el EntityManager.
         *
         * A partir de este momento:
         * - Las entidades pasan a estado DETACHED.
         * - No se pueden realizar operaciones lazy.
         */
        em.close();


        /*
         * Cerramos la EntityManagerFactory.
         *
         * En aplicaciones reales:
         * - Esto se haría al finalizar la aplicación.
         * - Nunca dentro de un bucle.
         */
        JPAUtil.close();
    }
}
