/**
 * Clase Profesor.
 *
 * Representa una especialización de la clase Persona.
 * Un Profesor:
 * - ES una Persona (hereda de Persona).
 * - Comparte los atributos comunes.
 * - Incorpora atributos propios relacionados con su rol.
 *
 * En la estrategia SINGLE_TABLE:
 * - No existe una tabla independiente para Profesor.
 * - Sus datos se almacenan en la misma tabla que los de Persona y Alumno.
 */

package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;

/*
 * @Entity indica que esta clase forma parte del modelo persistente.
 *
 * Aunque no tenga una tabla propia, Hibernate la trata como una entidad
 * completa gracias a la estrategia de herencia definida en la clase base.
 */
@Entity

/*
 * Valor del discriminador asociado a esta subclase.
 *
 * - Este valor se guarda en la columna "tipo" de la tabla única.
 * - Cuando Hibernate encuentra una fila con tipo = 'PROFESOR',
 *   crea una instancia de la clase Profesor.
 */
@DiscriminatorValue("PROFESOR")
public class Profesor extends Persona {

    private String departamento; //Atributo específico del Profesor.
                                //Solo tiene sentido para profesores.Se añade como una columna más en la tabla única.Para filas que representen a alumnos, este valor será NULL.

    public Profesor() {} //constructor vacío

    public Profesor(String nombre, String departamento) {
        super(nombre);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }
}
