CREATE DATABASE IF NOT EXISTS herencia_demo;
USE herencia_demo;

CREATE TABLE persona (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    curso VARCHAR(50),
    departamento VARCHAR(50),
    tipo VARCHAR(20) NOT NULL
);
