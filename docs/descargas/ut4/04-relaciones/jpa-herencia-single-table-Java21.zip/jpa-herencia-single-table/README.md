# Proyecto Demo JPA - Herencia SINGLE_TABLE

## Descripción
Proyecto Maven de demostración para explicar la **relación de generalización/especialización**
(herencia) en JPA/Hibernate utilizando la estrategia **SINGLE_TABLE**.

Incluye:
- Herencia JPA
- Uso de discriminador
- Centralización de EntityManagerFactory con JPAUtil
- Base de datos MySQL

---

## Diagrama de clases (modelo de dominio)

El siguiente diagrama representa visualmente la jerarquía de herencia utilizada
en el proyecto.



    Persona <|-- Alumno
    Persona <|-- Profesor

    class Persona {
        Long id
        String nombre
    }

    class Alumno {
        String curso
    }

    class Profesor {
        String departamento
    }


> **Nota:** Aunque existen tres clases Java, en la estrategia SINGLE_TABLE
> toda la jerarquía se almacena en **una única tabla** en la base de datos.

---

## Estrategia de herencia usada

- `@Inheritance(strategy = InheritanceType.SINGLE_TABLE)`
- `@DiscriminatorColumn(name = "tipo")`
- `@DiscriminatorValue("ALUMNO")`
- `@DiscriminatorValue("PROFESOR")`

Hibernate utiliza la columna `tipo` para decidir qué subclase instanciar.


## Tecnologías

- Java 17
- Maven
- JPA (Jakarta Persistence)
- Hibernate ORM
- MySQL 8

---

## Base de datos

- Base de datos: `herencia_demo`
- Usuario: `admin`
- Contraseña: `CAMBIAR_PASSWORD`

Script SQL:
```
src/main/resources/sql/schema.sql
```

---

## Ejecución

1. Ejecutar el script SQL en MySQL
2. Abrir el proyecto en el IDE
3. Ejecutar `Main.java`
4. Analizar la tabla `persona` y el valor del discriminador

---

## Objetivo didáctico

- Comprender la herencia en ORM
- Analizar la estrategia SINGLE_TABLE
- Visualizar el polimorfismo en JPA
- Aplicar buenas prácticas con `JPAUtil`
