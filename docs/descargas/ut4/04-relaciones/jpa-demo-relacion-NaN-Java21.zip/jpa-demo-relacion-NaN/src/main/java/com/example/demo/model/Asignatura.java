package com.example.demo.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Entidad Asignatura.
 *
 * Este lado es la PARTE INVERSA de la relación N-N.
 * Por eso usamos mappedBy, indicando el nombre del atributo en Alumno que define la relación.
 */
@Entity
@Table(name = "asignaturas")
public class Asignatura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 60)
    private String nombre;

    /**
     * Parte inversa:
     * - mappedBy = "asignaturas" apunta al atributo Set<Asignatura> en Alumno.
     * - Aquí NO se define @JoinTable: la join table la define el propietario (Alumno).
     */
    @ManyToMany(mappedBy = "asignaturas", fetch = FetchType.LAZY)
    private Set<Alumno> alumnos = new HashSet<>();

    public Asignatura() {}

    public Asignatura(String nombre) {
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Set<Alumno> getAlumnos() {
        return alumnos;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // equals/hashCode: para Sets, igual que en Alumno.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Asignatura)) return false;
        Asignatura that = (Asignatura) o;
        if (id != null && that.id != null) return Objects.equals(id, that.id);
        return Objects.equals(nombre, that.nombre);
    }

    @Override
    public int hashCode() {
        return id != null ? Objects.hash(id) : Objects.hash(nombre);
    }

    @Override
    public String toString() {
        return "Asignatura{id=" + id + ", nombre='" + nombre + "'}";
    }
}
