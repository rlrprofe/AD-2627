package com.example.demo.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Entidad Alumno.
 *
 * RELACIÓN N-N:
 * - Un Alumno puede estar matriculado en varias Asignaturas.
 * - Una Asignatura puede tener varios Alumnos.
 *
 * En JPA, una relación N-N se implementa mediante una TABLA INTERMEDIA (join table).
 * En este ejemplo, el lado propietario será Alumno (aquí definimos @JoinTable).
 */
@Entity
@Table(name = "alumnos")
public class Alumno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String nombre;

    /**
     * Relación MUCHOS A MUCHOS.
     *
     * Este lado ES EL PROPIETARIO porque define la tabla intermedia con @JoinTable.
     *
     * @JoinTable:
     * - name: nombre de la tabla intermedia.
     * - joinColumns: columna FK en la join table que apunta a Alumno.
     * - inverseJoinColumns: columna FK en la join table que apunta a Asignatura.
     *
     * fetch:
     * - ManyToMany es LAZY por defecto; lo dejamos así para que el alumnado
     *   vea el comportamiento típico (y conecte con LazyInitializationException).
     *
     * cascade:
     * - En N-N hay que ser prudente con REMOVE, porque podrías borrar asignaturas
     *   compartidas por otros alumnos.
     * - Para una demo sencilla, usamos PERSIST y MERGE (guardar y actualizar).
     */
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "alumnos_asignaturas",
            joinColumns = @JoinColumn(name = "alumno_id"),
            inverseJoinColumns = @JoinColumn(name = "asignatura_id")
    )
    private Set<Asignatura> asignaturas = new HashSet<>();

    public Alumno() {}

    public Alumno(String nombre) {
        this.nombre = nombre;
    }

    // Métodos de ayuda (MUY recomendables) para mantener consistencia en ambos lados.
    public void addAsignatura(Asignatura a) {
        asignaturas.add(a);
        a.getAlumnos().add(this);
    }

    public void removeAsignatura(Asignatura a) {
        asignaturas.remove(a);
        a.getAlumnos().remove(this);
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Set<Asignatura> getAsignaturas() {
        return asignaturas;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // equals/hashCode: importante para Sets. Usamos id si existe, si no, identidad lógica por nombre.
    // En demos educativas es suficiente; en producción se define cuidadosamente.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Alumno)) return false;
        Alumno alumno = (Alumno) o;
        if (id != null && alumno.id != null) return Objects.equals(id, alumno.id);
        return Objects.equals(nombre, alumno.nombre);
    }

    @Override
    public int hashCode() {
        return id != null ? Objects.hash(id) : Objects.hash(nombre);
    }

    @Override
    public String toString() {
        return "Alumno{id=" + id + ", nombre='" + nombre + "'}";
    }
}
