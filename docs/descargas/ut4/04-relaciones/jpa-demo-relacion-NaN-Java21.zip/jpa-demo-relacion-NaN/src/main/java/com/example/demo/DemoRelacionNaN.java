package com.example.demo;

import com.example.demo.model.Alumno;
import com.example.demo.model.Asignatura;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * DEMO: Relación Muchos a Muchos (N-N) con JPA/Hibernate.
 *
 * Objetivos didácticos:
 * 1) Ver cómo se guarda una relación N-N (tabla intermedia).
 * 2) Entender "propietario" (join table) vs "inverso" (mappedBy).
 * 3) Aprender a mantener consistencia en ambos lados (métodos add/remove).
 * 4) Ver cómo se elimina una relación (sin borrar entidades).
 */
public class DemoRelacionNaN {

    public static void main(String[] args) {
        System.out.println("=== DEMO N-N: Alumno <-> Asignatura ===");

        Long anaId = crearDatosIniciales();
        mostrarAlumnoConAsignaturas(anaId);
        romperRelacion(anaId);
        mostrarAlumnoConAsignaturas(anaId);
        borrarAlumno(anaId);

        JPAUtil.close();
        System.out.println("\nFin de la demo.");
    }

    /**
     * Crea asignaturas y alumnos y establece la relación N-N.
     * Devuelve el id de un alumno para seguir con la demo.
     */
    private static Long crearDatosIniciales() {
        System.out.println("\n[1] Crear datos y asociar (N-N) usando tabla intermedia");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        tx.begin();

        // Asignaturas (en N-N NO conviene cascada REMOVE: pueden ser compartidas)
        Asignatura prog = new Asignatura("Programación");
        Asignatura bd = new Asignatura("Bases de Datos");
        Asignatura ad = new Asignatura("Acceso a Datos");

        // Alumnos
        Alumno ana = new Alumno("Ana");
        Alumno luis = new Alumno("Luis");

        // Mantener consistencia en ambos lados:
        // addAsignatura añade en ana.asignaturas y también en asignatura.alumnos
        ana.addAsignatura(prog);
        ana.addAsignatura(ad);

        luis.addAsignatura(prog);
        luis.addAsignatura(bd);

        // Persistimos:
        // - Como en Alumno hay cascade PERSIST hacia Asignatura,
        //   al persistir alumnos se persisten asignaturas (si aún no existían).
        // - La tabla intermedia se rellenará automáticamente.
        em.persist(ana);
        em.persist(luis);

        tx.commit();
        em.close();

        System.out.println("Datos creados. Ana id = " + ana.getId());
        return ana.getId();
    }

    /**
     * Muestra un alumno y sus asignaturas (requiere EM abierto porque es LAZY).
     */
    private static void mostrarAlumnoConAsignaturas(Long alumnoId) {
        System.out.println("\n[2] Cargar Alumno y mostrar sus asignaturas (LAZY con EM abierto)");

        EntityManager em = JPAUtil.getEmf().createEntityManager();

        Alumno a = em.find(Alumno.class, alumnoId);
        System.out.println("Alumno: " + a);

        // Como la colección es LAZY, aquí se inicializa al acceder con el EM abierto:
        System.out.println("Asignaturas de " + a.getNombre() + ":");
        a.getAsignaturas().forEach(asig -> System.out.println("  - " + asig.getNombre()));

        em.close();
    }

    /**
     * Elimina una relación N-N: Ana deja "Acceso a Datos", pero ni Ana ni la asignatura se borran.
     * Lo que se borra es la fila correspondiente en la tabla intermedia.
     */
    private static void romperRelacion(Long alumnoId) {
        System.out.println("\n[3] Romper relación: eliminar una asignatura del alumno (DELETE en join table)");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        tx.begin();

        Alumno ana = em.find(Alumno.class, alumnoId);

        // Buscamos la asignatura "Acceso a Datos" dentro del set (ya está cargado al iterar).
        Asignatura ad = ana.getAsignaturas().stream()
                .filter(x -> "Acceso a Datos".equals(x.getNombre()))
                .findFirst()
                .orElse(null);

        if (ad != null) {
            // removeAsignatura actualiza ambos lados.
            // Hibernate eliminará la fila (alumno_id, asignatura_id) en alumnos_asignaturas.
            ana.removeAsignatura(ad);
            System.out.println("Se eliminó la relación Ana <-> Acceso a Datos (no se borró la asignatura).");
        } else {
            System.out.println("No se encontró la asignatura para romper relación.");
        }

        tx.commit();
        em.close();
    }

    /**
     * Borra un alumno.
     * Importante:
     * - Esto NO debe borrar asignaturas (podrían ser compartidas por otros alumnos).
     * - Hibernate limpiará automáticamente la tabla intermedia.
     */
    private static void borrarAlumno(Long alumnoId) {
        System.out.println("\n[4] Borrar alumno (se limpian filas de tabla intermedia)");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        tx.begin();

        Alumno a = em.find(Alumno.class, alumnoId);
        if (a != null) {
            // Para evitar que queden asociaciones colgantes, es buena práctica
            // romper relaciones antes del remove.
            // (Hibernate suele limpiar la join table, pero didácticamente esto es más explícito).
            a.getAsignaturas().forEach(asig -> asig.getAlumnos().remove(a));
            a.getAsignaturas().clear();

            em.remove(a);
            System.out.println("Alumno borrado: " + a.getNombre());
        } else {
            System.out.println("Alumno no encontrado (quizá ya estaba borrado).");
        }

        tx.commit();
        em.close();
    }
}
