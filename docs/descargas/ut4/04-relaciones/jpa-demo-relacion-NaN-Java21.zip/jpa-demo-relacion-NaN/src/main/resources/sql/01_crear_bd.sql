-- Script de creación de base de datos para la demo N-N (Alumno <-> Asignatura)


CREATE DATABASE IF NOT EXISTS demo_jpa_relacion_nan
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

-- Nota:
-- Las tablas se crean automáticamente al ejecutar la demo porque en persistence.xml:
--   hibernate.hbm2ddl.auto = update

