package com.example.demo;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Utilidad para obtener un EntityManagerFactory (EMF) único.
 *
 * - En una aplicación real, el ciclo de vida del EMF suele gestionarse con un framework (Spring, Jakarta EE, etc.).
 * - En una demo de consola, lo gestionamos manualmente.
 */
public class JPAUtil {

    private static final EntityManagerFactory EMF =
            Persistence.createEntityManagerFactory("demoPU");

    private JPAUtil() {}

    public static EntityManagerFactory getEmf() {
        return EMF;
    }

    public static void close() {
        if (EMF != null && EMF.isOpen()) {
            EMF.close();
        }
    }
}
