README_MYSQL.txt

DEMO JPA/HIBERNATE: RELACIÓN N-N (Alumno <-> Asignatura)

1) Requisitos
- Java 17
- Maven 3.8+
- MySQL 8.x
- Usuario MySQL: root
- Contraseña: CAMBIAR_PASSWORD

2) Crear la base de datos
Ejecuta el script:
  src/main/resources/sql/01_crear_bd.sql

3) Ejecutar la demo
En la carpeta del proyecto:
  mvn -q clean compile exec:java

4) Qué verás
- Se crean 2 asignaturas y 2 alumnos.
- Se asocian (N-N) usando una tabla intermedia (join table).
- Se muestran las asociaciones.
- Se rompe una relación (se elimina una asignatura de un alumno).
- Se borra un alumno y se comprueba el efecto en la tabla intermedia.

5) Si quieres ver el SQL
En src/main/resources/META-INF/persistence.xml:
  hibernate.show_sql = true
  hibernate.format_sql = true
