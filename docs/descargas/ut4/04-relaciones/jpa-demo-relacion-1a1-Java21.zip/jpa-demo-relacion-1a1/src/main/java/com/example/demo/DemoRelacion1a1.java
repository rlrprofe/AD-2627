package com.example.demo;

import com.example.model.Dni;
import com.example.model.Persona;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

/**
 * DEMO RELACIÓN 1 A 1 (Uno a Uno) con JPA + Hibernate
 *
 * Objetivo:
 * 1) Crear un objeto Persona y un objeto Dni (objetos Java normales).
 * 2) Persistir SOLO Persona y comprobar que, gracias a cascade=ALL, también se persiste Dni.
 * 3) Ver que la FK está en la tabla "personas" (columna dni_id).
 * 4) Borrar Persona y comprobar que, por cascada, se borra también Dni.
 *

 */
public class DemoRelacion1a1 {

    public static void main(String[] args) {
        System.out.println("=== DEMO 1 A 1: Persona <-> Dni ===");

        Long personaId = crearPersonaConDni();
        System.out.println();

        leerPersonaYMostrarRelaciones(personaId);
        System.out.println();

        borrarPersonaEnCascada(personaId);

        JPAUtil.close();
        System.out.println("\nFin de la demo.");
    }

    private static Long crearPersonaConDni() {
        System.out.println("[1] Crear y persistir una Persona con su DNI (cascade=ALL)");

        // 1) Objetos TRANSIENT (solo memoria)
        Dni dni = new Dni("12345678A");
        Persona persona = new Persona();
        persona.setNombre("Ana");

        // Buena práctica: mantener ambos lados coherentes
        persona.asignarDni(dni);

        // 2) Abrimos EntityManager y transacción
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // 3) Persistimos SOLO Persona.
            //    Por cascade=ALL, Hibernate persistirá también el DNI.
            em.persist(persona);

            tx.commit();
            System.out.println("Persistido OK. Persona id = " + persona.getId()
                    + " | DNI id = " + persona.getDni().getId());
            return persona.getId();

        } catch (Exception ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    private static void leerPersonaYMostrarRelaciones(Long personaId) {
        System.out.println("[2] Leer Persona desde BD y mostrar su DNI");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            Persona p = em.find(Persona.class, personaId);
            System.out.println("Persona cargada: " + p);

            if (p.getDni() != null) {
                System.out.println("DNI asociado: " + p.getDni());

                // Navegación inversa (Dni -> Persona)
                System.out.println("Persona desde DNI (lado inverso): " + p.getDni().getPersona());
            } else {
                System.out.println("No hay DNI asociado.");
            }
        } finally {
            em.close();
        }
    }

    private static void borrarPersonaEnCascada(Long personaId) {
        System.out.println("[3] Borrar Persona y comprobar borrado en cascada del DNI");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // Para borrar, la entidad debe estar MANAGED.
            Persona p = em.find(Persona.class, personaId);
            System.out.println("A borrar: " + p);

            // Por cascade=ALL, también se borrará su DNI (si existe).
            em.remove(p);

            tx.commit();
            System.out.println("Borrado realizado.");
        } catch (Exception ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
