package com.example.model;

import jakarta.persistence.*;

/**
 * Entidad Dni.
 *
 * Parte inversa de la relación 1-1.
 * - Un DNI pertenece a UNA Persona.
 *
 * PUNTO CLAVE:
 * - Esta entidad NO es propietaria de la relación.
 * - La FK está en "personas.dni_id", no en "dnis".
 *
 * mappedBy = "dni" significa:
 * - "La relación ya está mapeada en el atributo dni de la clase Persona".
 */
@Entity
@Table(name = "dnis")
public class Dni {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 15)
    private String numero;

    /**
     * Relación 1-1 inversa.
     * - No crea FK adicional.
     * - Sirve para navegar de DNI -> Persona desde Java.
     */
    @OneToOne(mappedBy = "dni")
    private Persona persona;

    public Dni() {
        // Constructor vacío obligatorio para JPA
    }

    public Dni(String numero) {
        this.numero = numero;
    }

    public Long getId() {
        return id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    @Override
    public String toString() {
        return "Dni{id=" + id + ", numero='" + numero + "'}";
    }
}
