package com.example.model;

import jakarta.persistence.*;

/**
 * Entidad Persona.
 *
 * Caso didáctico: Relación UNO A UNO con Dni.
 * - Una Persona tiene UN único DNI.
 *
 * PUNTO CLAVE DE JPA:
 * - Esta clase ES la "propietaria" de la relación porque contiene la FK (dni_id).
 * - @JoinColumn indica la columna FK en la tabla "personas".
 * 
 * ¿Qué significa que sea “propietaria”?
 *  - En JPA solo una entidad controla la relación.
    - La entidad propietaria es la que:
            -contiene la clave foránea en la base de datos,
            -decide qué se guarda y qué no.
 */
@Entity
@Table(name = "personas")
public class Persona {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String nombre;

    /**
     * Relación 1-1 (propietaria).
     * 
     *
     * @OneToOne: relación Uno a Uno.
     *
     * cascade = CascadeType.ALL: Esta parte no define la relación, sino cómo se propagan las operaciones.
     *  - PERSIST: al persistir Persona, se persiste también su Dni.
     *  - REMOVE: al borrar Persona, se borra también su Dni.
     *  - MERGE, REFRESH, DETACH: también se propagan.
     *
     * @JoinColumn:
     *  - name = "dni_id": en la tabla "personas" habrá una columna dni_id (FK).
     *  - unique = true: refuerza la idea 1-1 (no puede repetirse el mismo dni_id).
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "dni_id", unique = true)
    private Dni dni;

    public Persona() {
        // Constructor vacío obligatorio para JPA
    }

    public Persona(String nombre, Dni dni) {
        this.nombre = nombre;
        this.dni = dni;
        // Nota: en un proyecto real conviene mantener ambos lados coherentes (ver asignarDni()).
    }

    /**
     * Método helper (buena práctica) para mantener la relación coherente en ambos lados.
     * - Si asignamos un DNI a una persona, también fijamos la Persona en el DNI.
     */
    public void asignarDni(Dni dni) {
        this.dni = dni;
        if (dni != null) {
            dni.setPersona(this);
        }
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Dni getDni() {
        return dni;
    }

    public void setDni(Dni dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Persona{id=" + id + ", nombre='" + nombre + "', dni=" + dni + "}";
    }
}
