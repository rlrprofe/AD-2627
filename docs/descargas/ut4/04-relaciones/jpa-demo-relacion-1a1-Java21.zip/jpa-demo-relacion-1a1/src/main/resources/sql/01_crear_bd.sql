-- ==========================================================
-- Script MySQL: Base de datos para la demo JPA relación 1 a 1
-- Proyecto: jpa-demo-relacion-1a1-mysql
-- ==========================================================

DROP DATABASE IF EXISTS demo_jpa_relacion_1a1;
CREATE DATABASE demo_jpa_relacion_1a1
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;


-- IMPORTANTE:
-- Las tablas (personas y dnis) las crea Hibernate automáticamente
-- porque en persistence.xml está:
--   hibernate.hbm2ddl.auto = update

