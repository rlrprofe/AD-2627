package com.example.demo;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Utilidad mínima para crear y reutilizar una EntityManagerFactory.
 *
 * - En una aplicación real, la EntityManagerFactory se crea una vez y se reutiliza.
 * - Abrir/cerrar EntityManagerFactory es "caro", por eso la centralizamos aquí.
 */
public final class JPAUtil {

    private static EntityManagerFactory emf;

    private JPAUtil() {
        // Evitamos instancias (clase utilitaria)
    }

    public static EntityManagerFactory getEmf() {
        if (emf == null) {
            // "demoPU" debe coincidir con el nombre definido en persistence.xml
            emf = Persistence.createEntityManagerFactory("demoPU");
        }
        return emf;
    }

    public static void close() {
        if (emf != null) {
            emf.close();
            emf = null;
        }
    }
}
