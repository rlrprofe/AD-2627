DEMO JPA (Hibernate) - RELACIÓN 1 A 1 (MYSQL)

1) Ejecuta el script de base de datos:
   src/main/resources/sql/01_crear_bd.sql

2) Verifica credenciales en:
   src/main/resources/META-INF/persistence.xml
   - user: root
   - password: CAMBIAR_PASSWORD

3) Ejecuta:
   mvn -q clean compile exec:java

Notas:
- Hibernate creará las tablas automáticamente (hbm2ddl.auto=update).
- Si quieres reiniciar datos entre ejecuciones, borra filas o cambia a create/create-drop.
