# Demo JPA/Hibernate - Relación 1 a 1 (Persona <-> DNI)

Proyecto Maven (Java 17) para demostrar una relación **1 a 1** usando **Jakarta Persistence (JPA)** con **Hibernate**.

## Qué se demuestra
- Cómo mapear una relación 1-1 con `@OneToOne`.
- Qué significa "propietario" de la relación (FK en la tabla del propietario).
- Cómo funciona `cascade = CascadeType.ALL` al persistir y borrar.
- Navegación en ambos sentidos (Persona -> Dni y Dni -> Persona).

## Requisitos
- JDK 17
- Maven 3.8+

## Ejecutar
```bash
mvn -q clean compile exec:java
```

## Base de datos
Se usa **H2 en memoria**. No necesitas instalar MySQL para probar esta demo.
