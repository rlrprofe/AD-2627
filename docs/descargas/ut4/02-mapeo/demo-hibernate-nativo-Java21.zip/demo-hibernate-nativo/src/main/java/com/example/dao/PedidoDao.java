package com.example.dao;

import com.example.model.Pedido;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class PedidoDao {

    public Integer insertar(Pedido pedido) {
        Transaction tx = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            session.persist(pedido);

            tx.commit();
            return pedido.getId();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        }
    }

    public Pedido buscarPorId(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.find(Pedido.class, id);
        }
    }

    public List<Pedido> listar() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Pedido", Pedido.class).getResultList();
        }
    }

    public List<Pedido> listarConProductos() {
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        return session.createQuery(
                "select distinct p from Pedido p " +
                "left join fetch p.productos " +
                "left join fetch p.cliente",
                Pedido.class
        ).getResultList();
    }
}


    public void actualizar(Pedido pedido) {
        Transaction tx = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            session.merge(pedido);

            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        }
    }

    public boolean eliminarPorId(int id) {
        Transaction tx = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            Pedido pedido = session.find(Pedido.class, id);
            if (pedido == null) {
                tx.commit();
                return false;
            }

            session.remove(pedido);

            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        }
    }
}
