package com.example.service;

import com.example.dao.PedidoDao;
import com.example.model.Cliente;
import com.example.model.Pedido;
import com.example.model.Producto;

import java.util.List;

public class PedidoService {

    private final PedidoDao dao = new PedidoDao();

    public Integer crearPedido(Cliente cliente, List<Producto> productosSeleccionados) {
        if (cliente == null)
            throw new IllegalArgumentException("El cliente no existe.");
        if (productosSeleccionados == null || productosSeleccionados.isEmpty()) {
            throw new IllegalArgumentException("El pedido debe incluir al menos un producto.");
        }

        Pedido pedido = new Pedido(cliente);
        for (Producto p : productosSeleccionados) {
            pedido.addProducto(p);
        }
        return dao.insertar(pedido);
    }

    public List<Pedido> listar() {
        return dao.listar();
    }

    public List<Pedido> listarConProductos() {
        return dao.listarConProductos();
    }

    public boolean eliminar(int id) {
        return dao.eliminarPorId(id);
    }
}