package com.example;


import com.example.controller.ClienteController;
import com.example.controller.PedidoController;
import com.example.controller.ProductoController;
import com.example.util.HibernateUtil;
import com.example.view.MenuView;

public class App {

    public static void main(String[] args) {

        // Fuerza inicialización de SessionFactory para detectar errores pronto
        HibernateUtil.getSessionFactory();

        MenuView menu = new MenuView();
        ClienteController clienteController = new ClienteController();
        ProductoController productoController = new ProductoController();
        PedidoController pedidoController = new PedidoController();

        int op = menu.menuPrincipal();
        while (op != 0) {
            if (op == 1) {
                clienteController.ejecutar();
            } else if (op == 2) {
                productoController.ejecutar();
            } else if (op == 3) {
                pedidoController.ejecutar();
            } else {
                System.out.println("Opción no válida.");
            }
            op = menu.menuPrincipal();
        }

        HibernateUtil.close();
        System.out.println("Programa finalizado.");
    }
}