package com.example.view;

import com.example.model.Pedido;
import com.example.model.Producto;
import com.example.util.ConsoleUtil;

import java.util.ArrayList;
import java.util.List;

public class PedidoView {

    public int pedirIdCliente() {
        return ConsoleUtil.leerEntero("Id del cliente: ");
    }

    public List<Integer> pedirIdsProductos() {
        System.out.println("Introduce ids de productos (0 para terminar):");
        List<Integer> ids = new ArrayList<>();
        int id = ConsoleUtil.leerEntero("Id producto: ");
        while (id != 0) {
            ids.add(id);
            id = ConsoleUtil.leerEntero("Id producto: ");
        }
        return ids;
    }

    public void mostrarListado(List<Pedido> pedidos) {
        System.out.println("\nListado de pedidos:");
        if (pedidos.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }
        for (Pedido p : pedidos) {
            System.out.println(" - " + p);
            // Nota: si productos es LAZY, acceder aquí podría requerir sesión abierta.
        }
    }

    public void mostrarListadoConDetalle(List<Pedido> pedidos) {
        System.out.println("\nListado de pedidos (con productos):");
        if (pedidos.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }

        for (Pedido p : pedidos) {
            System.out.println(" - Pedido{id=" + p.getId()
                    + ", fecha=" + p.getFecha()
                    + ", total=" + p.getTotal()
                    + ", clienteId=" + (p.getCliente() != null ? p.getCliente().getId() : null)
                    + "}");

            if (p.getProductos() == null || p.getProductos().isEmpty()) {
                System.out.println("     (sin productos)");
            } else {
                System.out.println("     Productos:");
                for (Producto prod : p.getProductos()) {
                    System.out.println("       * " + prod.getId() + " - " + prod.getNombre()
                            + " (" + prod.getPrecio() + "€)");
                }
            }
        }
    }

    public int pedirIdPedido() {
        return ConsoleUtil.leerEntero("Id pedido: ");
    }
}