package com.example.controller;


import com.example.service.ProductoService;
import com.example.view.MenuView;
import com.example.view.ProductoView;

public class ProductoController {

    private final ProductoService service = new ProductoService();
    private final ProductoView view = new ProductoView();
    private final MenuView menu = new MenuView();

    public void ejecutar() {
        int op = menu.menuCRUD("PRODUCTOS");
        while (op != 0) {
            try {
                if (op == 1) {
                    String nombre = view.pedirNombre();
                    double precio = view.pedirPrecio();
                    Integer id = service.crearProducto(nombre, precio);
                    System.out.println("Producto creado con id: " + id);
                } else if (op == 2) {
                    view.mostrarListado(service.listar());
                } else if (op == 3) {
                    int id = view.pedirId();
                    boolean ok = service.eliminar(id);
                    System.out.println(ok ? "Producto eliminado." : "No existe ese producto.");
                } else {
                    System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            op = menu.menuCRUD("PRODUCTOS");
        }
    }
}