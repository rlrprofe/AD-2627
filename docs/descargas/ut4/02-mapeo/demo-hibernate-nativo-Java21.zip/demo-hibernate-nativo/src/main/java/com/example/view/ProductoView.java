package com.example.view;

import com.example.model.Producto;
import com.example.util.ConsoleUtil;

import java.util.List;

public class ProductoView {

    public String pedirNombre() {
        return ConsoleUtil.leerCadenaNoVacia("Nombre: ");
    }

    public double pedirPrecio() {
        return ConsoleUtil.leerDouble("Precio: ");
    }

    public int pedirId() {
        return ConsoleUtil.leerEntero("Id producto: ");
    }

    public void mostrarListado(List<Producto> productos) {
        System.out.println("\nListado de productos:");
        if (productos.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }
        for (Producto p : productos) {
            System.out.println(" - " + p);
        }
    }
}
