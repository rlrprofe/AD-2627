package com.example.service;
import com.example.dao.ProductoDao;
import com.example.model.Producto;

import java.util.List;

public class ProductoService {

    private final ProductoDao dao = new ProductoDao();

    public Integer crearProducto(String nombre, double precio) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (precio <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor que 0.");
        }
        return dao.insertar(new Producto(nombre.trim(), precio));
    }

    public Producto buscar(int id) {
        return dao.buscarPorId(id);
    }

    public List<Producto> listar() {
        return dao.listar();
    }

    public boolean eliminar(int id) {
        return dao.eliminarPorId(id);
    }
}