package com.example.controller;



import com.example.service.ClienteService;
import com.example.view.ClienteView;
import com.example.view.MenuView;

public class ClienteController {

    private final ClienteService service = new ClienteService();
    private final ClienteView view = new ClienteView();
    private final MenuView menu = new MenuView();

    public void ejecutar() {
        int op = menu.menuCRUD("CLIENTES");
        while (op != 0) {
            try {
                if (op == 1) {
                    String nombre = view.pedirNombre();
                    String email = view.pedirEmail();
                    Integer id = service.crearCliente(nombre, email);
                    System.out.println("Cliente creado con id: " + id);
                } else if (op == 2) {
                    view.mostrarListado(service.listar());
                } else if (op == 3) {
                    int id = view.pedirId();
                    boolean ok = service.eliminar(id);
                    System.out.println(ok ? "Cliente eliminado." : "No existe ese cliente.");
                } else {
                    System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            op = menu.menuCRUD("CLIENTES");
        }
    }
}
