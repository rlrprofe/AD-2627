package com.example.service;

import com.example.dao.ClienteDao;
import com.example.model.Cliente;

import java.util.List;

public class ClienteService {

    private final ClienteDao dao = new ClienteDao();

    public Integer crearCliente(String nombre, String email) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (email == null || email.isBlank() || !email.contains("@")) {
            throw new IllegalArgumentException("Email no válido.");
        }
        return dao.insertar(new Cliente(nombre.trim(), email.trim()));
    }

    public Cliente buscar(int id) {
        return dao.buscarPorId(id);
    }

    public List<Cliente> listar() {
        return dao.listar();
    }

    public boolean eliminar(int id) {
        return dao.eliminarPorId(id);
    }
}