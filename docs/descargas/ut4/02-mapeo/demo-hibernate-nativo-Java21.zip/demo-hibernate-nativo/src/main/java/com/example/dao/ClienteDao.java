package com.example.dao;

import com.example.model.Cliente;
import com.example.util.HibernateUtil;
import org.hibernate.Session;

import org.hibernate.Transaction;

import java.util.List;

public class ClienteDao {

   public Integer insertar(Cliente c) {
    Transaction tx = null;

    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        tx = session.beginTransaction();

        session.persist(c);

        tx.commit();           // aquí normalmente ya se habrá asignado el id
        return c.getId();
    } catch (Exception e) {
        if (tx != null) tx.rollback();
        throw e;
    }
}


   public Cliente buscarPorId(int id) {
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        return session.find(Cliente.class, id);
    }
}


    public List<Cliente> listar() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Cliente", Cliente.class).getResultList();
        }
    }
 public void actualizar(Cliente c) {
        Transaction tx = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            // Hibernate 7: update() eliminado -> merge()
            // merge() devuelve la instancia gestionada (managed). En este caso no la necesitamos.
            session.merge(c);

            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        }
    }

    public boolean eliminarPorId(int id) {
        Transaction tx = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            // Hibernate 7: find() en lugar de get()
            Cliente c = session.find(Cliente.class, id);
            if (c == null) {
                tx.commit(); // no había nada que borrar; cerramos transacción limpiamente
                return false;
            }

            // Hibernate 7: delete() eliminado/obsoleto -> remove()
            session.remove(c);

            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        }
    }
}