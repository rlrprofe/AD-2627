package com.example.controller;


import com.example.model.Cliente;
import com.example.model.Producto;
import com.example.service.ClienteService;
import com.example.service.PedidoService;
import com.example.service.ProductoService;
import com.example.view.MenuView;
import com.example.view.PedidoView;

import java.util.ArrayList;
import java.util.List;

public class PedidoController {

    private final PedidoService pedidoService = new PedidoService();
    private final ClienteService clienteService = new ClienteService();
    private final ProductoService productoService = new ProductoService();

    private final PedidoView view = new PedidoView();
    private final MenuView menu = new MenuView();

    public void ejecutar() {
        System.out.println("\n--- PEDIDOS ---");
        System.out.println("1. Crear pedido");
        System.out.println("2. Listar pedidos");
        System.out.println("3. Eliminar pedido");
        System.out.println("0. Volver");

        int op = com.example.util.ConsoleUtil.leerEntero("Opción: ");
        while (op != 0) {
            try {
                if (op == 1) {
                    crearPedido();
                } else if (op == 2) {
                    //view.mostrarListado(pedidoService.listar());
                    view.mostrarListadoConDetalle(pedidoService.listarConProductos());
                } else if (op == 3) {
                    int id = view.pedirIdPedido();
                    boolean ok = pedidoService.eliminar(id);
                    System.out.println(ok ? "Pedido eliminado." : "No existe ese pedido.");
                } else {
                    System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            System.out.println("\n--- PEDIDOS ---");
            System.out.println("1. Crear pedido");
            System.out.println("2. Listar pedidos");
            System.out.println("3. Eliminar pedido");
            System.out.println("0. Volver");
            op = com.example.util.ConsoleUtil.leerEntero("Opción: ");
        }
    }

    private void crearPedido() {
        int idCliente = view.pedirIdCliente();
        Cliente cliente = clienteService.buscar(idCliente);
        if (cliente == null) {
            System.out.println("No existe ese cliente.");
            return;
        }

        List<Integer> idsProductos = view.pedirIdsProductos();
        if (idsProductos.isEmpty()) {
            System.out.println("No se ha añadido ningún producto.");
            return;
        }

        List<Producto> productos = new ArrayList<>();
        for (int idProd : idsProductos) {
            Producto p = productoService.buscar(idProd);
            if (p != null) {
                productos.add(p);
            } else {
                System.out.println("Aviso: no existe el producto id " + idProd + " (se ignora).");
            }
        }

        if (productos.isEmpty()) {
            System.out.println("No hay productos válidos para crear el pedido.");
            return;
        }

        Integer idPedido = pedidoService.crearPedido(cliente, productos);
        System.out.println("Pedido creado con id: " + idPedido);
    }
}