package com.example.util;


import java.util.Scanner;

public class ConsoleUtil {

    private static final Scanner SC = new Scanner(System.in);

    public static int leerEntero(String msg) {
        Integer valor = null;
        while (valor == null) {
            System.out.print(msg);
            String input = SC.nextLine();
            try {
                valor = Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debe ser un número entero.");
            }
        }
        return valor;
    }

    public static double leerDouble(String msg) {
        Double valor = null;
        while (valor == null) {
            System.out.print(msg);
            String input = SC.nextLine();
            try {
                valor = Double.parseDouble(input.trim().replace(",", "."));
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debe ser un número (ej. 12.50).");
            }
        }
        return valor;
    }

    public static String leerCadenaNoVacia(String msg) {
        String s = "";
        while (s.isBlank()) {
            System.out.print(msg);
            s = SC.nextLine().trim();
            if (s.isBlank()) {
                System.out.println("No puede estar vacío.");
            }
        }
        return s;
    }

    public static String leerEmailBasico(String msg) {
        String email = "";
        while (email.isBlank() || !email.contains("@") || !email.contains(".")) {
            System.out.print(msg);
            email = SC.nextLine().trim();
            if (email.isBlank() || !email.contains("@") || !email.contains(".")) {
                System.out.println("Email no válido (validación básica).");
            }
        }
        return email;
    }
}
