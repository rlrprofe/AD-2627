package com.example.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Pedido {
    private Integer id;
    private Date fecha;
    private double total;

    private Cliente cliente; // N:1
    private Set<Producto> productos; // N:M

    public Pedido() {
        this.productos = new HashSet<>();
    }

    public Pedido(Cliente cliente) {
        this();
        this.cliente = cliente;
        this.fecha = new Date();
        this.total = 0.0;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Set<Producto> getProductos() {
        return productos;
    }

    public void setProductos(Set<Producto> productos) {
        this.productos = productos;
    }

    public void addProducto(Producto p) {
        if (p != null) {
            this.productos.add(p);
            this.total += p.getPrecio();
        }
    }

    @Override
    public String toString() {
        return "Pedido{id=" + id + ", fecha=" + fecha + ", total=" + total +
                ", clienteId=" + (cliente != null ? cliente.getId() : null) +
                "}";
    }

}