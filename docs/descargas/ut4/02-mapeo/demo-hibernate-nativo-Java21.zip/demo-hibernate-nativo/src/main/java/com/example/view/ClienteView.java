package com.example.view;

import com.example.model.Cliente;
import com.example.util.ConsoleUtil;

import java.util.List;

public class ClienteView {

    public String pedirNombre() {
        return ConsoleUtil.leerCadenaNoVacia("Nombre: ");
    }

    public String pedirEmail() {
        return ConsoleUtil.leerEmailBasico("Email: ");
    }

    public int pedirId() {
        return ConsoleUtil.leerEntero("Id cliente: ");
    }

    public void mostrarListado(List<Cliente> clientes) {
        System.out.println("\nListado de clientes:");
        if (clientes.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }
        for (Cliente c : clientes) {
            System.out.println(" - " + c);
        }
    }
}