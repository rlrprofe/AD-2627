package com.example.view;

import com.example.util.ConsoleUtil;

public class MenuView {

    public int menuPrincipal() {
        System.out.println("\n=== TIENDA ORM (Hibernate nativo) ===");
        System.out.println("1. Gestión de clientes");
        System.out.println("2. Gestión de productos");
        System.out.println("3. Gestión de pedidos");
        System.out.println("0. Salir");
        return ConsoleUtil.leerEntero("Opción: ");
    }

    public int menuCRUD(String titulo) {
        System.out.println("\n--- " + titulo + " ---");
        System.out.println("1. Alta");
        System.out.println("2. Listar");
        System.out.println("3. Eliminar");
        System.out.println("0. Volver");
        return ConsoleUtil.leerEntero("Opción: ");
    }
}