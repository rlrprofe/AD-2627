package es.dam.jdbc.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Acceso a datos de las cuentas. El DAO NO crea ni cierra la conexión recibida:
 * la controla el servicio para que todas las operaciones compartan transacción.
 */
public class CuentaDAO {
    /**
     * Descuenta el importe solo si la cuenta existe y tiene saldo suficiente.
     * @param con conexión compartida, con autoCommit desactivado por el servicio
     * @param cuenta identificador de la cuenta de origen
     * @param importe cantidad positiva que se desea descontar
     * @return número de filas actualizadas (normalmente 0 o 1)
     * @throws SQLException si falla la operación SQL
     */
    public int descontar(Connection con, int cuenta, BigDecimal importe) throws SQLException {
        String sql = "UPDATE cuentas SET saldo = saldo - ? WHERE id = ? AND saldo >= ?";
        // PreparedStatement parametriza los valores y evita concatenar datos al SQL.
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, importe);
            ps.setInt(2, cuenta);
            ps.setBigDecimal(3, importe); // Evita dejar el saldo en negativo.
            return ps.executeUpdate(); // El servicio comprueba que se modificó una fila.
        }
    }

    /**
     * Incrementa el saldo de la cuenta de destino.
     * @param con conexión compartida con la operación de descuento
     * @param cuenta identificador de destino
     * @param importe cantidad que se desea ingresar
     * @return número de filas actualizadas
     * @throws SQLException si falla la operación SQL
     */
    public int ingresar(Connection con, int cuenta, BigDecimal importe) throws SQLException {
        String sql = "UPDATE cuentas SET saldo = saldo + ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, importe);
            ps.setInt(2, cuenta);
            return ps.executeUpdate();
        }
    }
}
