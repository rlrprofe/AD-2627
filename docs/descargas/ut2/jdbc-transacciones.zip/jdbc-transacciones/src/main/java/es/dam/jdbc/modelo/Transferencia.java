package es.dam.jdbc.modelo;

import java.math.BigDecimal;

/**
 * Representa una solicitud de transferencia entre dos cuentas.
 * No contiene SQL ni realiza operaciones sobre la base de datos.
 * Las reglas de negocio se comprueban en TransferenciaService.
 */
public class Transferencia {
    /** Identificador de la cuenta de origen. */
    private int origen;
    /** Identificador de la cuenta de destino. */
    private int destino;
    /** Importe expresado con precisión decimal, adecuado para cantidades monetarias. */
    private BigDecimal importe;

    /**
     * Crea una solicitud de transferencia.
     * @param origen identificador de la cuenta que entrega el dinero
     * @param destino identificador de la cuenta que lo recibe
     * @param importe cantidad que se desea transferir
     */
    public Transferencia(int origen, int destino, BigDecimal importe) {
        this.origen = origen;
        this.destino = destino;
        this.importe = importe;
    }

    /** @return identificador de la cuenta de origen */
    public int getOrigen() { return origen; }
    /** @param origen nuevo identificador de origen */
    public void setOrigen(int origen) { this.origen = origen; }
    /** @return identificador de la cuenta de destino */
    public int getDestino() { return destino; }
    /** @param destino nuevo identificador de destino */
    public void setDestino(int destino) { this.destino = destino; }
    /** @return importe de la transferencia */
    public BigDecimal getImporte() { return importe; }
    /** @param importe nuevo importe de la transferencia */
    public void setImporte(BigDecimal importe) { this.importe = importe; }

    /** @return descripción de la solicitud, útil para depuración */
    @Override
    public String toString() {
        return "Transferencia{origen=" + origen + ", destino=" + destino
                + ", importe=" + importe + "}";
    }
}
