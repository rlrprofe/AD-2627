package es.dam.jdbc.app;

import es.dam.jdbc.modelo.Transferencia;
import es.dam.jdbc.servicio.TransferenciaService;
import java.math.BigDecimal;
import java.sql.SQLException;

/**
 * Punto de entrada del ejemplo de transacciones: transfiere 20,00 de la cuenta 1 a la 2.
 * ATENCIÓN: modifica saldos de la base de datos empresa; usa datos de prueba.
 */
public class DemoTransferencia {
    /** @param args no se utilizan argumentos de consola */
    public static void main(String[] args) {
        // BigDecimal evita los errores de redondeo habituales de double en importes.
        Transferencia solicitud = new Transferencia(1, 2, new BigDecimal("20.00"));
        try {
            new TransferenciaService().transferir(solicitud);
            System.out.println("Transferencia confirmada: " + solicitud);
        } catch (SQLException | IllegalArgumentException e) {
            // Un error impide mostrar un mensaje de éxito engañoso.
            System.err.println("Transferencia cancelada: " + e.getMessage());
        }
    }
}
