package es.dam.jdbc.servicio;

import es.dam.jdbc.config.ConexionBD;
import es.dam.jdbc.dao.CuentaDAO;
import es.dam.jdbc.modelo.Transferencia;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Coordina una transferencia atómica: o se actualizan las dos cuentas o ninguna.
 * Es el servicio, no el DAO, quien decide commit y rollback.
 */
public class TransferenciaService {
    private final CuentaDAO dao = new CuentaDAO();

    /**
     * Ejecuta una transferencia bancaria dentro de una única transacción.
     * @param transferencia solicitud con cuentas e importe
     * @throws SQLException si alguna operación SQL falla o no afecta una fila
     * @throws IllegalArgumentException si los datos de entrada no son válidos
     */
    public void transferir(Transferencia transferencia) throws SQLException {
        // Se valida antes de abrir una conexión para no consumir recursos innecesarios.
        if (transferencia == null || transferencia.getOrigen() <= 0
                || transferencia.getDestino() <= 0
                || transferencia.getOrigen() == transferencia.getDestino()
                || transferencia.getImporte() == null
                || transferencia.getImporte().signum() <= 0) {
            throw new IllegalArgumentException("Transferencia no válida");
        }
        try (Connection con = ConexionBD.abrir()) {
            con.setAutoCommit(false); // Desactiva la confirmación individual de cada UPDATE.
            try {
                // Ambos métodos del DAO usan EXACTAMENTE la misma conexión.
                if (dao.descontar(con, transferencia.getOrigen(), transferencia.getImporte()) != 1) {
                    throw new SQLException("Cuenta origen inexistente o saldo insuficiente");
                }
                if (dao.ingresar(con, transferencia.getDestino(), transferencia.getImporte()) != 1) {
                    throw new SQLException("Cuenta destino inexistente");
                }
                con.commit(); // Solo se confirma cuando ambas actualizaciones han funcionado.
            } catch (SQLException | RuntimeException error) {
                try {
                    con.rollback(); // Deshace también el primer UPDATE si falló el segundo.
                } catch (SQLException falloRollback) {
                    error.addSuppressed(falloRollback); // Conserva el error original.
                }
                throw error;
            }
            // try-with-resources cierra la conexión al terminar. No se reactiva
            // autoCommit aquí: cambiarlo después de un error podría confirmar cambios.
        }
    }
}
