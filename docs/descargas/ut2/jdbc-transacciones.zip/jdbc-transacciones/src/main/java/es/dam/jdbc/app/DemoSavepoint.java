package es.dam.jdbc.app;

import es.dam.jdbc.servicio.PedidoService;
import java.sql.SQLException;

/**
 * Punto de entrada para demostrar rollback parcial mediante Savepoint.
 * Requiere el pedido 1001 creado por sql/03-empresa-transacciones.sql.
 */
public class DemoSavepoint {
    /** @param args no se utilizan argumentos de consola */
    public static void main(String[] args) {
        try {
            // El albarán es opcional; su fallo no impide confirmar el pedido.
            new PedidoService().confirmarPedidoConAlbaranOpcional(1001);
            System.out.println("Pedido confirmado; comprueba pedidos y albaranes en MySQL.");
        } catch (SQLException | IllegalArgumentException e) {
            System.err.println("Error al procesar el pedido: " + e.getMessage());
        }
    }
}
