package es.dam.jdbc.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Centraliza la creación de conexiones JDBC a MySQL.
 * Lee los datos desde src/main/resources/db.properties, sin credenciales en Java.
 */
public final class ConexionBD {
    /** Evita crear instancias de una clase de utilidades. */
    private ConexionBD() { }

    /**
     * Abre una conexión nueva con los parámetros del archivo de propiedades.
     * @return conexión abierta; el llamador debe cerrarla con try-with-resources
     * @throws SQLException si falta la configuración, es incorrecta o falla MySQL
     */
    public static Connection abrir() throws SQLException {
        Properties datos = new Properties();
        // Maven copia los recursos al classpath: se leen igual desde VS Code o un JAR.
        try (InputStream entrada = ConexionBD.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (entrada == null) {
                throw new SQLException("No se encuentra db.properties. Copia db.properties.example "
                        + "a src/main/resources/db.properties y configura MySQL.");
            }
            datos.load(entrada);
        } catch (IOException e) {
            throw new SQLException("No se pudo leer db.properties", e);
        }
        String url = obligatorio(datos, "jdbc.url");
        String usuario = obligatorio(datos, "jdbc.user");
        String clave = obligatorio(datos, "jdbc.password");
        // DriverManager localiza el driver MySQL que Maven añade al classpath.
        return DriverManager.getConnection(url, usuario, clave);
    }

    /** Recupera una propiedad obligatoria y evita errores de configuración ambiguos. */
    private static String obligatorio(Properties datos, String clave) throws SQLException {
        String valor = datos.getProperty(clave);
        if (valor == null || valor.isBlank()) {
            throw new SQLException("Falta la propiedad " + clave + " en db.properties");
        }
        return valor.trim();
    }
}
