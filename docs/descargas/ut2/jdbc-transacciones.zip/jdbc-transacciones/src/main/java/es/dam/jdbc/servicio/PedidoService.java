package es.dam.jdbc.servicio;

import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Demuestra un SAVEPOINT: el pedido se confirma aunque falle su albarán opcional.
 * A diferencia de una transferencia, la regla de negocio permite el éxito parcial.
 */
public class PedidoService {
    /**
     * Confirma el pedido y, si es posible, crea un albarán asociado.
     * @param idPedido identificador del pedido existente
     * @throws SQLException si falla la confirmación obligatoria del pedido
     */
    public void confirmarPedidoConAlbaranOpcional(int idPedido) throws SQLException {
        if (idPedido <= 0) throw new IllegalArgumentException("Id de pedido no válido");
        try (Connection con = ConexionBD.abrir()) {
            con.setAutoCommit(false); // Las operaciones quedan pendientes de commit.
            try {
                String sqlPedido = "UPDATE pedidos SET estado = 'CONFIRMADO' WHERE id = ?";
                try (PreparedStatement ps = con.prepareStatement(sqlPedido)) {
                    ps.setInt(1, idPedido);
                    if (ps.executeUpdate() != 1) {
                        throw new SQLException("No existe el pedido " + idPedido);
                    }
                }
                // Guardamos un punto al que volver sin perder la confirmación del pedido.
                Savepoint antesAlbaran = con.setSavepoint("ANTES_ALBARAN");
                try {
                    String sqlAlbaran = "INSERT INTO albaranes (id_pedido, fecha) VALUES (?, ?)";
                    try (PreparedStatement ps = con.prepareStatement(sqlAlbaran)) {
                        ps.setInt(1, idPedido);
                        ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
                        ps.executeUpdate();
                    }
                } catch (SQLException falloAlbaran) {
                    // Solo deshacemos lo posterior al SAVEPOINT; el pedido sigue pendiente.
                    con.rollback(antesAlbaran);
                    System.err.println("Albarán opcional no creado: " + falloAlbaran.getMessage());
                }
                con.commit(); // Confirma el pedido y el albarán si pudo crearse.
            } catch (SQLException | RuntimeException error) {
                try { con.rollback(); } catch (SQLException fallo) { error.addSuppressed(fallo); }
                throw error;
            }
        }
    }
}
