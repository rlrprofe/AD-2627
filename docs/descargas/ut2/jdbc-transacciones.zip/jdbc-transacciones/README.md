# JDBC: transacciones, rollback y savepoints (Java 21)

Proyecto didáctico de la **UT2 de Acceso a Datos (DAM)** con MySQL/InnoDB. Incluye dos demostraciones independientes: una **transferencia atómica** y un **pedido con albarán opcional**, donde se permite deshacer solo una parte.

## Requisitos

- JDK 21, Maven y VS Code (o cualquier IDE compatible).
- MySQL 8 con una cuenta de prácticas y permisos sobre la base `empresa`.
- El driver MySQL Connector/J se descarga desde el `pom.xml`.

## 1. Preparar la base de datos

Ejecuta `sql/03-empresa-transacciones.sql` desde MySQL Workbench o el cliente MySQL. Crea la base `empresa`, las tablas InnoDB `cuentas`, `pedidos` y `albaranes`, y sus datos de prueba. **El script restablece los saldos de las cuentas de ejemplo y el estado del pedido 1001 al volver a ejecutarse**; no lo ejecutes en una base de datos con datos que debas conservar.

Puedes crear un usuario de prácticas con permisos mínimos suficientes. No utilices `root` para las aplicaciones.

```sql
SELECT id, titular, saldo FROM empresa.cuentas ORDER BY id;
SELECT id, estado FROM empresa.pedidos ORDER BY id;
SELECT id, id_pedido, fecha FROM empresa.albaranes ORDER BY id;
```

## 2. Configurar db.properties (obligatorio)

1. Copia `src/main/resources/db.properties.example` a `src/main/resources/db.properties`.
2. Edita **el archivo copiado** con la URL, el usuario y la contraseña de tu MySQL.

```properties
jdbc.url=jdbc:mysql://localhost:3306/empresa
jdbc.user=alumno
jdbc.password=TU_CLAVE_LOCAL
```

`ConexionBD` utiliza `Properties` y `getResourceAsStream("db.properties")`; **no utiliza variables de entorno ni `System.getenv()`**. El archivo real está excluido de Git mediante `.gitignore`. **Atención:** Maven copia recursos a `target/classes` y pueden incluirse en el JAR; no distribuyas artefactos que contengan contraseñas.

## 3. Compilar y ejecutar

Desde la carpeta que contiene `pom.xml`:

```powershell
mvn clean compile
```

En VS Code, abre `src/main/java/es/dam/jdbc/app/DemoTransferencia.java` y pulsa **Run Java** sobre `main`. Para el segundo ejemplo ejecuta `DemoSavepoint.java` del mismo modo.

| Clase principal | Qué demuestra | Efecto en la base de datos |
|---|---|---|
| `es.dam.jdbc.app.DemoTransferencia` | `setAutoCommit(false)`, dos `UPDATE`, `commit()` o `rollback()` | Descuenta 20,00 de la cuenta 1 e ingresa 20,00 en la cuenta 2 |
| `es.dam.jdbc.app.DemoSavepoint` | `setSavepoint()`, `rollback(savepoint)` y `commit()` | Confirma el pedido 1001 e intenta crear un albarán |

**Importante:** ejecutar varias veces `DemoTransferencia` repite la transferencia y cambia de nuevo los saldos. Revisa las tablas antes y después.

## 4. Organización del código

```text
src/main/java/es/dam/jdbc/
  app/DemoTransferencia.java    # main: ejemplo de transferencia
  app/DemoSavepoint.java        # main: ejemplo de savepoint
  config/ConexionBD.java        # Properties + DriverManager
  modelo/Transferencia.java     # clase convencional con atributos privados y getters/setters
  dao/CuentaDAO.java            # sentencias UPDATE parametrizadas
  servicio/TransferenciaService.java  # transacción todo-o-nada
  servicio/PedidoService.java         # transacción con operación opcional
src/main/resources/db.properties.example
sql/03-empresa-transacciones.sql
```

Las clases incluyen **Javadoc** y comentarios internos que explican decisiones y operaciones. `Transferencia` es una clase Java convencional, no un `record`: contiene atributos privados, constructor, getters, setters y `toString()`.

## 5. Transferencia: una sola transacción

1. El servicio valida que las cuentas sean distintas, positivas y que el importe sea mayor que cero.
2. Abre **una única `Connection`** y llama a `setAutoCommit(false)`.
3. `CuentaDAO.descontar(...)` usa `UPDATE ... WHERE saldo >= ?` y devuelve las filas afectadas.
4. `CuentaDAO.ingresar(...)` recibe **la misma conexión**.
5. Si ambas operaciones afectan exactamente a una fila, el servicio ejecuta `commit()`.
6. Si una falla, ejecuta `rollback()`; incluso el descuento inicial queda deshecho.

El DAO **no debe cerrar la conexión recibida**; solo cierra sus `PreparedStatement`. La conexión se cierra mediante `try-with-resources` en el servicio. Si falla también el `rollback`, su excepción se conserva con `addSuppressed`.

## 6. Savepoint: deshacer solo una parte

`PedidoService` cambia el estado del pedido a `CONFIRMADO`, crea un `Savepoint` e intenta insertar el albarán. Si falla esa inserción, vuelve al punto de guardado y confirma el pedido igualmente. Esta decisión es válida **porque el albarán es opcional**; no debe aplicarse a una transferencia bancaria.

## 7. Pruebas guiadas

1. **Éxito:** consulta saldos, ejecuta `DemoTransferencia` y comprueba el movimiento de 20,00.
2. **Saldo insuficiente:** cambia temporalmente la cantidad del `new BigDecimal(...)` por un importe superior al saldo; no deben cambiar las cuentas.
3. **Destino inexistente:** usa `new Transferencia(1, 9999, new BigDecimal("20.00"))`. Aunque el primer `UPDATE` sea válido, el segundo afecta 0 filas y se ejecuta `rollback()`.
4. **Savepoint:** ejecuta `DemoSavepoint` y consulta `pedidos` y `albaranes`. Para forzar el fallo del albarán, prepara un escenario controlado que provoque una restricción SQL, sin modificar tablas de producción.
5. **Repetición:** observa que cada ejecución exitosa modifica los datos. Para recuperar los valores de partida, vuelve a ejecutar el script de prácticas (teniendo en cuenta que los albaranes existentes no se borran).

## 8. Problemas frecuentes

| Error | Qué revisar |
|---|---|
| `No se encuentra db.properties` | Copia el `.example` con el nombre exacto en `src/main/resources` |
| `Falta la propiedad jdbc.password` | Completa las tres propiedades; no dejes valores vacíos |
| `Access denied` | Usuario, contraseña y permisos MySQL |
| `Unknown database 'empresa'` | Ejecuta el script SQL |
| `Communications link failure` | MySQL iniciado, host y puerto correctos |
| `ClassNotFoundException` | `mvn clean compile`, paquete de la clase y recarga del proyecto Java en VS Code |
| `No suitable driver` | Dependencia Maven y classpath |

**Seguridad:** no publiques `db.properties`, ni capturas que muestren credenciales, ni JAR con el archivo de configuración real incluido.
