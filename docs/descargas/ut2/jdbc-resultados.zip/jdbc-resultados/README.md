# jdbc-resultados

Procesamiento de `ResultSet` y `ResultSetMetaData`.

## Objetivos

- Identificar qué responsabilidad tiene cada clase.
- Ejecutar las operaciones JDBC con recursos cerrados automáticamente.
- Interpretar los resultados y los errores SQL.

## Requisitos

- JDK 21 y Maven (o un IDE con soporte Maven).
- MySQL 8.0 o superior y un usuario con permisos sobre la base de datos **curso**.
- La dependencia `com.mysql:mysql-connector-j` se descargará mediante Maven.

## Preparación de la base de datos

Los scripts se encuentran en `sql/`. Ejecútalos en MySQL Workbench o en el cliente MySQL **en el orden de su numeración**.

**Atención:** el script original de `curso` contiene `DROP DATABASE IF EXISTS CURSO`; elimina esa base de datos y sus datos. Ejecútalo solo en un entorno de prácticas y con copia de seguridad si procede.

Crea un usuario específico para el ejercicio y concede únicamente los permisos necesarios; evita trabajar como `root`. Ejemplo orientativo desde una cuenta administradora:

```sql
CREATE USER IF NOT EXISTS 'alumno'@'localhost' IDENTIFIED BY 'CAMBIA_ESTA_CLAVE';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, DROP, EXECUTE ON curso.* TO 'alumno'@'localhost';
```

Si conectas por `127.0.0.1` en lugar de `localhost`, comprueba que la cuenta MySQL permita ese origen.

## Configuración en PowerShell

```powershell
$env:JDBC_URL = "jdbc:mysql://localhost:3306/curso"
$env:JDBC_USER = "alumno"
$env:JDBC_PASSWORD = "TU_CLAVE_LOCAL"
```

Las variables de entorno se aplican a la sesión actual de PowerShell. No subas contraseñas a Git ni las incluyas en capturas.

## Compilación

```powershell
mvn clean compile
```

## Ejecución

Desde VS Code, abre la carpeta del proyecto Maven y ejecuta la clase que contiene `main`. Alternativamente, compila y ejecuta desde tu IDE.

**Clase principal:** `es.dam.jdbc.app.DemoResultados`. Consulta empleados del departamento 30 y muestra metadatos, incluyendo la diferencia entre nombre y etiqueta de columna.

## Organización

- `config/ConexionBD.java`: crea conexiones y lee la configuración.
- `modelo/` (cuando procede): representa entidades, sin SQL.
- `dao/`: ejecuta consultas y transforma los resultados.
- `servicio/`: aplica reglas de negocio y controla transacciones.
- `app/`: inicia ejemplos o presenta un menú de consola.
- `sql/`: prepara el entorno de pruebas.

## Buenas prácticas aplicadas

1. `try-with-resources` para `Connection`, `PreparedStatement` y `ResultSet`.
2. Parámetros `?` para valores variables; nunca concatenar entradas del usuario en SQL.
3. Validar entradas y comprobar filas afectadas.
4. Capturar `SQLException` en la capa de presentación y mostrar `SQLState` y código del proveedor.
5. Evitar lambdas y mantener los métodos cortos y descriptivos.
6. Los ejemplos que modifican datos deben ejecutarse sobre una base de prácticas.

## Errores frecuentes

| Síntoma | Comprobación |
|---|---|
| `Access denied` | Usuario, contraseña y permisos de MySQL |
| `Communications link failure` | Servidor arrancado, puerto y host |
| `Unknown database` | Ejecutar el script de creación |
| `Table doesn't exist` | Seleccionar la BD correcta y cargar las tablas |
| `No suitable driver` | Revisar la dependencia Maven y sincronizar el proyecto |
| `Falta JDBC_PASSWORD` | Configurar la variable de entorno antes de ejecutar |

## Actividades de ampliación

- Añadir validaciones y casos de error sin cambiar las responsabilidades de las clases.
- Explicar qué recursos cierra cada `try-with-resources`.
- Documentar una captura de ejecución y justificar los valores obtenidos.

## Ejemplos adicionales de cursores

- `es.dam.jdbc.app.DemoCursorDesplazable`: demuestra `first`, `last` y `absolute`.
- `es.dam.jdbc.app.DemoResultSetActualizable`: demuestra `updateRow` para el producto 9001, si existe. El driver debe admitir cursores actualizables; se recomienda practicar antes el CRUD con `PreparedStatement`.
