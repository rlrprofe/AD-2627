package es.dam.jdbc.app;

import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** Solicita un cursor desplazable; el soporte depende del driver. */
public class DemoCursorDesplazable {
    public static void main(String[] args) {
        try (Connection con = ConexionBD.abrir();
             Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                     ResultSet.CONCUR_READ_ONLY);
             ResultSet rs = st.executeQuery("SELECT emp_no, apellido FROM empleados ORDER BY emp_no")) {
            if (rs.first()) System.out.println("Primero: " + rs.getString("apellido"));
            if (rs.last()) System.out.println("Último: " + rs.getString("apellido"));
            if (rs.absolute(2)) System.out.println("Segundo: " + rs.getString("apellido"));
        } catch (SQLException e) {
            System.err.printf("Error: %s [SQLState=%s]%n", e.getMessage(),e.getSQLState());
        }
    }
}
