package es.dam.jdbc.app;
import es.dam.jdbc.dao.ConsultaDAO;
import java.sql.SQLException;
public class DemoResultados {
    public static void main(String[] args) {
        ConsultaDAO dao = new ConsultaDAO();
        try {
            System.out.println("Empleados del departamento 30:");
            dao.mostrarEmpleados(30);
            System.out.println("Metadatos de la consulta:");
            dao.mostrarMetadatos();
        } catch (SQLException e) {
            System.err.printf("Error SQL: %s [SQLState=%s, código=%d]%n",e.getMessage(),e.getSQLState(),e.getErrorCode());
        }
    }
}
