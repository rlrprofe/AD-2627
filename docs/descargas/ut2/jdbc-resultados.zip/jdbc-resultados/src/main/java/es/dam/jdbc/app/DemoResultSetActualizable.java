package es.dam.jdbc.app;

import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** Demuestra updateRow sobre una tabla sencilla. Modifica el producto 9001 si existe. */
public class DemoResultSetActualizable {
    public static void main(String[] args) {
        String sql = "SELECT producto_no, descripcion, stock_disponible FROM productos WHERE producto_no = 9001";
        try (Connection con = ConexionBD.abrir();
             Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                     ResultSet.CONCUR_UPDATABLE);
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                int nuevoStock = rs.getInt("stock_disponible") + 1;
                rs.updateInt("stock_disponible", nuevoStock);
                rs.updateRow(); // Envía la modificación a MySQL.
                System.out.println("Nuevo stock: " + nuevoStock);
            } else {
                System.out.println("Primero inserta el producto 9001 desde el proyecto CRUD.");
            }
        } catch (SQLException e) {
            System.err.printf("Cursor no disponible o error SQL: %s [SQLState=%s]%n",
                    e.getMessage(),e.getSQLState());
        }
    }
}
