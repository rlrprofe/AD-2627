package es.dam.jdbc.dao;
import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/** Lectura de filas y metadatos; no mezcla entrada de usuario con SQL. */
public class ConsultaDAO {
    public void mostrarEmpleados(int departamento) throws SQLException {
        String sql = "SELECT emp_no, apellido, salario FROM empleados WHERE dep_no = ? ORDER BY emp_no";
        try (Connection con = ConexionBD.abrir(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, departamento);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    System.out.printf("%d | %s | %s%n",rs.getInt("emp_no"),rs.getString("apellido"),rs.getBigDecimal("salario"));
                }
            }
        }
    }
    public void mostrarMetadatos() throws SQLException {
        String sql = "SELECT emp_no AS identificador, apellido, salario FROM empleados LIMIT 1";
        try (Connection con = ConexionBD.abrir(); PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData meta = rs.getMetaData();
            for (int columna = 1; columna <= meta.getColumnCount(); columna++) {
                System.out.printf("%d: etiqueta=%s, nombre=%s, tipo=%s%n",columna,
                        meta.getColumnLabel(columna),meta.getColumnName(columna),meta.getColumnTypeName(columna));
            }
        }
    }
}
