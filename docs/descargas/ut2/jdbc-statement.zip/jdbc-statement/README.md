# Proyecto Maven: conexión JDBC en tres versiones

Proyecto didáctico para **JDK 21**, Maven y MySQL. El script `sql/01-curso-original.sql` prepara la base de datos `curso`. **Atención:** el script incluye `DROP DATABASE IF EXISTS CURSO`; ejecútalo únicamente en una instalación de prácticas, pues borra esa base de datos.

## Objetivo

Comparar dos formas de configurar `DriverManager.getConnection(url, usuario, clave)` sin confundir **constantes** con **protección de secretos**.

| Aspecto | V1: constantes | V2: `db.properties` | V3: entorno |
|---|---|---|---|
| Archivo | `ConexionBD_V1.java` | `ConexionBD_V2.java` | `ConexionBD_V3.java` |
| Configuración | Literales Java | Fichero privado externo al código | Variables de entorno |
| Contraseña | En el código (solo prueba) | En `db.properties` local, excluido de Git | `JDBC_PASSWORD` obligatoria |
| Uso | Primer ejemplo | Desarrollo local | Proyectos y despliegues |

**Advertencia:** `private` y `final` no cifran secretos. Las contraseñas en fuentes, repositorios o JAR pueden recuperarse. La V1 incluye `clave_de_prueba`, una clave ilustrativa que debes adaptar **solo para una cuenta local sin datos sensibles**. Nunca copies una contraseña real a un repositorio. Las variables de entorno reducen la exposición en el código, pero tampoco son un almacén secreto infalible.

## Preparación

1. Instala JDK 21, Maven y MySQL.
2. Revisa y ejecuta `sql/01-curso-original.sql` **solo en una base de pruebas**.
3. Crea un usuario con permisos mínimos sobre `curso` (evita `root`). Por ejemplo, con una cuenta administradora de MySQL:

```sql
CREATE USER IF NOT EXISTS 'alumno'@'localhost' IDENTIFIED BY 'CAMBIA_ESTA_CLAVE';
GRANT SELECT ON curso.* TO 'alumno'@'localhost';
```

El ejemplo de conexión solo comprueba que MySQL acepta las credenciales. Para ejercicios que modifiquen datos, concede únicamente los permisos adicionales que necesiten. Ajusta también el origen del usuario si MySQL lo requiere.

## V1 — Constantes Java

En `ConexionBD_V1.java` aparecen `URL`, `USUARIO` y `CLAVE` como `private static final String`. Para este ejercicio, la contraseña de la cuenta local debe coincidir con el valor ilustrativo de `CLAVE`, o bien debes cambiar ese valor **sin subirlo a Git**. No uses esta variante para contraseñas reales ni aplicaciones distribuidas.

```java
private static final String URL = "jdbc:mysql://localhost:3306/curso";
private static final String USUARIO = "alumno";
private static final String CLAVE = "clave_de_prueba";
```

`final` evita reasignar la variable; no impide leerla desde el código o un JAR.

## V2 — Archivo `db.properties` (desarrollo local)

1. En `src/main/resources`, copia `db.properties.example` y renombra la copia a `db.properties`.
2. Edita los valores de `jdbc.url`, `jdbc.user` y `jdbc.password` para tu MySQL de prácticas.
3. Ejecuta `DemoConexion` con **Run Java**. La V2 buscará el fichero mediante `getResourceAsStream("db.properties")` y `Properties.load()`.

Ejemplo de contenido del archivo **privado** `db.properties` (no subir a GitHub):

```properties
jdbc.url=jdbc:mysql://localhost:3306/curso
jdbc.user=alumno
jdbc.password=TU_CLAVE_LOCAL
```

El `.gitignore` excluye `src/main/resources/db.properties`, pero **no** excluye la plantilla `db.properties.example`. El archivo real se copia a `target/classes` al compilar Maven: tampoco distribuyas el JAR o los artefactos con secretos. Un `.gitignore` no protege un archivo que ya estuviera versionado.

## V3 — Variables de entorno (recomendada para despliegues)

`System.getenv("JDBC_PASSWORD")` consulta una variable concreta; devuelve `null` si no existe. `System.getenv()` devuelve un mapa de variables y `getOrDefault()` permite elegir un valor alternativo para URL y usuario. **La contraseña no tiene valor por defecto**; si falta o está en blanco, se lanza una `SQLException` antes de conectar.

### Windows: PowerShell

```powershell
$env:JDBC_URL = "jdbc:mysql://localhost:3306/curso"
$env:JDBC_USER = "alumno"
$env:JDBC_PASSWORD = "TU_CLAVE_LOCAL"
```

### Linux: Bash

```bash
export JDBC_URL="jdbc:mysql://localhost:3306/curso"
export JDBC_USER="alumno"
export JDBC_PASSWORD="TU_CLAVE_LOCAL"
```

Las variables se aplican a esa sesión y a los procesos que se inicien desde ella. Si el IDE ya estaba abierto, puede no recibirlas; configura las variables en su ejecución o ábrelo desde la terminal preparada. Evita imprimir la contraseña, incluirla en capturas o subir scripts con secretos a Git.

## Compilar y ejecutar

```bash
mvn clean compile
```

Abre `es.dam.jdbc.app.DemoConexion` y pulsa **Run Java** en VS Code (o ejecuta el `main` desde otro IDE). **No hay que pasar argumentos de entrada**: el programa intenta las tres conexiones consecutivamente, primero V1, V2 y V3, y muestra el resultado de cada una.

Cada conexión dispone de su propio `try/catch`: si falla V1, el programa continúa y prueba V2 y V3. `try-with-resources` cierra automáticamente cada conexión.

Para que V1 funcione, ajusta sus constantes a tu MySQL local de prácticas. Para V3, configura previamente `JDBC_PASSWORD` (y opcionalmente `JDBC_URL` y `JDBC_USER`) en el entorno desde el que se lanza Java. **Pulsar Run Java no garantiza que VS Code herede las variables definidas en una terminal abierta después de iniciar el editor**. Si falta la contraseña de V3, se mostrará un error explicativo; V1 puede seguir funcionando.

Para ejecutar desde Maven sin argumentos de programa:

```bash
mvn exec:java -Dexec.mainClass=es.dam.jdbc.app.DemoConexion
```

En PowerShell, si Maven interpreta mal `-D`, utiliza comillas alrededor de la opción: `"-Dexec.mainClass=es.dam.jdbc.app.DemoConexion"`.

## Organización del código

- `config/ConexionBD_V1.java`: conexión con constantes.
- `config/ConexionBD_V2.java`: conexión con `Properties` y `db.properties`.
- `config/ConexionBD_V3.java`: conexión con `System.getenv()`.
- `src/main/resources/db.properties.example`: plantilla pública, sin secretos reales.
- `config/ConexionBD.java`: **compatibilidad**; su método `abrir()` delega en V3 para no romper ejercicios anteriores.
- `app/DemoConexion.java`: ejecuta V1 V2 y V3 sucesivamente, sin argumentos, y usa `try-with-resources` para cerrar cada `Connection`.
- `sql/`: datos y esquema de prácticas.

## Preguntas de repaso

1. ¿Por qué `private static final` no protege una contraseña?
2. ¿Qué devuelve `System.getenv("JDBC_PASSWORD")` si no existe?
3. ¿Por qué V2 y V3 evitan contraseñas en el código fuente?
4. ¿Por qué `db.properties` debe estar excluido de Git?
5. ¿Qué sucede si ejecutas Java desde un IDE que no heredó las variables de PowerShell?
6. ¿Por qué no deberías incluir una contraseña de servidor en una aplicación de escritorio distribuida?

**Nota:** si una aplicación de escritorio o móvil necesita datos de un servidor, normalmente debe acceder a una API que gestione la conexión y las credenciales en el servidor, no distribuir la contraseña de la base de datos.
