package es.dam.jdbc.config;

import java.sql.Connection;
import java.sql.SQLException;

/** Compatibilidad con ejercicios anteriores: usa V3 (variables de entorno). */
public final class ConexionBD {
    private ConexionBD() { }
    public static Connection abrir() throws SQLException {
        return ConexionBD_V3.abrir();
    }
}
