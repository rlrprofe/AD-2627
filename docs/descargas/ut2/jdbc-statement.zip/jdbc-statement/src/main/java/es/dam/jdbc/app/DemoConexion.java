package es.dam.jdbc.app;

import java.sql.Connection;
import java.sql.SQLException;
import es.dam.jdbc.config.ConexionBD_V1;
import es.dam.jdbc.config.ConexionBD_V2;
import es.dam.jdbc.config.ConexionBD_V3;

/** Ejecuta tres ejemplos consecutivos con Run Java, sin argumentos de entrada. */
public class DemoConexion {
    public static void main(String[] args) {
        // Cada intento tiene su propio try/catch: un fallo no detiene los siguientes.
        System.out.println("=== V1: constantes Java (solo laboratorio) ===");
        try (Connection conexion = ConexionBD_V1.abrir()) {
            System.out.println("Conexión V1 correcta: " + !conexion.isClosed());
        } catch (SQLException e) {
            System.err.println("Error en V1: " + e.getMessage());
        }

        // Lee el archivo privado src/main/resources/db.properties.
        System.out.println("=== V2: archivo db.properties ===");
        try (Connection conexion = ConexionBD_V2.abrir()) {
            System.out.println("Conexión V2 correcta: " + !conexion.isClosed());
        } catch (SQLException e) {
            System.err.println("Error en V2: " + e.getMessage());
        }

        // Lee JDBC_URL, JDBC_USER y JDBC_PASSWORD del entorno del proceso.
        System.out.println("=== V3: variables de entorno ===");
        try (Connection conexion = ConexionBD_V3.abrir()) {
            System.out.println("Conexión V3 correcta: " + !conexion.isClosed());
        } catch (SQLException e) {
            System.err.println("Error en V3: " + e.getMessage());
        }
    }
}
