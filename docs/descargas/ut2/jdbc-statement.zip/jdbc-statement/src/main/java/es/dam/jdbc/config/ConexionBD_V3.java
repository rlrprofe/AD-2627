package es.dam.jdbc.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Centraliza la apertura de conexiones JDBC.
 * Lee los datos de conexión de variables de entorno para evitar guardar
 * credenciales en el código fuente o publicarlas en Git.
 */
public final class ConexionBD_V3 {

    // Clase de utilidades: no necesitamos crear objetos ConexionBD_V3.
    private ConexionBD_V3() { }

    /**
     * Abre una conexión MySQL con la configuración del entorno.
     *
     * @return conexión JDBC abierta (debe cerrarse con try-with-resources)
     * @throws SQLException si falta la contraseña o falla la conexión
     */
    public static Connection abrir() throws SQLException {
        // System es una clase de Java; getenv() sin argumentos devuelve un
        // Map<String, String> con las variables de entorno del proceso.
        // getOrDefault() es un método de Map: si JDBC_URL no existe,
        // utilizamos la dirección local de la base de datos de prácticas.
        String url = System.getenv().getOrDefault(
                "JDBC_URL", "jdbc:mysql://localhost:3306/curso");

        // Si JDBC_USER no está definido, el usuario predeterminado es alumno.
        String usuario = System.getenv().getOrDefault("JDBC_USER", "alumno");

        // getenv("NOMBRE") devuelve el valor de esa variable como String.
        // Si no existe, devuelve null. No asignamos una contraseña por defecto.
        String clave = System.getenv("JDBC_PASSWORD");

        // isBlank() comprueba si una cadena está vacía o contiene solo espacios.
        // Primero comprobamos null para evitar NullPointerException.
        if (clave == null || clave.isBlank()) {
            throw new SQLException(
                    "Falta JDBC_PASSWORD. Configura la variable de entorno antes de ejecutar.");
        }

        // DriverManager usa el driver MySQL incluido como dependencia Maven.
        // No imprimimos la contraseña ni la guardamos en ningún fichero.
        return DriverManager.getConnection(url, usuario, clave);
    }
}
