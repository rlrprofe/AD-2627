package es.dam.jdbc.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * V1: ejemplo introductorio con constantes.
 * ADVERTENCIA: las credenciales estan visibles en el codigo y en el JAR.
 * Usar UNICAMENTE una cuenta local de practicas, nunca claves reales.
 */
public final class ConexionBD_V1 {
    // final impide reasignar; NO cifra ni protege la contraseña.
    private static final String URL = "jdbc:mysql://localhost:3306/curso";
    private static final String USUARIO = "root";
    private static final String CLAVE = "Password1234"; // Sustituir solo en laboratorio local.

    private ConexionBD_V1() { }

    /** Abre una conexion; quien la recibe debe cerrarla. */
    public static Connection abrir() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }
}
