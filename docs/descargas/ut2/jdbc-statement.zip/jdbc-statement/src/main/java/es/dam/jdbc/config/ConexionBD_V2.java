package es.dam.jdbc.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/** V2: configuración externa mediante un archivo db.properties privado. */
public final class ConexionBD_V2 {
    private ConexionBD_V2() { }

    public static Connection abrir() throws SQLException {
        Properties propiedades = new Properties();

        // Busca db.properties en el classpath (src/main/resources en Maven).
        // El archivo real se excluye de Git: no debe contener credenciales publicadas.
        try (InputStream entrada = ConexionBD_V2.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (entrada == null) {
                throw new SQLException("No se encuentra db.properties. Copia db.properties.example "
                        + "a src/main/resources/db.properties y configura tu MySQL local.");
            }
            propiedades.load(entrada);
        } catch (IOException e) {
            throw new SQLException("No se ha podido leer db.properties", e);
        }

        String url = propiedades.getProperty("jdbc.url");
        String usuario = propiedades.getProperty("jdbc.user");
        String clave = propiedades.getProperty("jdbc.password");

        // Comprobamos los valores antes de intentar la conexión.
        if (url == null || url.isBlank() || usuario == null || usuario.isBlank()
                || clave == null || clave.isBlank()) {
            throw new SQLException("Faltan jdbc.url, jdbc.user o jdbc.password en db.properties");
        }
        return DriverManager.getConnection(url, usuario, clave);
    }
}
