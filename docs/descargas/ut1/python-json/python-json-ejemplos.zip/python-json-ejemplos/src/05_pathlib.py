from pathlib import Path

carpeta = Path("data")
ruta1 = carpeta / "alumnos.json"
ruta2 = carpeta.joinpath("alumnos.json")

print("Ruta con /:", ruta1)
print("Ruta con joinpath():", ruta2)
print("Directorio actual:", Path.cwd())
print("Ruta absoluta:", ruta1.resolve())
print("¿Existe?:", ruta1.exists())
print("¿Es fichero?:", ruta1.is_file())
print("¿data es directorio?:", carpeta.is_dir())
