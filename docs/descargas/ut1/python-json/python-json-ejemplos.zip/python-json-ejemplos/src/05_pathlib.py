"""Ejemplo 5. Construcción de rutas portables con pathlib."""
from pathlib import Path


def main() -> None:
    # No dependemos del directorio desde el que se ejecuta Python.
    raiz = Path(__file__).resolve().parent.parent
    carpeta = raiz / "data"
    ruta = carpeta / "alumnos.json"

    print("Ruta construida con /:", ruta)
    print("Ruta con joinpath():", carpeta.joinpath("alumnos.json"))
    print("Directorio de trabajo:", Path.cwd())
    print("Ruta absoluta:", ruta.resolve())
    print("¿Existe?:", ruta.exists())
    print("¿Es un fichero?:", ruta.is_file())
    print("¿data es un directorio?:", carpeta.is_dir())


if __name__ == "__main__":
    main()
