import json

def main():
    alumno = {"nombre": "Ana", "edad": 20}

    json_str = json.dumps(alumno, indent=4, ensure_ascii=False)
    print("Python -> JSON:")
    print(json_str)

    alumno2 = json.loads(json_str)
    print("\nJSON -> Python:")
    print(alumno2)
    print(f"Nombre: {alumno2['nombre']} - Edad: {alumno2['edad']}")

if __name__ == "__main__":
    main()
