"""Ejemplo 8. Convertir una dataclass a diccionario y JSON."""
import json
from dataclasses import asdict, dataclass


@dataclass
class Alumno:
    nombre: str
    edad: int
    nota: float


def main() -> None:
    original = Alumno("Ana", 20, 8.5)
    # asdict convierte la dataclass a un diccionario serializable.
    texto = json.dumps(asdict(original), indent=4, ensure_ascii=False)
    print("JSON:", texto)

    datos = json.loads(texto)
    # **datos desempaqueta las claves como argumentos del constructor.
    if not isinstance(datos, dict):
        raise ValueError("Se esperaba un objeto JSON.")
    recuperado = Alumno(**datos)
    print("Dataclass recuperada:", recuperado)


if __name__ == "__main__":
    main()
