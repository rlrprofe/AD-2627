import json
from dataclasses import dataclass, asdict

@dataclass
class Alumno:
    nombre: str
    edad: int
    nota: float

def main():
    alumno = Alumno("Ana", 20, 8.5)

    texto = json.dumps(
        asdict(alumno),
        indent=4,
        ensure_ascii=False
    )
    print(texto)

    datos = json.loads(texto)
    recuperado = Alumno(**datos)
    print(recuperado)

if __name__ == "__main__":
    main()
