import json
from datetime import date

def serializar(obj):
    if isinstance(obj, date):
        return obj.isoformat()
    raise TypeError(f"Tipo no serializable: {type(obj).__name__}")

def recuperar_fechas(diccionario):
    valor = diccionario.get("fecha_nacimiento")
    if valor is not None:
        diccionario["fecha_nacimiento"] = date.fromisoformat(valor)
    return diccionario

def main():
    alumno = {
        "nombre": "Ana",
        "fecha_nacimiento": date(2005, 3, 15)
    }

    texto = json.dumps(
        alumno,
        default=serializar,
        indent=4,
        ensure_ascii=False
    )
    print(texto)

    recuperado = json.loads(texto, object_hook=recuperar_fechas)
    print(recuperado)
    print(type(recuperado["fecha_nacimiento"]))

if __name__ == "__main__":
    main()
