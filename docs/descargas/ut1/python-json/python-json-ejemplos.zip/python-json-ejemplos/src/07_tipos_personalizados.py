"""Ejemplo 7. Conversión de date mediante default y object_hook."""
import json
from datetime import date


def serializar(objeto: object) -> str:
    """JSON no admite date: lo representamos como texto ISO 8601."""
    if isinstance(objeto, date):
        return objeto.isoformat()
    raise TypeError(f"Tipo no serializable: {type(objeto).__name__}")


def recuperar_fechas(diccionario: dict) -> dict:
    """object_hook recibe cada objeto JSON; solo transformamos nuestra clave."""
    valor = diccionario.get("fecha_nacimiento")
    if isinstance(valor, str):
        try:
            diccionario["fecha_nacimiento"] = date.fromisoformat(valor)
        except ValueError:
            # Si no es una fecha válida, dejamos el texto original.
            pass
    return diccionario


def main() -> None:
    alumno = {"nombre": "Ana", "fecha_nacimiento": date(2005, 3, 15)}
    texto = json.dumps(alumno, default=serializar, indent=4, ensure_ascii=False)
    print("JSON:", texto)
    recuperado = json.loads(texto, object_hook=recuperar_fechas)
    print("Objeto recuperado:", recuperado)
    print("Tipo de fecha:", type(recuperado["fecha_nacimiento"]).__name__)


if __name__ == "__main__":
    main()
