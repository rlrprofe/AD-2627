import json
from pathlib import Path

def main():
    alumnos = [
        {"nombre": "Ana", "edad": 20},
        {"nombre": "Luis", "edad": 22},
        {"nombre": "Marta", "edad": 19}
    ]

    data_dir = Path("data")
    data_dir.mkdir(parents=True, exist_ok=True)
    fichero = data_dir / "alumnos.json"

    with fichero.open("w", encoding="utf-8") as f:
        json.dump(alumnos, f, indent=4, ensure_ascii=False)

    print(f"Fichero creado correctamente en: {fichero.resolve()}")

if __name__ == "__main__":
    main()
