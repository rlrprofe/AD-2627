"""Ejemplo 3. Guardar una lista de diccionarios como JSON (UTF-8)."""
import json
from pathlib import Path

# __file__ permite ejecutar el ejemplo desde cualquier directorio de trabajo.
RUTA_DATOS = Path(__file__).resolve().parent.parent / "data" / "alumnos.json"


def main() -> None:
    alumnos = [
        {"nombre": "Ana", "edad": 20},
        {"nombre": "Luis", "edad": 22},
        {"nombre": "Marta", "edad": 19},
    ]

    try:
        RUTA_DATOS.parent.mkdir(parents=True, exist_ok=True)
        # with cierra el fichero incluso si se produce una excepción.
        with RUTA_DATOS.open("w", encoding="utf-8") as fichero:
            json.dump(alumnos, fichero, indent=4, ensure_ascii=False)
    except OSError as error:
        print(f"No se pudieron guardar los alumnos: {error}")
        return

    print(f"Fichero guardado en: {RUTA_DATOS}")


if __name__ == "__main__":
    main()
