import json
from pathlib import Path

def main():
    fichero = Path("data/alumnos.json")

    if not fichero.exists():
        print("El fichero no existe. Ejecuta primero 03_guardar_alumnos.py")
        return

    with fichero.open("r", encoding="utf-8") as f:
        alumnos = json.load(f)

    print("Alumnos leídos desde el fichero:")
    for alumno in alumnos:
        nombre = alumno.get("nombre", "(sin nombre)")
        edad = alumno.get("edad", "(sin edad)")
        print(f"- {nombre} ({edad} años)")

if __name__ == "__main__":
    main()
