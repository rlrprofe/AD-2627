"""Ejemplo 4. Leer JSON, validar su estructura y mostrar los alumnos."""
import json
from pathlib import Path

RUTA_DATOS = Path(__file__).resolve().parent.parent / "data" / "alumnos.json"


def main() -> None:
    try:
        with RUTA_DATOS.open("r", encoding="utf-8") as fichero:
            alumnos = json.load(fichero)
    except FileNotFoundError:
        print("No existe alumnos.json. Ejecuta antes 03_guardar_alumnos.py.")
        return
    except json.JSONDecodeError as error:
        print(f"El fichero contiene JSON incorrecto: {error}")
        return
    except (OSError, UnicodeError) as error:
        print(f"No se pudo leer el fichero: {error}")
        return

    # Un JSON válido no tiene por qué ser una lista de alumnos.
    if not isinstance(alumnos, list):
        print("Formato inesperado: se esperaba una lista.")
        return

    print("Alumnos leídos:")
    for alumno in alumnos:
        if not isinstance(alumno, dict):
            print("- Entrada no válida: se esperaba un objeto JSON.")
            continue
        print(f"- {alumno.get('nombre', '(sin nombre)')} "
              f"({alumno.get('edad', '(sin edad)')} años)")


if __name__ == "__main__":
    main()
