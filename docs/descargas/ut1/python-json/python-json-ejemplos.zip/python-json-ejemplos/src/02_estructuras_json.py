import json

def main():
    curso = {
        "nombre": "2º DAM",
        "activo": True,
        "tutor": None,
        "alumnos": [
            {"nombre": "Ana", "notas": [8.5, 7.2, 9.1]},
            {"nombre": "Luis", "notas": [6.0, 7.5, 8.0]}
        ]
    }

    texto = json.dumps(curso, indent=4, ensure_ascii=False)
    print(texto)

    copia = json.loads(texto)
    for alumno in copia["alumnos"]:
        print(alumno["nombre"], alumno["notas"])

if __name__ == "__main__":
    main()
