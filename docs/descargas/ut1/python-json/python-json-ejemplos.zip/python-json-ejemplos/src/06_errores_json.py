"""Ejemplo 6. Manejo de errores de lectura y sintaxis JSON."""
import json
from pathlib import Path

RUTA_DATOS = Path(__file__).resolve().parent.parent / "data" / "alumnos.json"


def leer_json(ruta: Path) -> object | None:
    """Devuelve el contenido o None si no se puede leer.

    Atención: None también es un valor JSON válido (`null`). Para una API
    de producción convendría diferenciar éxito y error de otro modo.
    """
    try:
        with ruta.open("r", encoding="utf-8") as fichero:
            return json.load(fichero)
    except FileNotFoundError:
        print(f"No existe el fichero: {ruta}")
    except json.JSONDecodeError as error:
        print(f"JSON incorrecto en línea {error.lineno}: {error.msg}")
    except (OSError, UnicodeError) as error:
        print(f"Error de lectura: {error}")
    return None


def main() -> None:
    datos = leer_json(RUTA_DATOS)
    if datos is not None:
        print(datos)


if __name__ == "__main__":
    main()
