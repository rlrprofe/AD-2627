import json
from pathlib import Path

def leer_json(ruta):
    try:
        with ruta.open("r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print("No existe el fichero.")
    except json.JSONDecodeError as e:
        print("El fichero no contiene JSON válido.")
        print(e)
    except OSError as e:
        print("Error de acceso al fichero:", e)
    return None

if __name__ == "__main__":
    datos = leer_json(Path("data/alumnos.json"))
    if datos is not None:
        print(datos)
