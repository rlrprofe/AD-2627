# JSON con Python — guía de estudio (UT1, Acceso a Datos)

Este proyecto utiliza **solo la biblioteca estándar de Python** (`json`, `pathlib`, `datetime`, `dataclasses`). No necesitas instalar paquetes con `pip`.

## Preparación y ejecución

Abre la carpeta `python-json-ejemplos` en VS Code. Comprueba la versión:

```bash
python --version
```

Ejecuta cada programa desde la raíz del proyecto:

```bash
python src/01_basico_en_memoria.py
```

En algunos equipos Linux se utiliza `python3` en lugar de `python`. Los ejemplos de ficheros calculan la ruta de `data/` a partir de `__file__`, por lo que funcionan aunque se ejecuten desde otra carpeta.

## Orden didáctico recomendado

| Paso | Programa | Qué debes aprender | Resultado |
|---|---|---|---|
| 1 | `01_basico_en_memoria.py` | `json.dumps()` y `json.loads()`: texto JSON y objetos Python | Muestra un alumno y su recuperación |
| 2 | `02_estructuras_json.py` | Diccionarios, listas, `True`, `None`, datos anidados | Muestra un curso con alumnos |
| 3 | `03_guardar_alumnos.py` | `json.dump()`, UTF-8, `with`, escritura en disco | Genera `data/alumnos.json` |
| 4 | `04_leer_alumnos.py` | `json.load()`, errores y comprobación de tipos | Lee y muestra la lista |
| 5 | `05_pathlib.py` | `Path`, operador `/`, rutas absolutas y existencia | Muestra información de rutas |
| 6 | `06_errores_json.py` | `JSONDecodeError`, `FileNotFoundError`, `OSError` | Lee el JSON o informa de errores |
| 7 | `07_tipos_personalizados.py` | `date`, `default=` y `object_hook` | Fecha ISO 8601 y recuperación |
| 8 | `08_dataclass_json.py` | `@dataclass`, `asdict()` y constructor con `**datos` | Reconstruye un `Alumno` |

**Ejecuta el paso 3 antes del 4** para generar el fichero que después se leerá. El proyecto incluye un `data/alumnos.json` de muestra, pero puedes regenerarlo.

## Estructura

```text
python-json-ejemplos/
├── README.md
├── data/
│   ├── alumno.json
│   └── alumnos.json
└── src/
    ├── 01_basico_en_memoria.py
    ├── 02_estructuras_json.py
    ├── 03_guardar_alumnos.py
    ├── 04_leer_alumnos.py
    ├── 05_pathlib.py
    ├── 06_errores_json.py
    ├── 07_tipos_personalizados.py
    └── 08_dataclass_json.py
```

Los ocho ejemplos son **independientes y progresivos**. No se fuerza un patrón MVC: su objetivo es aprender la API `json` de Python y practicar el acceso a ficheros con responsabilidades claras.

## Buenas prácticas para observar

- `if __name__ == "__main__":` evita ejecutar la demostración al importar el módulo.
- `with ... open(..., encoding="utf-8")` cierra el fichero automáticamente.
- `ensure_ascii=False` conserva los caracteres españoles en la salida.
- `Path(__file__).resolve().parent.parent` localiza la carpeta del proyecto.
- `try`/`except` distingue errores de lectura y errores de sintaxis JSON.
- `isinstance()` comprueba que el JSON leído tiene la estructura esperada.
- `default` y `object_hook` son transformaciones explícitas, no mágicas.

## Preguntas de autoevaluación

1. ¿Qué diferencia hay entre `dump` y `dumps`, y entre `load` y `loads`?
2. ¿Por qué usamos `with` al trabajar con ficheros?
3. ¿Qué ocurre si `alumnos.json` contiene un objeto `{}` en vez de una lista `[]`?
4. ¿Por qué un objeto `date` no puede serializarse directamente?
5. ¿Qué diferencia existe entre un diccionario y una `dataclass`?

**Práctica:** añade un cuarto alumno en `03_guardar_alumnos.py`, ejecuta los pasos 3 y 4 y comprueba que se recupera correctamente.
