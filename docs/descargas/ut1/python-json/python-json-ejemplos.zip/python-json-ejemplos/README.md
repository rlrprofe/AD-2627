# JSON con Python - ejemplos

Proyecto de ejemplos para el minicurso de JSON con Python de Acceso a Datos (2º DAM).

No requiere dependencias externas: utiliza `json`, `pathlib`, `datetime` y `dataclasses` de la librería estándar.

## Orden recomendado

1. `01_basico_en_memoria.py`
2. `02_estructuras_json.py`
3. `03_guardar_alumnos.py`
4. `04_leer_alumnos.py`
5. `05_pathlib.py`
6. `06_errores_json.py`
7. `07_tipos_personalizados.py`
8. `08_dataclass_json.py`

Ejecuta los programas desde la carpeta raíz del proyecto.
