# Conversión XML ↔ JSON — proyecto Maven Java 21

## Proyecto manual

Estudia los ejemplos en este orden:

1. `xmltojson/XmlToJsonManual1.java`: DOM → lista de mapas → Gson → JSON.
2. `xmltojson/XmlToJsonManual2.java`: DOM + XPath → JSON.
3. `xmltojson/handlers/ClienteHandler.java` y `xmltojson/XmlToJsonManual3.java`: SAX → JSON.
4. `jsontoxml/JsonToXmlManual1.java`: Gson → DOM → XML.
5. `jsontoxml/JsonToXmlManual2_Recursivo.java`: conversión de estructuras anidadas.

## Preparación

- Abre esta carpeta (donde está `pom.xml`) en VS Code.
- Utiliza JDK 21 y Maven. Compila con `mvn clean compile`.
- Ejecuta cada clase desde VS Code con la **carpeta raíz como directorio de trabajo**: los ejemplos originales utilizan rutas relativas como `resources/clientes.xml` y `resources/clientes.json`.
- Las salidas se guardan en la carpeta `salida/`.
- Los ficheros de entrada incluyen Laura (30) y Pedro (25).

## Buenas prácticas y limitaciones

- Los ejemplos conservan sus nombres originales para corresponderse con los apuntes.
- Maven utiliza Java 21; se ha reforzado la configuración XXE de los analizadores DOM/SAX existentes.
- Las lecturas de JSON con `FileReader` se han sustituido por lectores UTF-8.
- Son demostraciones didácticas, no un convertidor universal. Los atributos, arrays, números, `null` y estructuras anidadas requieren decisiones de mapeo.
- La conversión por modelo no es totalmente automática: requiere definir las clases y anotaciones JAXB.
- Antes de usar XML de fuentes externas con JAXB, configura un analizador seguro y verifica la validación de entrada.
