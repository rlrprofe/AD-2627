import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class DemoBytes {
    public static void main(String[] args) {
        try {
            // 1) writeInt
            try (RandomAccessFile raf = new RandomAccessFile("int123.dat", "rw")) {
                raf.setLength(0); // vaciar fichero
                raf.writeInt(123);
            }

            // 2) writeUTF
            try (RandomAccessFile raf = new RandomAccessFile("utf123.dat", "rw")) {
                raf.setLength(0);
                raf.writeUTF("123");
            }

            // 3) FileWriter
            try (FileWriter fw = new FileWriter("texto123.txt")) {
                fw.write("123");
            }

            // Mostrar bytes en consola
            mostrarBytes("int123.dat");
            mostrarBytes("utf123.dat");
            mostrarBytes("texto123.txt");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método auxiliar para mostrar bytes en hexadecimal
    private static void mostrarBytes(String fichero) throws IOException {
        byte[] bytes = Files.readAllBytes(Path.of(fichero));
        System.out.print(fichero + " → ");
        for (byte b : bytes) {
            System.out.printf("%02X ", b);
        }
        System.out.println();
    }
}
