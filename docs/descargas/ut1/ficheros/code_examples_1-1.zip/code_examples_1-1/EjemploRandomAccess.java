/* Ejemplo1 RandomAccess
 * 
 * Permite leer y escribir en cualquier parte del fichero.
 * Aquí lo hemos usado de manera sencilla: escribir → volver al inicio → leer.
 * Los datos se almacenan en binario, no como texto legible.
 * La lectura debe seguir el mismo orden que la escritura, porque si no, los bytes no coinciden.
 * 
 */


import java.io.RandomAccessFile;
import java.io.IOException;


public class EjemploRandomAccess {
    public static void main(String[] args) {
        //Aquí se abre (o crea si no existe) el fichero datos.dat con permiso de lectura y escritura ("rw")
        try (RandomAccessFile raf = new RandomAccessFile("datos.dat", "rw")) {
            // Escritura
            raf.writeInt(101);          // ocupa 4 bytes
            raf.writeUTF("Pedro");      // escribe cadena en formato UTF
            raf.writeDouble(8.5);       // ocupa 8 bytes

            // Volver al inicio del fichero
            raf.seek(0); //mueve el puntero de lectura/escritura al byte 0 del fichero

            // Lectura
            int id = raf.readInt();
            String nombre = raf.readUTF();
            double nota = raf.readDouble();

            System.out.println("ID: " + id + ", Nombre: " + nombre + ", Nota: " + nota);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
/*
 * El objeto raf se crea dentro del paréntesis.

        -Cuando termina el bloque try, Java lo cierra automáticamente (close()), aunque haya excepciones.
        -Es la forma más segura y moderna (desde Java 7).
        -Inconveniente: el objeto queda limitado al bloque try, no se puede usar fuera.
 * 
 * Escritura:
 * 
 * Estamos escribiendo tres valores seguidos en binario dentro del fichero:
        -writeInt(101) → escribe 4 bytes que representan el número 101 en binario.
        -writeUTF("Pedro") → escribe la cadena "Pedro" en formato UTF:
            *Primero escribe 2 bytes con la longitud (en UTF).
            *Después escribe cada carácter.
        -writeDouble(8.5) → escribe 8 bytes con el número 8.5 en formato IEEE 754.
    En total, en el fichero datos.dat queda algo así (simplificado):
        [ 4 bytes int ][ 2 bytes longitud ][ caracteres "Pedro" ][ 8 bytes double ]

  *
  * Lectura
  * Leemos los valores en el mismo orden en que se escribieron:

        -readInt() → lee los primeros 4 bytes → devuelve 101.
        -readUTF() → lee primero la longitud (que se guardó automáticamente al escribir) y luego los caracteres → devuelve "Pedro".
        -readDouble() → lee los siguientes 8 bytes → devuelve 8.5.
    Si no los leyéramos en el mismo orden, la lectura se desincronizaría y saldrían datos corruptos.
 */

 /*  ¿Qué sucede si ejecutas varias veces?

    El fichero guarda:
    1ª ejecución -- [101][Pedro][8.5]
    2ª ejecución -- [101][Pedro][8.5][101][Pedro][8.5]
    3ª ejecución -- [101][Pedro][8.5][101][Pedro][8.5][101][Pedro][8.5]

    En código actual solo se lee el primer bloque

    1) Podemos sobreescribir el contenido cuando ejecutemos más de una vez
        RandomAccessFile raf = new RandomAccessFile("datos.dat", "rw");
        raf.setLength(0); // borra contenido anterior
    2) Si queremos ir añadiendo registros y leugo mostrar más la lectura debería ser:
        un bucle de lectura hasta llegar al final del fichero 
        (while(raf.getFilePointer() < raf.length())).

  */