/* Ejemplo2 RandomAccess
 * 
 * Versión 2 Sobreescribir el fichero en cada ejecución
 * 
 */


import java.io.RandomAccessFile;
import java.io.IOException;


public class Ejemplo2RandomAccess {
    public static void main(String[] args) {
        //Aquí se abre (o crea si no existe) el fichero datos.dat con permiso de lectura y escritura ("rw")
        try (RandomAccessFile raf = new RandomAccessFile("datos.dat", "rw")) {
            
            //Sobreescribe el fichero antes de escribir
            raf.setLength(0); // borra el contenido previo
            raf.seek(0); //vamos al inicio (opcional)

            // Escritura
            raf.writeInt(101);          // ocupa 4 bytes
            raf.writeUTF("Pedro");      // escribe cadena en formato UTF
            raf.writeDouble(8.5);       // ocupa 8 bytes

            // Volver al inicio del fichero
            raf.seek(0); //mueve el puntero de lectura/escritura al byte 0 del fichero

            // Lectura
            int id = raf.readInt();
            String nombre = raf.readUTF();
            double nota = raf.readDouble();

            System.out.println("ID: " + id + ", Nombre: " + nombre + ", Nota: " + nota);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
/* ¿Qué estas haciendo ahora?

 * raf.setLength(0): limpia el fichero datos.dat al arrancar, de modo que siempre empiezas desde cero.
   Escribes el registro (id, nombre, nota).
   Lees desde el principio y lo muestra

   el fichero no crece entre ejecuciones, porque lo vacías cada vez.
 */