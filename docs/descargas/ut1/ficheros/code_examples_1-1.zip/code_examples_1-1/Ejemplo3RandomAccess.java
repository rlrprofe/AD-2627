/* Ejemplo3 RandomAccess
 * 
 * Versión 3: con un boolean poder elegir si "sobreescribir" o "añadir"
 * 
 */

import java.io.IOException;
import java.io.RandomAccessFile;

public class Ejemplo3RandomAccess {
    public static void main(String[] args) {
        boolean sobrescribir = false; //  false para añadir y true para sobreescribir

        try (RandomAccessFile raf = new RandomAccessFile("datos.dat", "rw")) {

            if (sobrescribir) {
                raf.setLength(0);     // limpia el fichero
                raf.seek(0);
            } else {
                raf.seek(raf.length());  // saltar al final para añadir
            }

            // Escribir un registro
            raf.writeInt(101);
            raf.writeUTF("Pedro");
            raf.writeDouble(8.5);

            // Mostrar todo el contenido (listar registros)
            raf.seek(0);
            while (raf.getFilePointer() < raf.length()) {
                int id = raf.readInt();
                String nombre = raf.readUTF();
                double nota = raf.readDouble();
                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Nota: " + nota);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
