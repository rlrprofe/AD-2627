package com.example;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class LeerAlumnosGson {
    public static void main(String[] args) {
        Gson gson = new Gson();
        Path ruta = Path.of("data", "alumnos.json");

        Type tipo = new TypeToken<List<Alumno>>() {}.getType();

        try (FileReader reader = new FileReader(ruta.toFile())) {
            List<Alumno> alumnos = gson.fromJson(reader, tipo);

            System.out.println("Alumnos leídos:");
            for (Alumno alumno : alumnos) {
                System.out.println(alumno);
            }

        } catch (IOException e) {
            System.err.println("Error al leer el fichero: " + e.getMessage());
        }
    }
}
