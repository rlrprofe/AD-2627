package com.example;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GuardarAlumnosGson {
    public static void main(String[] args) {
        List<Alumno> alumnos = new ArrayList<>();
        alumnos.add(new Alumno(1, "Ana", 8.5));
        alumnos.add(new Alumno(2, "Luis", 7.2));
        alumnos.add(new Alumno(3, "Marta", 9.1));

        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        Path directorio = Path.of("data");
        Path ruta = directorio.resolve("alumnos.json");

        try {
            Files.createDirectories(directorio);

            try (FileWriter writer = new FileWriter(ruta.toFile())) {
                gson.toJson(alumnos, writer);
            }

            System.out.println("Fichero guardado en:");
            System.out.println(ruta.toAbsolutePath());

        } catch (IOException e) {
            System.err.println("Error al guardar el fichero: " + e.getMessage());
        }
    }
}
