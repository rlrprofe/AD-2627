package com.example;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class DemoListaGson {
    public static void main(String[] args) {
        List<Alumno> alumnos = new ArrayList<>();
        alumnos.add(new Alumno(1, "Ana", 8.5));
        alumnos.add(new Alumno(2, "Luis", 7.2));
        alumnos.add(new Alumno(3, "Marta", 9.1));

        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        String json = gson.toJson(alumnos);
        System.out.println("JSON generado:");
        System.out.println(json);

        Type tipo = new TypeToken<List<Alumno>>() {}.getType();
        List<Alumno> recuperados = gson.fromJson(json, tipo);

        System.out.println("\nAlumnos recuperados:");
        for (Alumno alumno : recuperados) {
            System.out.println(alumno);
        }
    }
}
