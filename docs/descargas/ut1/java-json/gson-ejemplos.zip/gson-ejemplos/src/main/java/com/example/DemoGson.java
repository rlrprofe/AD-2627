package com.example;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class DemoGson {
    public static void main(String[] args) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        Alumno original = new Alumno(1, "Ana", 8.5);

        String json = gson.toJson(original);
        System.out.println("JSON generado:");
        System.out.println(json);

        Alumno recuperado = gson.fromJson(json, Alumno.class);
        System.out.println("\nAlumno recuperado:");
        System.out.println(recuperado);
    }
}
