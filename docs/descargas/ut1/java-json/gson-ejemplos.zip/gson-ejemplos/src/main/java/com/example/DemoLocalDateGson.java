package com.example;

import java.time.LocalDate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class DemoLocalDateGson {
    public static void main(String[] args) {
        Alumno alumno = new Alumno(
                1,
                "Ana",
                8.5,
                LocalDate.of(2005, 3, 15)
        );

        Gson gson = new GsonBuilder()
                .registerTypeAdapter(LocalDate.class, new LocalDateAdapter())
                .setPrettyPrinting()
                .create();

        String json = gson.toJson(alumno);

        System.out.println("JSON generado:");
        System.out.println(json);

        Alumno recuperado = gson.fromJson(json, Alumno.class);

        System.out.println("\nAlumno recuperado:");
        System.out.println(recuperado);
    }
}
