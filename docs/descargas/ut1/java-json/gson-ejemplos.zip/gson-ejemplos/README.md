# Ejemplos Gson - Acceso a Datos 2º DAM

Proyecto Maven de apoyo al minicurso de Gson.

## Requisitos
- JDK 21
- Maven
- Gson 2.11.0

## Ejemplos
1. `Alumno.java` — modelo de datos común.
2. `DemoGson.java` — serialización y deserialización de un objeto.
3. `DemoListaGson.java` — colecciones y `TypeToken`.
4. `GuardarAlumnosGson.java` — escritura de una lista en `data/alumnos.json`.
5. `LeerAlumnosGson.java` — lectura del fichero como `List<Alumno>`.
6. `LocalDateAdapter.java` — serializador/deserializador personalizado para `LocalDate`.
7. `DemoLocalDateGson.java` — uso del adaptador de `LocalDate`.

## Orden recomendado
Ejecuta primero `DemoGson`, después `DemoListaGson`.
Para persistencia, ejecuta `GuardarAlumnosGson` antes de `LeerAlumnosGson`.
Finalmente ejecuta `DemoLocalDateGson`.

El `pom.xml` utiliza `<maven.compiler.release>21</maven.compiler.release>`.
