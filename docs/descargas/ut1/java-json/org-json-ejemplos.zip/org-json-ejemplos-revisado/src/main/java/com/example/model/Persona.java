package com.example.model;

/** Entidad de dominio independiente de la biblioteca JSON. */
public class Persona {
    private final String nombre;
    private final int edad;

    public Persona(String nombre, int edad) {
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Nombre obligatorio");
        if (edad < 0) throw new IllegalArgumentException("Edad no válida");
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    @Override public String toString() { return nombre + " (" + edad + " años)"; }
}
