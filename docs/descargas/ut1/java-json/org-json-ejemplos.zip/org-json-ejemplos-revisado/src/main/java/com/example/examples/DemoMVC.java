package com.example.examples;

import com.example.controller.PersonaController;
import com.example.repository.PersonaJsonRepository;
import com.example.view.PersonaConsoleView;
import java.nio.file.Path;

/** Ejemplo adicional: flujo modelo-vista-controlador con repositorio JSON. */
public class DemoMVC {
    public static void main(String[] args) {
        PersonaJsonRepository repo = new PersonaJsonRepository(Path.of("data", "personas-mvc.json"));
        new PersonaController(repo, new PersonaConsoleView()).ejecutar();
    }
}
