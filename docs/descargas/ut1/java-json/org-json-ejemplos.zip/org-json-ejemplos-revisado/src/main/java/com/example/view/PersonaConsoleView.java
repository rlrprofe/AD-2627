package com.example.view;

import com.example.model.Persona;
import java.util.List;

/** Vista de consola: no conoce los detalles del almacenamiento JSON. */
public class PersonaConsoleView {
    public void mostrar(List<Persona> personas) {
        System.out.println("Personas recuperadas del fichero:");
        personas.forEach(System.out::println);
    }
    public void mostrarError(String mensaje) { System.err.println(mensaje); }
}
