package com.example.examples;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

public class GuardarJSONv2 {

    public static void main(String[] args) {
        // Scanner para leer datos desde teclado
        Scanner sc = new Scanner(System.in);

        // JSONArray que contendrá todos los objetos persona
        JSONArray listaPersonas = new JSONArray();

        System.out.println("Introduce personas (nombre y edad). Para terminar escribe 'fin' en el nombre.");

        // Pedimos el primer nombre fuera del bucle
        System.out.print("Nombre: ");
        String nombre = sc.nextLine().trim();

        // Mientras el usuario no escriba "fin", seguimos pidiendo datos
        while (!nombre.equalsIgnoreCase("fin")) {
            // Pedimos la edad asociada al nombre
            System.out.print("Edad: ");
            int edad;
            try {
                edad = Integer.parseInt(sc.nextLine().trim());
                if (edad < 0) {
                    System.out.println("La edad no puede ser negativa.");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Introduce una edad numérica válida.");
                continue;
            }

            // Creamos un objeto JSON para cada persona
            JSONObject persona = new JSONObject();
            persona.put("nombre", nombre); // clave "nombre"
            persona.put("edad", edad);     // clave "edad"

            // Añadimos la persona al array de personas
            listaPersonas.put(persona);

            // Volvemos a pedir un nombre (puede ser otro o "fin" para terminar)
            System.out.print("Nombre: ");
            nombre = sc.nextLine().trim();
        }

        // Al salir del bucle comprobamos si se introdujeron personas
        if (listaPersonas.isEmpty()) {
            // Si el array está vacío → no se creó ninguna persona
            System.out.println("No se introdujo ninguna persona. No se creó el fichero.");
        } else {
            
           // Crear una carpeta data/ para ficheros generados
            


            // Si hay personas, las guardamos en el fichero JSON
            try {
                Files.createDirectories(Path.of("data"));
                try (BufferedWriter file = Files.newBufferedWriter(Path.of("data/personas.json"), StandardCharsets.UTF_8)) {
                // toString(4) genera un JSON con formato indentado (4 espacios)
                file.write(listaPersonas.toString(4));
                System.out.println("Fichero personas.json creado con éxito.");
            }
        } catch (IOException e) {
                // En caso de error al escribir en disco
                System.err.println("Error al guardar JSON: " + e.getMessage());
            }
        }

        // Cerramos el Scanner
        // No cerramos System.in: pertenece a la aplicación, no a este ejemplo.
    }
}
