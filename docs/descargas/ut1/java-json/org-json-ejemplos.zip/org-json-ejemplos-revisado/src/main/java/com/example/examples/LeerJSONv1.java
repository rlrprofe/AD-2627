/* Lectura */
package com.example.examples;



import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import java.io.IOException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class LeerJSONv1 {
    public static void main(String[] args) {
        // Ruta del fichero 
        String ruta = "data/persona.json";

        try (BufferedReader reader = Files.newBufferedReader(Path.of(ruta), StandardCharsets.UTF_8)) {
            // JSONTokener convierte el flujo de caracteres en datos JSON
            JSONTokener tokener = new JSONTokener(reader);

            // Creamos el objeto JSONObject a partir del fichero
            JSONObject obj = new JSONObject(tokener);

            // Accedemos a las claves
            String nombre = obj.getString("nombre");
            int edad = obj.getInt("edad");

            // Mostrar por consola
            System.out.println("Contenido del JSON:");
            System.out.println("Nombre: " + nombre);
            System.out.println("Edad: " + edad);

        } catch (JSONException e) {
            System.err.println("JSON no válido: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Error al leer el fichero JSON: " + e.getMessage());
        }
    }
}

