package com.example.repository;

import com.example.model.Persona;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/** Traduce entre el modelo Persona y un fichero JSON. */
public class PersonaJsonRepository {
    private final Path ruta;
    public PersonaJsonRepository(Path ruta) { this.ruta = ruta; }

    public void guardar(List<Persona> personas) throws IOException {
        JSONArray array = new JSONArray();
        for (Persona persona : personas) {
            JSONObject objeto = new JSONObject();
            objeto.put("nombre", persona.getNombre());
            objeto.put("edad", persona.getEdad());
            array.put(objeto);
        }
        Path directorio = ruta.getParent();
        if (directorio != null) Files.createDirectories(directorio);
        // try-with-resources cierra el escritor incluso ante una excepción.
        try (BufferedWriter writer = Files.newBufferedWriter(ruta, StandardCharsets.UTF_8)) {
            writer.write(array.toString(4));
        }
    }

    public List<Persona> leer() throws IOException {
        List<Persona> resultado = new ArrayList<>();
        // El JSONTokener interpreta el flujo de caracteres como JSON.
        try (BufferedReader reader = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            JSONArray array = new JSONArray(new JSONTokener(reader));
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                resultado.add(new Persona(obj.getString("nombre"), obj.getInt("edad")));
            }
        }
        return resultado;
    }
}
