package com.example.controller;

import com.example.model.Persona;
import com.example.repository.PersonaJsonRepository;
import com.example.view.PersonaConsoleView;
import java.io.IOException;
import java.util.List;
import org.json.JSONException;

/** Coordina modelo, persistencia y vista sin mezclar sus responsabilidades. */
public class PersonaController {
    private final PersonaJsonRepository repositorio;
    private final PersonaConsoleView vista;
    public PersonaController(PersonaJsonRepository repositorio, PersonaConsoleView vista) {
        this.repositorio = repositorio;
        this.vista = vista;
    }
    public void ejecutar() {
        try {
            List<Persona> personas = List.of(new Persona("Ana", 25), new Persona("Luis", 30));
            repositorio.guardar(personas);
            vista.mostrar(repositorio.leer());
        } catch (IOException | JSONException | IllegalArgumentException e) {
            vista.mostrarError("No se pudo completar el ejemplo: " + e.getMessage());
        }
    }
}
