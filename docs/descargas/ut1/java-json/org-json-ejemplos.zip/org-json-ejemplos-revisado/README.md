# Ejemplos de org.json (Java 21)

Proyecto Maven revisado. Se conservan las 11 clases originales, ahora en `com.example.examples`, y se añade `DemoMVC` para mostrar separación de responsabilidades.

## Paquetes

- `examples`: ejemplos didácticos de JSONObject, JSONArray, JSONTokener, lectura y escritura.
- `model`: entidad `Persona` independiente de org.json.
- `repository`: conversión y persistencia JSON con `Path`, `Files`, UTF-8 y try-with-resources.
- `controller`: coordinación del caso de uso.
- `view`: presentación en consola.

## Ejecución

Abre el directorio que contiene `pom.xml` en VS Code con JDK 21. Ejecuta cualquier clase de `com.example.examples` con su método `main`. Para el flujo MVC ejecuta `DemoMVC`. Los ficheros se leen o escriben en `data/`, relativo al directorio de trabajo del proyecto.

`GuardarJSONv1` / `LeerJSONv1` trabajan con `persona.json`; `GuardarJSONv2` / `LeerJSONv2` con `personas.json`. `DemoMVC` utiliza `personas-mvc.json` para no sobrescribir los datos de los otros ejemplos.

## Notas didácticas

`JSONObject` y `JSONArray` son estructuras de la librería, no entidades del modelo MVC. Las demostraciones básicas permanecen autocontenidas para facilitar su estudio. En los ejemplos de E/S se emplea `try-with-resources`; no es necesario para objetos JSON en memoria.
