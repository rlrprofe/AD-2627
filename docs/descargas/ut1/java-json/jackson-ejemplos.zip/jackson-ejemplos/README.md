# Jackson — Guía didáctica de los ejemplos (Java 21)

Este proyecto Maven reúne ejemplos de **serialización y deserialización JSON con Jackson**. Se recomienda estudiarlos **en el orden indicado**, no por orden alfabético. Las clases de `app` contienen los métodos `main` que puedes ejecutar desde VS Code.

## Antes de empezar

1. Abre la carpeta del proyecto (la que contiene `pom.xml`) en VS Code.
2. Comprueba que utilizas **JDK 21** y que Maven reconoce las dependencias.
3. Si quieres comprobar la compilación desde la terminal, ejecuta `mvn clean compile`.

## Orden didáctico recomendado

| Paso | Archivo | Qué debes observar | ¿Se ejecuta? |
| --- | --- | --- | --- |
| 1 | `model/Alumno.java` | Modelo POJO: atributos, constructor vacío, constructor con parámetros, getters y setters. Por ahora, observa las anotaciones sin estudiarlas en profundidad. | No |
| 2 | `config/JacksonConfig.java` | Configuración compartida de `ObjectMapper`, el objeto principal de Jackson para trabajar con JSON. | No |
| 3 | `app/DemoJackson.java` | Conversión de un objeto Java a texto JSON (**serialización**) y recuperación de un objeto desde JSON (**deserialización**). | Sí |
| 4 | `app/DemoListaJackson.java` | Conversión de una colección y uso de `TypeReference<List<Alumno>>` para conservar el tipo de los elementos. | Sí |
| 5 | `repository/AlumnoJsonRepository.java` | Separación del acceso a datos: `Path`, `Files`, UTF-8, lectores/escritores y `try-with-resources`. | No |
| 6 | `app/GuardarAlumnosJackson.java` | Escritura de una lista de alumnos en `data/alumnos.json` a través del repositorio. | Sí |
| 7 | `app/LeerAlumnosJackson.java` | Lectura del JSON generado y reconstrucción de una lista de objetos `Alumno`. | Sí, después del paso 6 |
| 8 | `app/DemoJsonNode.java` | Uso de `JsonNode` para explorar la estructura de un JSON sin necesitar un POJO para cada estructura. | Sí |
| 9 | `app/DemoAnotaciones.java` | Personalización de las propiedades JSON. Vuelve a `Alumno.java` y estudia `@JsonProperty` y `@JsonIgnore`. | Sí |

**Importante:** las anotaciones ya influyen en los primeros ejemplos. En particular, el atributo `nombre` aparece en JSON como `nombreCompleto` por `@JsonProperty`, y `observaciones` se excluye por `@JsonIgnore`. No es un error: analizaremos el motivo con detalle en el último ejemplo.

## Propuesta de estudio por bloques

### Bloque 1 — Objetos y JSON (pasos 1–3)

- Identifica las propiedades de `Alumno`.
- Localiza dónde se obtiene el `ObjectMapper`.
- Ejecuta `DemoJackson` y compara el objeto Java con el JSON mostrado.
- Distingue `writeValueAsString()` de `readValue()`.

### Bloque 2 — Colecciones (paso 4)

- Ejecuta `DemoListaJackson`.
- Comprueba que el JSON representa una lista de alumnos.
- Explica para qué sirve `TypeReference<List<Alumno>>` al recuperar la colección.

### Bloque 3 — Ficheros y buenas prácticas (pasos 5–7)

- Lee primero `AlumnoJsonRepository`: no tiene `main`, porque su función es encapsular el acceso a datos.
- Identifica `Files.newBufferedWriter()`, `Files.newBufferedReader()`, UTF-8 y los bloques `try-with-resources`.
- Ejecuta **primero** `GuardarAlumnosJackson` y **después** `LeerAlumnosJackson`.
- Abre `data/alumnos.json` y compara el contenido con los objetos Java. La ruta es relativa al directorio desde el que ejecutas el programa.

### Bloque 4 — Árboles JSON y anotaciones (pasos 8–9)

- Ejecuta `DemoJsonNode` y observa cómo se consultan los nodos de un documento JSON.
- Ejecuta `DemoAnotaciones` y vuelve al modelo `Alumno`.
- Explica por qué `nombre` se transforma en `nombreCompleto` y por qué se omite `observaciones`.

## Organización del proyecto

```text
src/main/java/com/example/
├── model/
│   └── Alumno.java
├── config/
│   └── JacksonConfig.java
├── repository/
│   └── AlumnoJsonRepository.java
└── app/
    ├── DemoJackson.java
    ├── DemoListaJackson.java
    ├── GuardarAlumnosJackson.java
    ├── LeerAlumnosJackson.java
    ├── DemoJsonNode.java
    └── DemoAnotaciones.java
```

La separación responde a las responsabilidades de cada clase:

- **`model`**: representa los datos del dominio.
- **`config`**: centraliza la configuración de Jackson.
- **`repository`**: encapsula la persistencia en ficheros JSON.
- **`app`**: contiene ejemplos ejecutables y la salida por consola.

No se implementa un MVC completo porque son ejemplos introductorios de una librería. Sí se aplica una **separación de responsabilidades** que facilita evolucionarlos hacia una aplicación mayor.

## Buenas prácticas que debes identificar

- JDK 21 configurado en Maven.
- `ObjectMapper` configurado en un lugar común.
- Uso de `TypeReference` para listas.
- Gestión de ficheros con `Path` y `Files`, usando UTF-8.
- Cierre automático de recursos con `try-with-resources`.
- Gestión de errores de E/S y JSON.
- Comentarios que explican las operaciones principales.

## Para comprobar que lo has entendido

1. ¿Qué diferencia existe entre serializar y deserializar?
2. ¿Por qué `DemoListaJackson` necesita `TypeReference`?
3. ¿Qué clase se ocupa de guardar y leer los datos? ¿Por qué no lo hace `Alumno`?
4. ¿Qué ventaja aporta `try-with-resources`?
5. ¿Qué efecto tienen `@JsonProperty` y `@JsonIgnore`?

**Sugerencia:** modifica la nota de un alumno, vuelve a guardar el fichero y comprueba que el programa de lectura recupera el nuevo valor.
