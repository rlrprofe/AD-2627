package com.example.app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.config.JacksonConfig;
import com.example.model.Alumno;


/** Ejemplo didáctico de Jackson. */
public class DemoAnotaciones {
    public static void main(String[] args) {
        Alumno alumno = new Alumno(1, "Ana", 8.5);
        alumno.setObservaciones("Dato interno que no se serializa");

        ObjectMapper mapper = JacksonConfig.crearMapper();
        

        try {
            // @JsonProperty cambia el nombre de la propiedad y @JsonIgnore la omite.
            String json = mapper.writeValueAsString(alumno);

        System.out.println(json);
        System.out.println("\nObserva que:");
        System.out.println("- nombre se representa como nombreCompleto.");
        System.out.println("- observaciones no aparece en el JSON.");
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            System.err.println("Error al generar JSON: " + e.getOriginalMessage());
        }
    }
}
