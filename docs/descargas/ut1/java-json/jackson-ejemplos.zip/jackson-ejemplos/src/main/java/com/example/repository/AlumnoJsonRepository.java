package com.example.repository;

import com.example.model.Alumno;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

/** Acceso a datos: aísla la lectura y escritura JSON de los ejemplos de consola. */
public class AlumnoJsonRepository {
    private final ObjectMapper mapper;
    private final Path fichero;

    public AlumnoJsonRepository(ObjectMapper mapper, Path fichero) {
        this.mapper = Objects.requireNonNull(mapper);
        this.fichero = Objects.requireNonNull(fichero);
    }

    public void guardar(List<Alumno> alumnos) throws IOException {
        Path directorio = fichero.getParent();
        if (directorio != null) Files.createDirectories(directorio);
        // El escritor se cierra incluso si Jackson produce una excepción.
        try (BufferedWriter escritor = Files.newBufferedWriter(fichero, StandardCharsets.UTF_8)) {
            mapper.writeValue(escritor, alumnos);
        }
    }

    public List<Alumno> leer() throws IOException {
        // TypeReference conserva el tipo de los elementos de List<Alumno>.
        try (BufferedReader lector = Files.newBufferedReader(fichero, StandardCharsets.UTF_8)) {
            List<Alumno> alumnos = mapper.readValue(lector, new TypeReference<List<Alumno>>() { });
            return alumnos == null ? List.of() : alumnos;
        }
    }
}
