package com.example.app;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.config.JacksonConfig;
import com.example.model.Alumno;


import java.util.List;

/** Ejemplo didáctico de Jackson. */
public class DemoListaJackson {
    public static void main(String[] args) {
        ObjectMapper mapper = JacksonConfig.crearMapper();
        

        List<Alumno> alumnos = List.of(
                new Alumno(1, "Ana", 8.5),
                new Alumno(2, "Luis", 7.2),
                new Alumno(3, "Marta", 9.1)
        );

        try {
            // Serializa la lista completa como un array JSON.
            String json = mapper.writeValueAsString(alumnos);
        System.out.println(json);

        List<Alumno> recuperados = mapper.readValue(
                json,
                new TypeReference<List<Alumno>>() {} // Conserva el tipo genérico.
        );

        System.out.println("\nAlumnos recuperados:");
        recuperados.forEach(System.out::println);
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            System.err.println("Error al procesar la lista: " + e.getOriginalMessage());
        }
    }
}
