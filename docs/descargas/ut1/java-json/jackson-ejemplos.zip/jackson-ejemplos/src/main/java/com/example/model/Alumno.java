package com.example.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/** Modelo de alumno. Las anotaciones muestran cómo personalizar el JSON. */
public class Alumno {
    private int id;
    private String nombre;
    private double nota;

    // Campo interno: @JsonIgnore impide incluirlo en el JSON.
    @JsonIgnore
    private String observaciones;

    public Alumno() {
    }

    public Alumno(int id, String nombre, double nota) {
        this.id = id;
        this.nombre = nombre;
        this.nota = nota;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // El atributo nombre se representa en JSON con la clave nombreCompleto.
    @JsonProperty("nombreCompleto")
    public String getNombre() {
        return nombre;
    }

    @JsonProperty("nombreCompleto")
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "Alumno{id=" + id + ", nombre='" + nombre + "', nota=" + nota + "}";
    }
}
