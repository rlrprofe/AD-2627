package com.example.app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.config.JacksonConfig;
import com.example.model.Alumno;
import com.example.repository.AlumnoJsonRepository;
import java.io.IOException;


import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Ejemplo didáctico de Jackson. */
public class GuardarAlumnosJackson {
    public static void main(String[] args) {
        ObjectMapper mapper = JacksonConfig.crearMapper();
        

        List<Alumno> alumnos = List.of(
                new Alumno(1, "Ana", 8.5),
                new Alumno(2, "Luis", 7.2),
                new Alumno(3, "Marta", 9.1)
        );

        Path fichero = Path.of("data", "alumnos.json");
        AlumnoJsonRepository repositorio = new AlumnoJsonRepository(mapper, fichero);
        try {
            // La capa repository gestiona el fichero mediante try-with-resources.
            repositorio.guardar(alumnos);
            System.out.println("Datos guardados en: " + fichero.toAbsolutePath());
        } catch (IOException e) {
            System.err.println("No se pudo guardar el JSON: " + e.getMessage());
        }
    }
}
