package com.example.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/** Configuración compartida del serializador JSON. ObjectMapper es reutilizable. */
public final class JacksonConfig {
    private JacksonConfig() { }

    public static ObjectMapper crearMapper() {
        return new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    }
}
