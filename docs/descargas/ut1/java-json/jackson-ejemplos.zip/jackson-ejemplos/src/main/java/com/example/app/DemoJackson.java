package com.example.app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.config.JacksonConfig;
import com.example.model.Alumno;


/** Ejemplo didáctico de Jackson. */
public class DemoJackson {
    public static void main(String[] args) {
        ObjectMapper mapper = JacksonConfig.crearMapper();
        

        Alumno original = new Alumno(1, "Ana", 8.5);

        try {
            // Serialización: objeto Java a texto JSON.
            String json = mapper.writeValueAsString(original);
        System.out.println("JSON:");
        System.out.println(json);

        // Deserialización: texto JSON a objeto Java.
        Alumno recuperado = mapper.readValue(json, Alumno.class);
        System.out.println("\nObjeto recuperado:");
        System.out.println(recuperado);
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            System.err.println("Error al procesar JSON: " + e.getOriginalMessage());
        }
    }
}
