package com.example.app;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.config.JacksonConfig;
import com.example.model.Alumno;
import com.example.repository.AlumnoJsonRepository;
import java.io.IOException;

import java.nio.file.Path;
import java.util.List;

/** Ejemplo didáctico de Jackson. */
public class LeerAlumnosJackson {
    public static void main(String[] args) {
        ObjectMapper mapper = JacksonConfig.crearMapper();

        Path fichero = Path.of("data", "alumnos.json");

        AlumnoJsonRepository repositorio = new AlumnoJsonRepository(mapper, fichero);
        try {
            // TypeReference y cierre seguro del lector se gestionan en repository.
            List<Alumno> alumnos = repositorio.leer();
            alumnos.forEach(System.out::println);
        } catch (IOException e) {
            System.err.println("No se pudo leer el JSON: " + e.getMessage());
        }
    }
}
