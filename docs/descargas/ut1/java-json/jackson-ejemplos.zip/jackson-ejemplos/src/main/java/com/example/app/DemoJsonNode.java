package com.example.app;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.config.JacksonConfig;

/** Ejemplo didáctico de Jackson. */
public class DemoJsonNode {
    public static void main(String[] args) {
        String json = """
                {
                  "id": 1,
                  "nombreCompleto": "Ana",
                  "nota": 8.5
                }
                """;

        ObjectMapper mapper = JacksonConfig.crearMapper();
        try {
            // JsonNode permite consultar JSON sin crear una clase modelo.
            JsonNode raiz = mapper.readTree(json);

        System.out.println("Nombre: " + raiz.path("nombreCompleto").asText("(sin nombre)"));
        System.out.println("Nota: " + raiz.path("nota").asDouble());
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            System.err.println("JSON incorrecto: " + e.getOriginalMessage());
        }
    }
}
