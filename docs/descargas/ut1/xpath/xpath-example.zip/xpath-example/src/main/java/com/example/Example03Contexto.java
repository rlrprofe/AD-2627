package com.example;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.*;
import java.io.File;

/**
 * Ejemplo 3 – Contexto de evaluación en XPath:
 *  - Evaluar una expresión sobre el DOCUMENTO completo (global).
 *  - Evaluar una expresión sobre un NODO concreto (relativa).
 *  - Diferencia entre (//producto)[1] y //producto[1] según el contexto.
 */
public class Example03Contexto {

    public static void main(String[] args) {
        try {
            // --------------------------------------------------------------
            // 1) Cargar XML (DOM)
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            File xmlFile = new File("resources/catalogo.xml");
            Document doc = dbf.newDocumentBuilder().parse(xmlFile);
            doc.getDocumentElement().normalize();
            System.out.println(" XML cargado: " + xmlFile.getAbsolutePath());

            // Evaluador XPath
            XPath xp = XPathFactory.newInstance().newXPath();

            // --------------------------------------------------------------
            // 2) Evaluación GLOBAL (sobre el DOCUMENTO)
            //    Lista de todos los precios del catálogo
            // --------------------------------------------------------------
            NodeList preciosGlobal = (NodeList) xp.evaluate(
                    "//precio/text()",      // búsqueda en todo el árbol
                    doc, XPathConstants.NODESET);

            System.out.println("\n[GLOBAL] Precios del catálogo (//precio/text()):");
            for (int i = 0; i < preciosGlobal.getLength(); i++) {
                System.out.println(" - " + preciosGlobal.item(i).getNodeValue());
            }

            // --------------------------------------------------------------
            // 3) Evaluación LOCAL (sobre cada NODO <producto>)
            //    Mismas consultas, pero relativas al nodo actual
            // --------------------------------------------------------------
            NodeList productos = (NodeList) xp.evaluate("//producto", doc, XPathConstants.NODESET);
            System.out.println("\n[LOCAL] Detalle por producto (evaluación relativa al nodo <producto>):");

            for (int i = 0; i < productos.getLength(); i++) {
                Element p = (Element) productos.item(i);

                // Expresiones RELATIVAS: no empiezan por // ni por /
                String nombre = (String) xp.evaluate("nombre/text()", p, XPathConstants.STRING);
                String precio = (String) xp.evaluate("precio/text()", p, XPathConstants.STRING);
                String moneda = (String) xp.evaluate("precio/@moneda", p, XPathConstants.STRING);
                String id = p.getAttribute("id");

                //  booleano relativo a ESTE producto
                Boolean esCaro = (Boolean) xp.evaluate("number(precio) > 100", p, XPathConstants.BOOLEAN);

                System.out.printf(" [%s] %s — %s %s | ¿caro? %s%n",
                        id, nombre, precio, moneda, esCaro);
            }

            // --------------------------------------------------------------
            // 4) (//producto)[1] vs //producto[1] según el CONTEXTO
            // --------------------------------------------------------------
            // Contexto: el nodo <catalogo> (padre de productos)
            Element catalogo = (Element) xp.evaluate("/catalogo", doc, XPathConstants.NODE);

            // (a) Evaluado desde <catalogo>
            String a1 = (String) xp.evaluate("(//producto)[1]/nombre/text()", catalogo, XPathConstants.STRING);
            String a2 = (String) xp.evaluate("//producto[1]/nombre/text()",    catalogo, XPathConstants.STRING);

            System.out.println("\n[Desde <catalogo>]");
            System.out.println(" (//producto)[1] → " + a1 + "   (primer <producto> del DOCUMENTO)");
            System.out.println(" //producto[1]   → " + a2 + "   (primer <producto> BAJO CADA PADRE)");

            // (b) Evaluado desde un <producto> concreto (por ejemplo, el segundo)
            Element segundoProducto = (Element) productos.item(1); // posición 1 = 2º producto

            String b1 = (String) xp.evaluate("(//producto)[1]/nombre/text()", segundoProducto, XPathConstants.STRING);
            String b2 = (String) xp.evaluate("//producto[1]/nombre/text()",    segundoProducto, XPathConstants.STRING);
            String bRelativo = (String) xp.evaluate("nombre/text()",           segundoProducto, XPathConstants.STRING);

            System.out.println("\n[Desde <producto> (el segundo)]");
            System.out.println(" (//producto)[1] → " + b1 + "   (sigue siendo el 1º del DOCUMENTO)");
            System.out.println(" //producto[1]   → " + b2 + "   (1º <producto> BAJO el MISMO padre <catalogo>)");
            System.out.println(" nombre          → " + bRelativo + "   (relativo: el nombre de ESTE producto)");

            // Conclusión:
            // - (//producto)[1] siempre es el 1º producto del documento (global).
            // - //producto[1] toma "el primero de cada grupo de hermanos bajo su padre".
            // - "nombre" (sin / ni //) es RELATIVO al nodo actual (no al documento).

        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println(" Configuración del parser DOM: " + e.getMessage());
        } catch (org.xml.sax.SAXException e) {
            System.err.println(" XML mal formado: " + e.getMessage());
        } catch (java.io.IOException e) {
            System.err.println(" Error de lectura del archivo XML: " + e.getMessage());
        } catch (XPathExpressionException e) {
            System.err.println(" Expresión XPath inválida: " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}
