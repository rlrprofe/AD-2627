
package com.example;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.*;
import java.io.File;

/**
 * Ejemplo 1 – Uso básico de XPath en Java con manejo de excepciones.
 * 
 * Objetivo:
 *  - Cargar un XML en memoria (DOM)
 *  - Ejecutar consultas XPath sencillas:
 *          -Obtener el nombre de todos los productos con precio > 50.
             -Calcular el número total de productos.
             -Mostrar el id del primer producto del documento.
             -(Opcional) Calcular la suma y media de los precios.
 *  - Capturar errores comunes de lectura o análisis
 */
public class Example01Catalogo {

    public static void main(String[] args) {
        try {
            // --------------------------------------------------------------
            // 1) Cargar el XML en memoria (DOM)
            // --------------------------------------------------------------
            // DocumentBuilderFactory crea el analizador DOM.
            // Se desactiva el uso de espacios de nombres (namespaceAware).
            DocumentBuilderFactory  dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);

            // Crear el objeto Document a partir del fichero XML.
            // Si el archivo no existe o está mal formado, lanzará una excepción.
            File xmlFile = new File("resources/catalogo.xml");
            Document doc = dbf.newDocumentBuilder().parse(xmlFile);

            // Normalizar el documento evita errores por nodos de texto partidos.
            doc.getDocumentElement().normalize();
            System.out.println(" XML cargado correctamente: " + xmlFile.getAbsolutePath());

            // --------------------------------------------------------------
            // 2) Crear el evaluador XPath
            // --------------------------------------------------------------
            XPath xp = XPathFactory.newInstance().newXPath();

            // --------------------------------------------------------------
            // 3) CONSULTAS
            // --------------------------------------------------------------

            // (a) Nombres de productos con precio > 50 → NODESET (lista de nodos)
            NodeList caros = (NodeList) xp.evaluate(
                    "//producto[precio > 50]/nombre/text()",
                    doc, XPathConstants.NODESET);

            System.out.println("\nProductos con precio > 50:");
            for (int i = 0; i < caros.getLength(); i++) {
                System.out.println(" - " + caros.item(i).getNodeValue());
            }

            // (b) Número total de productos → NUMBER (Double)
            Double total = (Double) xp.evaluate("count(//producto)", doc, XPathConstants.NUMBER);
            System.out.println("\nTotal de productos: " + total.intValue());

            // (c) ID del primer producto → STRING
            String idPrimero = (String) xp.evaluate("(//producto)[1]/@id", doc, XPathConstants.STRING);
            System.out.println("ID del primer producto: " + idPrimero);

            // (d) (Opcional) Suma y media de precios
            Double suma = (Double) xp.evaluate("sum(//precio)", doc, XPathConstants.NUMBER);
            double media = (total > 0) ? (suma / total) : 0.0;
            System.out.printf("Suma de precios: %.2f | Media: %.2f%n", suma, media);

        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println(" Error de configuración del parser DOM: " + e.getMessage());

        } catch (org.xml.sax.SAXException e) {
            System.err.println(" Error al analizar el XML (mal formado): " + e.getMessage());

        } catch (java.io.IOException e) {
            System.err.println(" Error de lectura del archivo XML (no encontrado o sin permisos): " + e.getMessage());

        } catch (XPathExpressionException e) {
            System.err.println(" Error en la expresión XPath: " + e.getMessage());

        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}
