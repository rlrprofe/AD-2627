package com.example;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.*;

import java.io.File;
import java.io.InputStream;

/**
 * Ejemplo 2 – Evaluación de XPath con distintos tipos de resultado:
 *  - NODESET (lista de nodos)
 *  - STRING  (cadena)
 *  - NUMBER  (número Double)
 *  - BOOLEAN (verdadero/falso)
 *
 * Carga el XML desde  (resources/catalogo.xml).
 */
public class Example02TiposResultado {

    public static void main(String[] args) {
        try {
            // -----------------------------------------------------------------
            // 1) Cargar el XML desde el classpath
            // -----------------------------------------------------------------
            // DocumentBuilderFactory permite crear un parser DOM
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false); // nuestro XML no usa namespaces

            // El XML se encuentra dentro de la carpeta "resources"
            File xmlFile = new File("resources/catalogo.xml");
            Document doc = dbf.newDocumentBuilder().parse(xmlFile);
            doc.getDocumentElement().normalize();

            System.out.println(" XML cargado correctamente desde: " + xmlFile.getAbsolutePath());
            System.out.println();

            // -----------------------------------------------------------------
            // 2) Crear evaluador XPath
            // -----------------------------------------------------------------
            XPath xp = XPathFactory.newInstance().newXPath();

            // -----------------------------------------------------------------
            // 3) NODESET: cuando quieres "muchos resultados" (lista)
            //    Ej.: nombres de todos los productos (sin filtro)
            // -----------------------------------------------------------------
            NodeList listaNombres = (NodeList) xp.evaluate(
                    "//producto/nombre/text()",
                    doc, XPathConstants.NODESET);

            System.out.println("NODESET → Lista de nombres:");
            for (int i = 0; i < listaNombres.getLength(); i++) {
                // Cada item es un Text node → getNodeValue()
                System.out.println(" - " + listaNombres.item(i).getNodeValue());
            }
            System.out.println();

            // -----------------------------------------------------------------
            // 4) STRING: cuando esperas "un solo valor"
            //    Ej.: nombre del primer producto en el documento
            // -----------------------------------------------------------------
            String primerNombre = (String) xp.evaluate(
                    "(//producto)[1]/nombre/text()",
                    doc, XPathConstants.STRING);

            System.out.println("STRING → (//producto)[1]/nombre/text() = " + primerNombre);
            System.out.println("  * Útil cuando el resultado es único (o te interesa solo el primero).\n");

            // -----------------------------------------------------------------
            // 5) NUMBER: para cálculos (count/sum/round/...)
            //    Ej.: sumar precios y contar productos para calcular la media
            // -----------------------------------------------------------------
            Double sumaPrecios = (Double) xp.evaluate("sum(//precio)", doc, XPathConstants.NUMBER);
            Double totalProductos = (Double) xp.evaluate("count(//producto)", doc, XPathConstants.NUMBER);
            double media = (totalProductos > 0) ? (sumaPrecios / totalProductos) : 0.0;

            System.out.printf("NUMBER → sum(//precio) = %.2f%n", sumaPrecios);
            System.out.printf("NUMBER → count(//producto) = %.0f%n", totalProductos);
            System.out.printf("MEDIA calculada en Java = %.2f%n%n", media);

            // -----------------------------------------------------------------
            // 6) BOOLEAN: para comprobar condiciones (existe/no existe, > 0, etc.)
            //    Ej.: ¿hay productos con precio > 100? ¿Hay categoría 'pantallas'?
            // -----------------------------------------------------------------
            Boolean hayCaros = (Boolean) xp.evaluate(
                    "count(//producto[precio > 100]) > 0",
                    doc, XPathConstants.BOOLEAN);
            Boolean hayPantallas = (Boolean) xp.evaluate(
                    "count(//producto[@categoria='pantallas']) > 0",
                    doc, XPathConstants.BOOLEAN);

            System.out.println("BOOLEAN → ¿precio > 100? " + hayCaros);
            System.out.println("BOOLEAN → ¿categoría 'pantallas'? " + hayPantallas + "\n");

            // -----------------------------------------------------------------
            // 7) mismo XPath, distintos tipos de retorno
            //    Expresión: nombre del primer producto
            // -----------------------------------------------------------------
            // Como NODESET: devuelve una lista con 1 nodo de texto
            NodeList unoComoLista = (NodeList) xp.evaluate(
                    "(//producto)[1]/nombre/text()", doc, XPathConstants.NODESET);
            // Como STRING: devuelve el texto directamente
            String unoComoString = (String) xp.evaluate(
                    "(//producto)[1]/nombre/text()", doc, XPathConstants.STRING);

            System.out.println("Mismo XPath, tipos distintos:");
            System.out.println(" - NODESET (tamaño): " + unoComoLista.getLength());
            if (unoComoLista.getLength() > 0) {
                System.out.println("   NODESET[0] = " + unoComoLista.item(0).getNodeValue());
            }
            System.out.println(" - STRING = " + unoComoString);

            // -----------------------------------------------------------------
            // Fin del ejemplo
            // -----------------------------------------------------------------

        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println(" Configuración del parser DOM: " + e.getMessage());
        } catch (org.xml.sax.SAXException e) {
            System.err.println(" XML mal formado: " + e.getMessage());
        } catch (java.io.IOException e) {
            System.err.println(" Error de E/S (no se pudo leer catalogo.xml): " + e.getMessage());
        } catch (XPathExpressionException e) {
            System.err.println(" Expresión XPath inválida: " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}
