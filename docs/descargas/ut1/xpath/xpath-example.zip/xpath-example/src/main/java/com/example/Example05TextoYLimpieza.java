package com.example;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.*;
import java.io.File;

/**
 * Ejemplo 5 – Texto y limpieza con XPath 1.0
 * Funciones clave:
 *  - contains(haystack, needle)
 *  - starts-with(text, prefix)
 *  - string-length(text)
 *  - normalize-space(text)
 *  - translate(text, "ABC...", "abc...") para case-insensitive
 */
public class Example05TextoYLimpieza {

    public static void main(String[] args) {
        try {
            // --------------------------------------------------------------
            // 1) Cargar XML (DOM)
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            File xmlFile = new File("resources/catalogo.xml");
            Document doc = dbf.newDocumentBuilder().parse(xmlFile);
            doc.getDocumentElement().normalize();
            System.out.println(" XML cargado: " + xmlFile.getAbsolutePath() + "\n");

            XPath xp = XPathFactory.newInstance().newXPath();

            // --------------------------------------------------------------
            // 2) Descripción que contiene "LED" (sensible a mayúsculas)
            // --------------------------------------------------------------
            NodeList ledSensibles = (NodeList) xp.evaluate(
                    "//producto[contains(descripcion,'LED')]/nombre/text()",
                    doc, XPathConstants.NODESET);

            System.out.println("Descripciones que contienen 'LED' (case-sensitive):");
            if (ledSensibles.getLength() == 0) System.out.println(" - (ninguno)");
            for (int i = 0; i < ledSensibles.getLength(); i++) {
                System.out.println(" - " + ledSensibles.item(i).getNodeValue());
            }
            System.out.println();

            // --------------------------------------------------------------
            // 3) Nombres que empiezan por "Mo" (starts-with)
            // --------------------------------------------------------------
            NodeList empiezaMo = (NodeList) xp.evaluate(
                    "//producto[starts-with(nombre,'Mo')]/nombre/text()",
                    doc, XPathConstants.NODESET);

            System.out.println("Nombres que empiezan por 'Mo':");
            if (empiezaMo.getLength() == 0) System.out.println(" - (ninguno)");
            for (int i = 0; i < empiezaMo.getLength(); i++) {
                System.out.println(" - " + empiezaMo.item(i).getNodeValue());
            }
            System.out.println();

            // --------------------------------------------------------------
            // 4) Búsqueda case-insensitive de "led" en descripción
            //    Truco con translate(): pasa a minúsculas A-Z -> a-z
            // --------------------------------------------------------------
            String toLower = "translate(descripcion, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')";
            NodeList ledCaseInsensitive = (NodeList) xp.evaluate(
                    "//producto[contains(" + toLower + ",'led')]/nombre/text()",
                    doc, XPathConstants.NODESET);

            System.out.println("Descripciones que contienen 'led' (case-insensitive):");
            if (ledCaseInsensitive.getLength() == 0) System.out.println(" - (ninguno)");
            for (int i = 0; i < ledCaseInsensitive.getLength(); i++) {
                System.out.println(" - " + ledCaseInsensitive.item(i).getNodeValue());
            }
            System.out.println("  * Usamos translate() para simular lower-case en XPath 1.0.\n");

            // --------------------------------------------------------------
            // 5) Nombres “largos” (> 12 caracteres), tras limpiar espacios
            //    normalize-space(): elimina espacios iniciales/finales y colapsa internos
            // --------------------------------------------------------------
            NodeList nombresLargos = (NodeList) xp.evaluate(
                    "//producto[string-length(normalize-space(nombre)) > 12]/nombre/text()",
                    doc, XPathConstants.NODESET);

            System.out.println("Nombres 'largos' (>12), tras normalize-space():");
            if (nombresLargos.getLength() == 0) System.out.println(" - (ninguno)");
            for (int i = 0; i < nombresLargos.getLength(); i++) {
                System.out.println(" - " + nombresLargos.item(i).getNodeValue());
            }
            System.out.println();

            // --------------------------------------------------------------
            // 6) Mostrar nombres “limpios” con normalize-space()
            //    (útil si en el XML hay espacios extra o saltos de línea)
            // --------------------------------------------------------------
            NodeList nombresLimpios = (NodeList) xp.evaluate(
                    "normalize-space(//producto[1]/nombre)",
                    doc, XPathConstants.NODESET); // Nota: devuelve NodeSet si pedimos NODESET

            // Mejor: pedir STRING para ver el efecto directamente
            String primeroLimpio = (String) xp.evaluate(
                    "normalize-space((//producto)[1]/nombre)",
                    doc, XPathConstants.STRING);

            System.out.println("normalize-space() sobre primer <nombre> (STRING):");
            System.out.println(" - \"" + primeroLimpio + "\"");
            System.out.println("  * Útil para comparar textos evitando espacios de más.\n");

        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println(" Configuración del parser DOM: " + e.getMessage());
        } catch (org.xml.sax.SAXException e) {
            System.err.println(" XML mal formado: " + e.getMessage());
        } catch (java.io.IOException e) {
            System.err.println(" Error de lectura del archivo XML: " + e.getMessage());
        } catch (XPathExpressionException e) {
            System.err.println(" Expresión XPath inválida: " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}
