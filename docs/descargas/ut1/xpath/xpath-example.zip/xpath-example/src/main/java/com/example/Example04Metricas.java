package com.example;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.*;
import java.io.File;

/**
 * Ejemplo 4 – Métricas y filtros combinados con XPath 1.0 y Java.
 * - count() y sum() en XPath
 * - media, mínimo y máximo en Java
 * - identificación de producto más caro/barato
 * - listados de caros (>100) y baratos (<=50)
 */
public class Example04Metricas {

    public static void main(String[] args) {
        try {
            // --------------------------------------------------------------
            // 1) Cargar XML (DOM) desde ruta relativa
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            File xmlFile = new File("resources/catalogo.xml");
            Document doc = dbf.newDocumentBuilder().parse(xmlFile);
            doc.getDocumentElement().normalize();
            System.out.println(" XML cargado: " + xmlFile.getAbsolutePath() + "\n");

            XPath xp = XPathFactory.newInstance().newXPath();

            // --------------------------------------------------------------
            // 2) Total de productos y suma de precios (XPath NUMBER)
            // --------------------------------------------------------------
            Double total = (Double) xp.evaluate("count(//producto)", doc, XPathConstants.NUMBER);
            Double suma = (Double) xp.evaluate("sum(//precio)", doc, XPathConstants.NUMBER);
            double media = (total > 0) ? (suma / total) : 0.0;

            System.out.printf("Total productos: %.0f%n", total);
            System.out.printf("Suma de precios: %.2f%n", suma);
            System.out.printf("Media de precios: %.2f%n", media);

            // --------------------------------------------------------------
            // 3) Mínimo y máximo (XPath 1.0 no tiene min/max → Java)
            //    Recorremos todos los <precio> y calculamos min/max
            // --------------------------------------------------------------
            NodeList precios = (NodeList) xp.evaluate("//precio/text()", doc, XPathConstants.NODESET);
            double min = Double.POSITIVE_INFINITY;
            double max = Double.NEGATIVE_INFINITY;
            for (int i = 0; i < precios.getLength(); i++) {
                String txt = precios.item(i).getNodeValue().trim();
                if (txt.isEmpty()) continue;
                double val = Double.parseDouble(txt);
                if (val < min) min = val;
                if (val > max) max = val;
            }
            System.out.printf("Precio mínimo: %.2f%n", min);
            System.out.printf("Precio máximo: %.2f%n", max);

            // --------------------------------------------------------------
            // 4) Producto más barato y más caro
            //    Estrategia: encontrar el <producto> cuyo precio == min/max
            //    Nota: si hubiera empates, devolvería el primero que coincida.
            // --------------------------------------------------------------
            // a) Producto más caro
            String xpathMasCaro = "//producto[number(precio) = " + max + "]";
            Element prodCaro = (Element) xp.evaluate(xpathMasCaro, doc, XPathConstants.NODE);
            if (prodCaro != null) {
                String nombreCaro = (String) xp.evaluate("nombre/text()", prodCaro, XPathConstants.STRING);
                String idCaro = ((Element) prodCaro).getAttribute("id");
                System.out.printf("Más caro: [%s] %s (%.2f)%n", idCaro, nombreCaro, max);
            }

            // b) Producto más barato
            String xpathMasBarato = "//producto[number(precio) = " + min + "]";
            Element prodBarato = (Element) xp.evaluate(xpathMasBarato, doc, XPathConstants.NODE);
            if (prodBarato != null) {
                String nombreBarato = (String) xp.evaluate("nombre/text()", prodBarato, XPathConstants.STRING);
                String idBarato = ((Element) prodBarato).getAttribute("id");
                System.out.printf("Más barato: [%s] %s (%.2f)%n", idBarato, nombreBarato, min);
            }

            // --------------------------------------------------------------
            // 5) Listados por segmento de precio
            // --------------------------------------------------------------
            // Caros: precio > 100
            NodeList caros = (NodeList) xp.evaluate(
                    "//producto[precio > 100]/nombre/text()", doc, XPathConstants.NODESET);
            System.out.println("\nProductos CAROS (>100):");
            if (caros.getLength() == 0) System.out.println(" - (ninguno)");
            for (int i = 0; i < caros.getLength(); i++) {
                System.out.println(" - " + caros.item(i).getNodeValue());
            }

            // Baratos: precio <= 50
            NodeList baratos = (NodeList) xp.evaluate(
                    "//producto[number(precio) <= 50]/nombre/text()", doc, XPathConstants.NODESET);
            System.out.println("\nProductos BARATOS (<=50):");
            if (baratos.getLength() == 0) System.out.println(" - (ninguno)");
            for (int i = 0; i < baratos.getLength(); i++) {
                System.out.println(" - " + baratos.item(i).getNodeValue());
            }

        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println(" Configuración del parser DOM: " + e.getMessage());
        } catch (org.xml.sax.SAXException e) {
            System.err.println(" XML mal formado: " + e.getMessage());
        } catch (java.io.IOException e) {
            System.err.println(" Error de lectura del archivo XML: " + e.getMessage());
        } catch (XPathExpressionException e) {
            System.err.println(" Expresión XPath inválida: " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}
