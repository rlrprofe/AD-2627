# Gestión de inventario — UT3 (Java 21, Maven, MVC + Servicio + DAO)

Solución de referencia revisada a partir del proyecto original de la UT3 de Acceso a Datos.

## Objetivos didácticos

- **Modelo** (`modelo/Producto`): datos de un producto, representados con un `record`.
- **Vista** (`vista/ConsolaVista`): menú, lectura de teclado, presentación y errores.
- **Controlador** (`controlador/ProductoControlador`): coordina cada caso de uso mediante métodos pequeños.
- **Servicio** (`servicio/ProductoService`): valida las reglas de negocio.
- **DAO** (`dao/ProductoDAO`): contrato CRUD independiente del almacenamiento.
- **Persistencia CSV/JDBC**: implementaciones intercambiables del DAO.
- **Configuración** (`configuracion/Configuracion`, `FabricaDao`): carga un fichero `.properties` y crea el DAO.
- **Conexión** (`util/ConexionBD`): centraliza la apertura de conexiones MySQL.
- **App**: únicamente crea las dependencias y arranca el controlador.

### Recorrido de una operación

`Usuario → ConsolaVista ↔ ProductoControlador → ProductoService → ProductoDAO → CSV/MySQL`

No se añade una clase por cada línea de código: se separan responsabilidades con motivos distintos para cambiar.

## Requisitos

- JDK 21
- Maven 3.9.x o una versión compatible
- MySQL (solo para modo `mysql`)

## Configuración con fichero `.properties`

1. En `config/` se incluye `configuracion.properties.example`.
2. Copia ese archivo a `config/configuracion.properties` (ya se proporciona uno de muestra para CSV).
3. Para trabajar con CSV:

```properties
almacenamiento.tipo=csv
csv.ruta=datos/productos.csv
```

4. Para trabajar con MySQL, crea la base de datos mediante `sql/inventario.sql` y configura:

```properties
almacenamiento.tipo=mysql
csv.ruta=datos/productos.csv
db.url=jdbc:mysql://localhost:3306/inventario
db.usuario=inventario_app
db.password=TU_CONTRASENA
```

**No publiques contraseñas.** `config/configuracion.properties` está excluido por `.gitignore`. Si necesitas compartir el proyecto con otras personas, entrega solo `configuracion.properties.example` y explícales cómo crear su copia privada.

**Importante:** el fichero se busca en `config/configuracion.properties` **relativo al directorio desde el que ejecutas la aplicación**. Ejecuta desde la raíz del proyecto (donde está `pom.xml`). Si utilizas VS Code, comprueba el directorio de trabajo de la configuración de ejecución.

El programa **no utiliza variables de entorno ni solicita introducirlas en la terminal**.

## Compilar, probar y ejecutar

```bash
mvn clean test
mvn clean package
java -jar target/gestion-inventario-1.0-SNAPSHOT.jar
```

El JAR se genera con `maven-shade-plugin` para incluir las dependencias necesarias.

## Ejemplos de pruebas

- `ProductoServiceTest`: validaciones y reglas de negocio (prueba unitaria).
- `ProductoFicheroDAOTest`: persistencia CSV usando `@TempDir` y comprobación CRUD.
- `ProductoControladorTest`: interacción completa simulando la entrada del teclado y capturando la salida.

Para ejecutar MySQL se requiere que el servidor esté disponible, la tabla creada y un usuario con permisos. Las pruebas anteriores no necesitan MySQL.

## Gestión de recursos

- `Scanner` se cierra en `App` con **try-with-resources**.
- La lectura del fichero de configuración utiliza `InputStream` y **try-with-resources**.
- El CSV utiliza `BufferedReader` y `BufferedWriter` con **try-with-resources**.
- JDBC utiliza `Connection`, `PreparedStatement` y `ResultSet` con **try-with-resources**.
- El CSV se guarda primero en un fichero temporal y se sustituye al final. No es una solución transaccional multiusuario.

## Limitaciones intencionadas

- El CSV es un formato didáctico simplificado con separador `;`: los nombres no pueden contener `;` ni saltos de línea.
- El precio se representa con `double` para mantener el modelo de la UT3; en aplicaciones económicas reales es preferible `BigDecimal`.
- La implementación CSV no ofrece bloqueo ni concurrencia multiusuario.
- El programa usa una vista de consola, no una interfaz gráfica; MVC también puede aplicarse en consola.
