package es.iesisidra.inventario.dao;
import es.iesisidra.inventario.modelo.Producto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
public class ProductoFicheroDAO implements ProductoDAO {
    private final Path ruta;
    public ProductoFicheroDAO(Path ruta) { this.ruta = ruta; }
    @Override public List<Producto> listar() {
        if (!Files.exists(ruta)) return new ArrayList<>();
        try {
            List<Producto> productos = new ArrayList<>();
            try (var lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
                String linea;
                int numeroLinea = 0;
                while ((linea = lector.readLine()) != null) {
                numeroLinea++;
                if (linea.isBlank() || linea.equals("id;nombre;precio;stock")) continue;
                String[] c = linea.split(";", -1);
                if (c.length != 4) throw new IllegalStateException("CSV incorrecto: " + linea);
                try {
                    productos.add(new Producto(Integer.parseInt(c[0]), c[1],
                            Double.parseDouble(c[2]), Integer.parseInt(c[3])));
                } catch (NumberFormatException e) {
                    throw new IllegalStateException("Valores incorrectos en CSV, línea " + numeroLinea, e);
                }
            }
            }
            return productos;
        } catch (IOException e) { throw new IllegalStateException("Error al leer CSV", e); }
    }
    @Override public Optional<Producto> buscarPorId(int id) {
        return listar().stream().filter(p -> p.id() == id).findFirst();
    }
    @Override public void insertar(Producto p) {
        List<Producto> productos = listar();
        if (productos.stream().anyMatch(x -> x.id() == p.id())) throw new IllegalArgumentException("El ID ya existe");
        productos.add(p);
        guardar(productos);
    }
    @Override public boolean actualizar(Producto p) {
        List<Producto> productos = listar();
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).id() == p.id()) {
                productos.set(i, p); guardar(productos); return true;
            }
        }
        return false;
    }
    @Override public boolean eliminar(int id) {
        List<Producto> productos = listar();
        boolean eliminado = productos.removeIf(p -> p.id() == id);
        if (eliminado) guardar(productos);
        return eliminado;
    }
    private void guardar(List<Producto> productos) {
        Path temporal = null;
        try {
            Path destino = ruta.toAbsolutePath();
            Path carpeta = destino.getParent();
            Files.createDirectories(carpeta);
            temporal = Files.createTempFile(carpeta, "inventario-", ".tmp");
            try (var escritor = Files.newBufferedWriter(temporal, StandardCharsets.UTF_8)) {
                escritor.write("id;nombre;precio;stock");
                escritor.newLine();
                for (Producto p : productos) {
                    if (p.nombre().contains(";") || p.nombre().contains("\\n")
                            || p.nombre().contains("\\r")) {
                        throw new IllegalArgumentException("Nombre incompatible con el CSV simplificado");
                    }
                    escritor.write(p.id() + ";" + p.nombre() + ";" + p.precio() + ";" + p.stock());
                    escritor.newLine();
                }
            }
            try {
                Files.move(temporal, destino, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temporal, destino, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Error al guardar CSV", e);
        } finally {
            if (temporal != null) {
                try { Files.deleteIfExists(temporal); }
                catch (IOException ignored) { /* El temporal se eliminará manualmente si es necesario. */ }
            }
        }
    }
}
