package es.iesisidra.inventario.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Factoría de conexiones JDBC; cada DAO cierra su conexión con try-with-resources. */
public final class ConexionBD {
    private final String url;
    private final String usuario;
    private final String password;

    public ConexionBD(String url, String usuario, String password) {
        this.url = url;
        this.usuario = usuario;
        this.password = password;
    }

    public Connection abrir() throws SQLException {
        return DriverManager.getConnection(url, usuario, password);
    }
}
