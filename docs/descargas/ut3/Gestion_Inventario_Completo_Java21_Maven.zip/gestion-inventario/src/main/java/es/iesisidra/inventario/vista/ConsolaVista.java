package es.iesisidra.inventario.vista;

import es.iesisidra.inventario.modelo.Producto;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

/** Única clase que lee teclado y presenta mensajes al usuario. */
public final class ConsolaVista {
    private final Scanner teclado;
    private final PrintStream salida;

    public ConsolaVista(Scanner teclado, PrintStream salida) {
        this.teclado = teclado;
        this.salida = salida;
    }

    public int solicitarOpcion() {
        salida.println("\n=== GESTIÓN DE INVENTARIO ===");
        salida.println("1. Alta  2. Buscar  3. Listar  4. Modificar  5. Eliminar  0. Salir");
        return leerEntero("Opción: ");
    }

    public Producto solicitarProducto() {
        int id = solicitarId();
        String nombre = leerTexto("Nombre: ");
        double precio = leerDecimal("Precio (punto decimal): ");
        int stock = leerEntero("Stock: ");
        return new Producto(id, nombre, precio, stock);
    }

    public int solicitarId() { return leerEntero("ID: "); }

    public void mostrarProducto(Producto p) {
        salida.printf("ID: %d | Nombre: %s | Precio: %.2f | Stock: %d%n",
                p.id(), p.nombre(), p.precio(), p.stock());
    }

    public void mostrarProductos(List<Producto> productos) {
        if (productos.isEmpty()) {
            mostrarMensaje("No hay productos.");
            return;
        }
        productos.forEach(this::mostrarProducto);
    }

    public void mostrarMensaje(String mensaje) { salida.println(mensaje); }
    public void mostrarError(String mensaje) { salida.println("Error: " + mensaje); }

    private String leerTexto(String etiqueta) {
        salida.print(etiqueta);
        if (!teclado.hasNextLine()) throw new IllegalStateException("Entrada finalizada");
        return teclado.nextLine().trim();
    }

    private int leerEntero(String etiqueta) {
        while (true) {
            try { return Integer.parseInt(leerTexto(etiqueta)); }
            catch (NumberFormatException e) { mostrarError("Introduce un entero válido."); }
        }
    }

    private double leerDecimal(String etiqueta) {
        while (true) {
            try { return Double.parseDouble(leerTexto(etiqueta)); }
            catch (NumberFormatException e) { mostrarError("Introduce un decimal válido, por ejemplo 19.95."); }
        }
    }
}
