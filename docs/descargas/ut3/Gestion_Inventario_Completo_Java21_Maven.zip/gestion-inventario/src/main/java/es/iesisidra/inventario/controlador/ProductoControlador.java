package es.iesisidra.inventario.controlador;

import es.iesisidra.inventario.modelo.Producto;
import es.iesisidra.inventario.servicio.ProductoService;
import es.iesisidra.inventario.vista.ConsolaVista;

/** Coordina casos de uso; no lee teclado, no imprime ni ejecuta SQL. */
public final class ProductoControlador {
    private final ConsolaVista vista;
    private final ProductoService servicio;

    public ProductoControlador(ConsolaVista vista, ProductoService servicio) {
        this.vista = vista;
        this.servicio = servicio;
    }

    public void iniciar() {
        boolean continuar = true;
        while (continuar) {
            try {
                continuar = ejecutarOpcion(vista.solicitarOpcion());
            } catch (IllegalArgumentException | IllegalStateException e) {
                vista.mostrarError(e.getMessage());
                if ("Entrada finalizada".equals(e.getMessage())) continuar = false;
            }
        }
    }

    private boolean ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 0 -> { vista.mostrarMensaje("Hasta pronto."); return false; }
            case 1 -> alta();
            case 2 -> buscar();
            case 3 -> listar();
            case 4 -> modificar();
            case 5 -> eliminar();
            default -> vista.mostrarError("Opción no válida.");
        }
        return true;
    }

    private void alta() {
        Producto producto = vista.solicitarProducto();
        servicio.alta(producto);
        vista.mostrarMensaje("Producto registrado.");
    }

    private void buscar() {
        servicio.buscar(vista.solicitarId()).ifPresentOrElse(
                vista::mostrarProducto,
                () -> vista.mostrarMensaje("Producto no encontrado."));
    }

    private void listar() { vista.mostrarProductos(servicio.listar()); }

    private void modificar() {
        boolean actualizado = servicio.modificar(vista.solicitarProducto());
        vista.mostrarMensaje(actualizado ? "Producto modificado." : "Producto no encontrado.");
    }

    private void eliminar() {
        boolean eliminado = servicio.baja(vista.solicitarId());
        vista.mostrarMensaje(eliminado ? "Producto eliminado." : "Producto no encontrado.");
    }
}
