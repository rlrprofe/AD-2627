package es.iesisidra.inventario;

import es.iesisidra.inventario.configuracion.Configuracion;
import es.iesisidra.inventario.configuracion.FabricaDao;
import es.iesisidra.inventario.controlador.ProductoControlador;
import es.iesisidra.inventario.servicio.ProductoService;
import es.iesisidra.inventario.vista.ConsolaVista;
import java.util.Scanner;

/** Punto de entrada: solo ensambla las dependencias y arranca la aplicación. */
public final class App {
    private App() { }

    public static void main(String[] args) {
        try {
            Configuracion configuracion = Configuracion.cargar();
            ProductoService servicio = new ProductoService(FabricaDao.crear(configuracion));
            try (Scanner teclado = new Scanner(System.in)) {
                ConsolaVista vista = new ConsolaVista(teclado, System.out);
                new ProductoControlador(vista, servicio).iniciar();
            }
        } catch (RuntimeException e) {
            System.err.println("No se pudo iniciar la aplicación: " + e.getMessage());
        }
    }
}
