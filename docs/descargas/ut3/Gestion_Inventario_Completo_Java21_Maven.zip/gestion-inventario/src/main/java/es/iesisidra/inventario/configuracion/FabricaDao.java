package es.iesisidra.inventario.configuracion;

import es.iesisidra.inventario.dao.ProductoDAO;
import es.iesisidra.inventario.dao.ProductoFicheroDAO;
import es.iesisidra.inventario.dao.ProductoJdbcDAO;
import es.iesisidra.inventario.util.ConexionBD;
import java.nio.file.Path;
import java.util.Locale;

/** Decide la persistencia; ni el controlador ni el servicio conocen el modo. */
public final class FabricaDao {
    private FabricaDao() { }

    public static ProductoDAO crear(Configuracion config) {
        return switch (config.obtener("almacenamiento.tipo", "csv").toLowerCase(Locale.ROOT)) {
            case "csv" -> new ProductoFicheroDAO(Path.of(config.obligatorio("csv.ruta")));
            case "mysql" -> new ProductoJdbcDAO(new ConexionBD(
                    config.obligatorio("db.url"),
                    config.obligatorio("db.usuario"),
                    config.obligatorio("db.password")));
            default -> throw new IllegalArgumentException("almacenamiento.tipo debe ser csv o mysql");
        };
    }
}
