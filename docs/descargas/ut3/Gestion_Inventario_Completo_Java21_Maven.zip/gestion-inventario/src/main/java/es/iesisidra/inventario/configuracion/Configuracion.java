package es.iesisidra.inventario.configuracion;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Lee configuracion.properties externo, sin credenciales incrustadas en Java. */
public final class Configuracion {
    private final Properties valores;

    private Configuracion(Properties valores) { this.valores = valores; }

    public static Configuracion cargar() {
        Path ruta = Path.of("config", "configuracion.properties");
        if (!Files.isRegularFile(ruta)) {
            throw new IllegalStateException("Falta " + ruta + ". Copia configuracion.properties.example y rellena sus datos.");
        }
        Properties p = new Properties();
        try (InputStream entrada = Files.newInputStream(ruta)) {
            p.load(entrada);
        } catch (IOException e) {
            throw new IllegalStateException("No se puede leer " + ruta, e);
        }
        return new Configuracion(p);
    }

    public String obligatorio(String clave) {
        String valor = valores.getProperty(clave, "").trim();
        if (valor.isEmpty()) throw new IllegalStateException("Falta la propiedad: " + clave);
        return valor;
    }
    public String obtener(String clave, String defecto) {
        return valores.getProperty(clave, defecto).trim();
    }
}
