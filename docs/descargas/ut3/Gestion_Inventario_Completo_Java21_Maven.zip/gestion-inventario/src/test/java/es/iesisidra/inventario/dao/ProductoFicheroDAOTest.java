package es.iesisidra.inventario.dao;

import es.iesisidra.inventario.modelo.Producto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class ProductoFicheroDAOTest {
    @TempDir Path temporal;

    @Test void crudSeConservaAlReabrirElFichero() {
        Path ruta = temporal.resolve("productos.csv");
        ProductoDAO dao = new ProductoFicheroDAO(ruta);
        dao.insertar(new Producto(1, "Teclado", 19.95, 5));
        assertEquals(1, new ProductoFicheroDAO(ruta).listar().size());
        assertTrue(dao.actualizar(new Producto(1, "Teclado USB", 20.0, 3)));
        assertEquals("Teclado USB", dao.buscarPorId(1).orElseThrow().nombre());
        assertTrue(dao.eliminar(1));
        assertTrue(new ProductoFicheroDAO(ruta).listar().isEmpty());
    }

    @Test void noAdmiteDuplicados() {
        ProductoDAO dao = new ProductoFicheroDAO(temporal.resolve("datos.csv"));
        dao.insertar(new Producto(1, "Ratón", 10.0, 2));
        assertThrows(IllegalArgumentException.class,
                () -> dao.insertar(new Producto(1, "Otro", 2.0, 1)));
    }
}
