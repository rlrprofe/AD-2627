package es.iesisidra.inventario.controlador;

import es.iesisidra.inventario.dao.ProductoDAO;
import es.iesisidra.inventario.dao.ProductoFicheroDAO;
import es.iesisidra.inventario.servicio.ProductoService;
import es.iesisidra.inventario.vista.ConsolaVista;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;

class ProductoControladorTest {
    @TempDir Path temporal;

    @Test void altaListadoYSalidaDesdeConsolaSimulada() throws Exception {
        ProductoDAO dao = new ProductoFicheroDAO(temporal.resolve("datos.csv"));
        String entradas = "1\n7\nMonitor\n149.99\n6\n3\n0\n";
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (Scanner scanner = new Scanner(entradas);
             PrintStream salida = new PrintStream(buffer, true, StandardCharsets.UTF_8)) {
            new ProductoControlador(new ConsolaVista(scanner, salida),
                    new ProductoService(dao)).iniciar();
        }
        String texto = buffer.toString(StandardCharsets.UTF_8);
        assertTrue(texto.contains("Producto registrado"));
        assertTrue(texto.contains("Monitor"));
        assertTrue(texto.contains("Hasta pronto"));
        assertEquals(1, dao.listar().size());
    }
}
