# Gestión de productos · UT3 (Java 21 + Maven)

Proyecto didáctico que demuestra el patrón DAO con dos implementaciones: CSV y MySQL/JDBC.

## Requisitos

- JDK 21 y Maven.
- Para modo JDBC: MySQL y el script `01-productos.sql` ejecutado previamente.

## Ejecutar en modo CSV

Desde la carpeta del `pom.xml`:

```powershell
mvn clean test
mvn exec:java
```

El fichero `datos/productos.csv` se crea al guardar el primer producto. El modo por defecto es CSV.

## Ejecutar en modo JDBC (PowerShell)

```powershell
$env:UT3_MODO="jdbc"
$env:UT3_DB_URL="jdbc:mysql://localhost:3306/ut3_componentes"
$env:UT3_DB_USER="usuario"
$env:UT3_DB_PASSWORD="tu_clave"
mvn exec:java
```

No publiques credenciales en GitHub. Las variables de entorno solo se utilizan durante la ejecución.

## Organización

- `modelo/Producto.java`: datos del producto.
- `dao/ProductoDAO.java`: contrato de persistencia.
- `dao/ProductoFicheroDAO.java`: implementación CSV.
- `dao/ProductoJdbcDAO.java`: implementación JDBC.
- `servicio/ProductoService.java`: validaciones y reglas de negocio.
- `Main.java`: menú y selección del componente.

## Pruebas

```powershell
mvn test
```

Incluye pruebas JUnit del componente CSV. **No se incluyen pruebas automáticas JDBC**, pues requieren un servidor MySQL configurado.

## Limitaciones didácticas

- CSV simple separado por `;`, sin campos entrecomillados ni escapado general. El servicio rechaza nombres con `;` o saltos de línea.
- La implementación CSV no está diseñada para escrituras concurrentes.
- Para simplificar el modelo se utiliza `double` para el precio; en aplicaciones monetarias reales es preferible `BigDecimal`.
- La sustitución del fichero CSV se realiza mediante un temporal, pero no garantiza atomicidad en todos los sistemas.
- Los modos CSV y JDBC guardan datos independientes; no hay migración entre ellos.

## Empaquetar

```powershell
mvn package
```

El JAR estándar no incluye automáticamente las dependencias externas. Para ejecutar el ejemplo de forma sencilla se recomienda `mvn exec:java`.
