package es.iesisidra.productos.dao;

import es.iesisidra.productos.modelo.Producto;
import es.iesisidra.productos.servicio.ProductoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class ProductoFicheroDAOTest {
    @TempDir Path carpetaTemporal;

    @Test
    void guardarYBuscar() throws Exception {
        ProductoDAO dao = new ProductoFicheroDAO(carpetaTemporal.resolve("productos.csv"));
        Producto producto = new Producto(1, "Teclado", 25.0);
        dao.guardar(producto);
        assertEquals(producto, dao.buscarPorId(1).orElseThrow());
        assertEquals(1, dao.listar().size());
    }

    @Test
    void buscarInexistente() throws Exception {
        ProductoDAO dao = new ProductoFicheroDAO(carpetaTemporal.resolve("productos.csv"));
        assertTrue(dao.buscarPorId(999).isEmpty());
    }

    @Test
    void rechazarIdDuplicado() throws Exception {
        ProductoDAO dao = new ProductoFicheroDAO(carpetaTemporal.resolve("productos.csv"));
        dao.guardar(new Producto(1, "Teclado", 25.0));
        assertThrows(AccesoDatosException.class, () -> dao.guardar(new Producto(1, "Ratón", 15.0)));
    }

    @Test
    void validarPrecioNegativo() {
        ProductoDAO dao = new ProductoFicheroDAO(carpetaTemporal.resolve("productos.csv"));
        ProductoService servicio = new ProductoService(dao);
        assertThrows(IllegalArgumentException.class, () -> servicio.registrar(new Producto(1, "Teclado", -5.0)));
    }
}
