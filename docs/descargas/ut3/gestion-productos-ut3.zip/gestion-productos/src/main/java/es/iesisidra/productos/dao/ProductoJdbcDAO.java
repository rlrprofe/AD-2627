package es.iesisidra.productos.dao;

import es.iesisidra.productos.modelo.Producto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** DAO JDBC para la tabla productos de MySQL. */
public class ProductoJdbcDAO implements ProductoDAO {
    private final String url;
    private final String usuario;
    private final String clave;

    public ProductoJdbcDAO(String url, String usuario, String clave) {
        this.url = url;
        this.usuario = usuario;
        this.clave = clave;
    }

    @Override
    public void guardar(Producto producto) throws AccesoDatosException {
        String sql = "INSERT INTO productos (id, nombre, precio) VALUES (?, ?, ?)";
        try (Connection conexion = DriverManager.getConnection(url, usuario, clave);
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, producto.id());
            ps.setString(2, producto.nombre());
            ps.setDouble(3, producto.precio());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new AccesoDatosException("No se pudo guardar el producto (ID duplicado o error JDBC)", e);
        }
    }

    @Override
    public Optional<Producto> buscarPorId(int id) throws AccesoDatosException {
        String sql = "SELECT id, nombre, precio FROM productos WHERE id = ?";
        try (Connection conexion = DriverManager.getConnection(url, usuario, clave);
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(leerProducto(rs));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new AccesoDatosException("No se pudo buscar el producto", e);
        }
    }

    @Override
    public List<Producto> listar() throws AccesoDatosException {
        String sql = "SELECT id, nombre, precio FROM productos ORDER BY id";
        List<Producto> productos = new ArrayList<>();
        try (Connection conexion = DriverManager.getConnection(url, usuario, clave);
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                productos.add(leerProducto(rs));
            }
            return productos;
        } catch (SQLException e) {
            throw new AccesoDatosException("No se pudieron listar los productos", e);
        }
    }

    private Producto leerProducto(ResultSet rs) throws SQLException {
        return new Producto(rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio"));
    }
}
