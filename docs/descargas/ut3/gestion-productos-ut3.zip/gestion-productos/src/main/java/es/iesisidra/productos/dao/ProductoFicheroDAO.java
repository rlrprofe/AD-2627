package es.iesisidra.productos.dao;

import es.iesisidra.productos.modelo.Producto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** DAO para un CSV didáctico con separador punto y coma y sin escapado. */
public class ProductoFicheroDAO implements ProductoDAO {
    private static final String CABECERA = "id;nombre;precio";
    private final Path ruta;

    public ProductoFicheroDAO(Path ruta) {
        this.ruta = ruta;
    }

    @Override
    public void guardar(Producto producto) throws AccesoDatosException {
        List<Producto> productos = listar();
        for (Producto existente : productos) {
            if (existente.id() == producto.id()) {
                throw new AccesoDatosException("Ya existe un producto con ID " + producto.id());
            }
        }
        productos.add(producto);
        escribirTodos(productos);
    }

    @Override
    public Optional<Producto> buscarPorId(int id) throws AccesoDatosException {
        for (Producto producto : listar()) {
            if (producto.id() == id) {
                return Optional.of(producto);
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Producto> listar() throws AccesoDatosException {
        List<Producto> productos = new ArrayList<>();
        if (!Files.exists(ruta)) {
            return productos;
        }
        try {
            List<String> lineas = Files.readAllLines(ruta, StandardCharsets.UTF_8);
            if (lineas.isEmpty()) {
                throw new AccesoDatosException("CSV vacío: falta la cabecera");
            }
            if (!CABECERA.equals(lineas.get(0))) {
                throw new AccesoDatosException("Cabecera CSV incorrecta");
            }
            for (int i = 1; i < lineas.size(); i++) {
                String linea = lineas.get(i);
                String[] campos = linea.split(";", -1);
                if (campos.length != 3) {
                    throw new AccesoDatosException("Línea " + (i + 1) + " mal formada");
                }
                try {
                    int id = Integer.parseInt(campos[0]);
                    String nombre = campos[1];
                    double precio = Double.parseDouble(campos[2]);
                    productos.add(new Producto(id, nombre, precio));
                } catch (NumberFormatException e) {
                    throw new AccesoDatosException("Dato numérico inválido en línea " + (i + 1), e);
                }
            }
            return productos;
        } catch (IOException e) {
            throw new AccesoDatosException("No se pudo leer " + ruta, e);
        }
    }

    private void escribirTodos(List<Producto> productos) throws AccesoDatosException {
        Path temporal = null;
        try {
            Path absoluta = ruta.toAbsolutePath();
            Path carpeta = absoluta.getParent();
            Files.createDirectories(carpeta);
            List<String> lineas = new ArrayList<>();
            lineas.add(CABECERA);
            for (Producto producto : productos) {
                lineas.add(producto.id() + ";" + producto.nombre() + ";" + producto.precio());
            }
            temporal = Files.createTempFile(carpeta, "productos-", ".tmp");
            Files.write(temporal, lineas, StandardCharsets.UTF_8);
            // Sustitución del fichero; la operación no garantiza atomicidad en todos los sistemas.
            Files.move(temporal, absoluta, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new AccesoDatosException("No se pudo escribir " + ruta, e);
        } finally {
            if (temporal != null) {
                try {
                    Files.deleteIfExists(temporal);
                } catch (IOException ignored) {
                    // El fallo principal, si existe, no debe quedar oculto.
                }
            }
        }
    }
}
