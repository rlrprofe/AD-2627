package es.iesisidra.productos.dao;

import es.iesisidra.productos.modelo.Producto;
import java.util.List;
import java.util.Optional;

/** Contrato para almacenar y recuperar productos. */
public interface ProductoDAO {
    /**
     * Guarda un producto nuevo.
     * @param producto producto que se guardará
     * @throws AccesoDatosException si existe el ID o falla el almacenamiento
     */
    void guardar(Producto producto) throws AccesoDatosException;

    /**
     * Busca un producto por su identificador.
     * @param id identificador del producto
     * @return producto encontrado o vacío si no existe
     * @throws AccesoDatosException si falla el almacenamiento
     */
    Optional<Producto> buscarPorId(int id) throws AccesoDatosException;

    /**
     * Recupera todos los productos.
     * @return lista de productos, vacía si no existen
     * @throws AccesoDatosException si falla el almacenamiento
     */
    List<Producto> listar() throws AccesoDatosException;
}
