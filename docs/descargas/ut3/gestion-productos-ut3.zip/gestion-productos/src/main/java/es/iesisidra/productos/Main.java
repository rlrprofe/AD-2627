package es.iesisidra.productos;

import es.iesisidra.productos.dao.AccesoDatosException;
import es.iesisidra.productos.dao.ProductoDAO;
import es.iesisidra.productos.dao.ProductoFicheroDAO;
import es.iesisidra.productos.dao.ProductoJdbcDAO;
import es.iesisidra.productos.modelo.Producto;
import es.iesisidra.productos.servicio.ProductoService;
import java.nio.file.Path;
import java.util.Scanner;

/** Menú de consola: no accede directamente al fichero ni ejecuta SQL. */
public class Main {
    public static void main(String[] args) {
        String modo = System.getenv().getOrDefault("UT3_MODO", "csv");
        ProductoDAO dao;
        if ("jdbc".equalsIgnoreCase(modo)) {
            String url = System.getenv().getOrDefault("UT3_DB_URL", "jdbc:mysql://localhost:3306/ut3_componentes");
            String usuario = System.getenv().getOrDefault("UT3_DB_USER", "root");
            String clave = System.getenv("UT3_DB_PASSWORD");
            if (clave == null) {
                System.err.println("Falta configurar UT3_DB_PASSWORD para modo JDBC.");
                return;
            }
            dao = new ProductoJdbcDAO(url, usuario, clave);
        } else if ("csv".equalsIgnoreCase(modo)) {
            dao = new ProductoFicheroDAO(Path.of("datos", "productos.csv"));
        } else {
            System.err.println("UT3_MODO debe ser csv o jdbc.");
            return;
        }

        ProductoService servicio = new ProductoService(dao);
        System.out.println("Almacenamiento seleccionado: " + modo);
        try (Scanner teclado = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n1. Guardar  2. Buscar  3. Listar  0. Salir");
                System.out.print("Opción: ");
                String opcion = teclado.nextLine().trim();
                try {
                    switch (opcion) {
                        case "1" -> {
                            System.out.print("ID: ");
                            int id = Integer.parseInt(teclado.nextLine());
                            System.out.print("Nombre: ");
                            String nombre = teclado.nextLine();
                            System.out.print("Precio: ");
                            double precio = Double.parseDouble(teclado.nextLine().replace(',', '.'));
                            servicio.registrar(new Producto(id, nombre, precio));
                            System.out.println("Producto guardado.");
                        }
                        case "2" -> {
                            System.out.print("ID: ");
                            int id = Integer.parseInt(teclado.nextLine());
                            var resultado = servicio.buscar(id);
                            if (resultado.isPresent()) {
                                System.out.println(resultado.get());
                            } else {
                                System.out.println("No encontrado");
                            }
                        }
                        case "3" -> {
                            for (Producto producto : servicio.listar()) {
                                System.out.println(producto);
                            }
                        }
                        case "0" -> { return; }
                        default -> System.out.println("Opción desconocida.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Dato numérico incorrecto.");
                } catch (IllegalArgumentException | AccesoDatosException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }
}
