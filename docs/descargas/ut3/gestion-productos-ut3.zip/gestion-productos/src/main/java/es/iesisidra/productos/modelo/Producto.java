package es.iesisidra.productos.modelo;

/** Datos inmutables de un producto. */
public record Producto(int id, String nombre, double precio) { }
