package es.iesisidra.productos.dao;

/** Error ocurrido al consultar o modificar el almacenamiento. */
public class AccesoDatosException extends Exception {
    public AccesoDatosException(String mensaje) {
        super(mensaje);
    }

    public AccesoDatosException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
