package es.iesisidra.productos.servicio;

import es.iesisidra.productos.dao.AccesoDatosException;
import es.iesisidra.productos.dao.ProductoDAO;
import es.iesisidra.productos.modelo.Producto;
import java.util.List;
import java.util.Optional;

/** Reglas de negocio; desconoce si los datos están en CSV o MySQL. */
public class ProductoService {
    private final ProductoDAO dao;

    public ProductoService(ProductoDAO dao) {
        this.dao = dao;
    }

    public void registrar(Producto producto) throws AccesoDatosException {
        if (producto.id() <= 0) {
            throw new IllegalArgumentException("El ID debe ser positivo");
        }
        if (producto.nombre() == null || producto.nombre().isBlank() ||
                producto.nombre().contains(";") || producto.nombre().contains("\n") ||
                producto.nombre().contains("\r")) {
            throw new IllegalArgumentException("Nombre vacío o con caracteres no admitidos (; o saltos de línea)");
        }
        if (!Double.isFinite(producto.precio()) || producto.precio() < 0) {
            throw new IllegalArgumentException("El precio debe ser un número no negativo y finito");
        }
        dao.guardar(producto);
    }

    public Optional<Producto> buscar(int id) throws AccesoDatosException {
        return dao.buscarPorId(id);
    }

    public List<Producto> listar() throws AccesoDatosException {
        return dao.listar();
    }
}
