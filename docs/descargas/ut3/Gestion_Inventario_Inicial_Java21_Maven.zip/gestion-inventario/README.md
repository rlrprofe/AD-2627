# Gestión de inventario — proyecto inicial

Requisitos: JDK 21 y Maven. Este proyecto **no es la solución completa**.

Contiene `Producto` y el contrato `ProductoDAO`. Desarrolla progresivamente `ProductoService`, `ProductoFicheroDAO`, `ProductoJdbcDAO`, `ConexionBD` y `App` siguiendo las páginas 3.3–3.7 de la UT3. Incorpora las dependencias y los plugins Maven cuando correspondan.

Comprobación inicial: `mvn compile`.
