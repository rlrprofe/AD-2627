package es.dam.jdbc.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Centraliza la configuración y apertura de conexiones a MySQL.
 * Lee los datos desde db.properties, sin recurrir a variables de entorno.
 */
public final class ConexionBD {

    /** Evita crear objetos de una clase que solo ofrece métodos estáticos. */
    private ConexionBD() { }

    /**
     * Abre una conexión JDBC con los datos del archivo db.properties.
     *
     * @return conexión abierta; quien la recibe debe cerrarla con try-with-resources
     * @throws SQLException si falta la configuración o falla la conexión
     */
    public static Connection abrir() throws SQLException {
        Properties propiedades = new Properties();

        // El archivo se busca en el classpath: src/main/resources/db.properties.
        // InputStream es un recurso y se cierra automáticamente.
        try (InputStream entrada = ConexionBD.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (entrada == null) {
                throw new SQLException("No se encuentra db.properties en src/main/resources. "
                        + "Copia db.properties.example y completa sus datos.");
            }
            propiedades.load(entrada);
        } catch (IOException e) {
            // Conservamos la causa original para facilitar el diagnóstico.
            throw new SQLException("No se pudo leer db.properties", e);
        }

        String url = obtenerObligatoria(propiedades, "db.url");
        String usuario = obtenerObligatoria(propiedades, "db.user");
        String clave = obtenerObligatoria(propiedades, "db.password");

        // La conexión se devuelve abierta: el DAO la cerrará con try-with-resources.
        return DriverManager.getConnection(url, usuario, clave);
    }

    /**
     * Recupera una propiedad obligatoria y comprueba que no esté vacía.
     *
     * @param propiedades conjunto de propiedades cargadas
     * @param clave nombre de la propiedad requerida
     * @return valor de la propiedad sin espacios exteriores
     * @throws SQLException si no existe o está vacía
     */
    private static String obtenerObligatoria(Properties propiedades, String clave) throws SQLException {
        String valor = propiedades.getProperty(clave);
        if (valor == null || valor.isBlank()) {
            throw new SQLException("Falta la propiedad obligatoria '" + clave + "' en db.properties");
        }
        return valor.trim();
    }
}
