package es.dam.jdbc.servicio;

import es.dam.jdbc.dao.ProductoDAO;
import es.dam.jdbc.modelo.Producto;
import java.sql.SQLException;
import java.util.List;

/**
 * Capa de servicio: valida los datos antes de delegar en el DAO.
 * No contiene instrucciones SQL ni gestiona conexiones JDBC.
 */
public class ProductoService {
    private final ProductoDAO dao = new ProductoDAO();

    /**
     * Solicita al DAO todos los productos.
     *
     * @return lista de productos
     * @throws SQLException si falla la consulta
     */
    public List<Producto> listar() throws SQLException {
        return dao.listar();
    }

    /**
     * Valida e inserta un producto.
     *
     * @param producto producto que se desea crear
     * @return número de filas insertadas
     * @throws IllegalArgumentException si los datos no son válidos
     * @throws SQLException si falla la inserción
     */
    public int insertar(Producto producto) throws SQLException {
        // La validación pertenece al servicio, no a la clase que ejecuta SQL.
        if (producto == null || producto.getNumero() <= 0
                || producto.getDescripcion() == null || producto.getDescripcion().isBlank()
                || producto.getPrecio() == null || producto.getPrecio().signum() < 0
                || producto.getStock() < 0) {
            throw new IllegalArgumentException("Producto no válido");
        }
        return dao.insertar(producto);
    }

    /**
     * Valida el identificador y el nuevo stock antes de actualizar.
     *
     * @param numero identificador del producto
     * @param stock nuevo stock (no negativo)
     * @return número de filas actualizadas
     * @throws IllegalArgumentException si los valores no son válidos
     * @throws SQLException si falla la actualización
     */
    public int actualizarStock(int numero, int stock) throws SQLException {
        if (numero <= 0 || stock < 0) {
            throw new IllegalArgumentException("Identificador o stock no válido");
        }
        return dao.actualizarStock(numero, stock);
    }

    /**
     * Valida el identificador y elimina el producto correspondiente.
     *
     * @param numero identificador del producto
     * @return número de filas eliminadas
     * @throws IllegalArgumentException si el identificador no es válido
     * @throws SQLException si falla la eliminación
     */
    public int eliminar(int numero) throws SQLException {
        if (numero <= 0) {
            throw new IllegalArgumentException("Identificador no válido");
        }
        return dao.eliminar(numero);
    }
}
