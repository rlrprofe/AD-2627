package es.dam.jdbc.servicio;
import es.dam.jdbc.dao.ProductoDAO;
import es.dam.jdbc.modelo.Producto;
import java.sql.SQLException;
import java.util.List;
/** Valida reglas de negocio antes de llamar al DAO. */
public class ProductoService {
    private final ProductoDAO dao = new ProductoDAO();
    public List<Producto> listar() throws SQLException { return dao.listar(); }
    public int insertar(Producto p) throws SQLException {
        if (p.numero() <= 0 || p.descripcion() == null || p.descripcion().isBlank()
                || p.precio() == null || p.precio().signum() < 0 || p.stock() < 0) {
            throw new IllegalArgumentException("Producto no válido");
        }
        return dao.insertar(p);
    }
    public int actualizarStock(int numero, int stock) throws SQLException {
        if (numero <= 0 || stock < 0) throw new IllegalArgumentException("Identificador o stock no válido");
        return dao.actualizarStock(numero, stock);
    }
    public int eliminar(int numero) throws SQLException {
        if (numero <= 0) throw new IllegalArgumentException("Identificador no válido");
        return dao.eliminar(numero);
    }
}
