package es.dam.jdbc.modelo;
import java.math.BigDecimal;
/** Datos de un producto; no contiene instrucciones SQL. */
public record Producto(int numero, String descripcion, BigDecimal precio, int stock) { }
