package es.dam.jdbc.modelo;

import java.math.BigDecimal;

/**
 * Modelo de un producto almacenado en la tabla {@code productos}.
 * Los atributos son privados para respetar la encapsulación.
 */
public class Producto {

    /** Identificador único del producto. */
    private int numero;
    /** Nombre o descripción del producto. */
    private String descripcion;
    /** Precio actual del producto. */
    private BigDecimal precio;
    /** Cantidad de unidades disponibles. */
    private int stock;

    /**
     * Construye un producto con todos sus datos.
     *
     * @param numero identificador del producto
     * @param descripcion nombre o descripción del producto
     * @param precio precio actual del producto
     * @param stock unidades disponibles
     */
    public Producto(int numero, String descripcion, BigDecimal precio, int stock) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
    }

    /** @return identificador del producto */
    public int getNumero() {
        return numero;
    }

    /** @param numero nuevo identificador del producto */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /** @return descripción del producto */
    public String getDescripcion() {
        return descripcion;
    }

    /** @param descripcion nueva descripción del producto */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /** @return precio actual del producto */
    public BigDecimal getPrecio() {
        return precio;
    }

    /** @param precio nuevo precio del producto */
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    /** @return unidades disponibles del producto */
    public int getStock() {
        return stock;
    }

    /** @param stock nueva cantidad de unidades disponibles */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Devuelve una representación legible de los datos del producto.
     *
     * @return texto con los atributos del producto
     */
    @Override
    public String toString() {
        return "Producto{" +
                "numero=" + numero +
                ", descripcion='" + descripcion + '\'' +
                ", precio=" + precio +
                ", stock=" + stock +
                '}';
    }
}
