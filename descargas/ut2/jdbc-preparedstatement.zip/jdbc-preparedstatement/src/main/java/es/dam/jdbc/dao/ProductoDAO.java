package es.dam.jdbc.dao;

import es.dam.jdbc.config.ConexionBD;
import es.dam.jdbc.modelo.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Capa de acceso a datos (DAO): contiene las sentencias SQL de productos.
 * Utiliza PreparedStatement para separar la consulta de sus parámetros.
 */
public class ProductoDAO {

    /**
     * Consulta todos los productos ordenados por su identificador.
     *
     * @return lista de productos encontrados (vacía si no hay registros)
     * @throws SQLException si se produce un error de acceso a datos
     */
    public List<Producto> listar() throws SQLException {
        String sql = "SELECT producto_no, descripcion, precio_actual, stock_disponible "
                + "FROM productos ORDER BY producto_no";
        List<Producto> productos = new ArrayList<>();

        // Los recursos se cierran en orden inverso: ResultSet, PreparedStatement, Connection.
        try (Connection conexion = ConexionBD.abrir();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            // Cada fila del resultado se transforma en un objeto Producto.
            while (resultado.next()) {
                productos.add(new Producto(
                        resultado.getInt("producto_no"),
                        resultado.getString("descripcion"),
                        resultado.getBigDecimal("precio_actual"),
                        resultado.getInt("stock_disponible")));
            }
        }
        return productos;
    }

    /**
     * Inserta un nuevo producto mediante parámetros posicionados.
     *
     * @param producto datos del producto que se va a insertar
     * @return número de filas insertadas
     * @throws SQLException si falla la operación (por ejemplo, ID duplicado)
     */
    public int insertar(Producto producto) throws SQLException {
        String sql = "INSERT INTO productos "
                + "(producto_no, descripcion, precio_actual, stock_disponible) VALUES (?, ?, ?, ?)";

        try (Connection conexion = ConexionBD.abrir();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            // Los índices de los parámetros empiezan en 1, no en 0.
            sentencia.setInt(1, producto.getNumero());
            sentencia.setString(2, producto.getDescripcion());
            sentencia.setBigDecimal(3, producto.getPrecio());
            sentencia.setInt(4, producto.getStock());
            return sentencia.executeUpdate();
        }
    }

    /**
     * Modifica las unidades disponibles de un producto existente.
     *
     * @param numero identificador del producto
     * @param stock nuevo número de unidades
     * @return número de filas actualizadas (0 si el producto no existe)
     * @throws SQLException si falla la operación SQL
     */
    public int actualizarStock(int numero, int stock) throws SQLException {
        String sql = "UPDATE productos SET stock_disponible = ? WHERE producto_no = ?";

        try (Connection conexion = ConexionBD.abrir();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, stock);
            sentencia.setInt(2, numero);
            return sentencia.executeUpdate();
        }
    }

    /**
     * Elimina el producto identificado por su número.
     *
     * @param numero identificador del producto
     * @return número de filas eliminadas (0 si no existía)
     * @throws SQLException si falla la operación SQL
     */
    public int eliminar(int numero) throws SQLException {
        String sql = "DELETE FROM productos WHERE producto_no = ?";

        try (Connection conexion = ConexionBD.abrir();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, numero);
            return sentencia.executeUpdate();
        }
    }
}
