package es.dam.jdbc.dao;
import es.dam.jdbc.config.ConexionBD;
import es.dam.jdbc.modelo.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Única clase que conoce el SQL de productos. */
public class ProductoDAO {
    public List<Producto> listar() throws SQLException {
        String sql = "SELECT producto_no, descripcion, precio_actual, stock_disponible FROM productos ORDER BY producto_no";
        List<Producto> productos = new ArrayList<>();
        try (Connection con = ConexionBD.abrir();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                productos.add(new Producto(rs.getInt("producto_no"), rs.getString("descripcion"),
                        rs.getBigDecimal("precio_actual"), rs.getInt("stock_disponible")));
            }
        }
        return productos;
    }
    public int insertar(Producto producto) throws SQLException {
        String sql = "INSERT INTO productos (producto_no, descripcion, precio_actual, stock_disponible) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionBD.abrir(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, producto.numero());
            ps.setString(2, producto.descripcion());
            ps.setBigDecimal(3, producto.precio());
            ps.setInt(4, producto.stock());
            return ps.executeUpdate();
        }
    }
    public int actualizarStock(int numero, int stock) throws SQLException {
        String sql = "UPDATE productos SET stock_disponible = ? WHERE producto_no = ?";
        try (Connection con = ConexionBD.abrir(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, stock);
            ps.setInt(2, numero);
            return ps.executeUpdate();
        }
    }
    public int eliminar(int numero) throws SQLException {
        String sql = "DELETE FROM productos WHERE producto_no = ?";
        try (Connection con = ConexionBD.abrir(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, numero);
            return ps.executeUpdate();
        }
    }
}
