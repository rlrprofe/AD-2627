package es.dam.jdbc.app;
import es.dam.jdbc.modelo.Producto;
import es.dam.jdbc.servicio.ProductoService;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Scanner;

/** Presentación por consola: sin SQL ni conexiones directas. */
public class MenuProductos {
    public static void main(String[] args) {
        ProductoService servicio = new ProductoService();
        try (Scanner teclado = new Scanner(System.in)) {
            boolean salir = false;
            while (!salir) {
                System.out.println("\n1 Listar | 2 Insertar | 3 Cambiar stock | 4 Eliminar | 0 Salir");
                String opcion = teclado.nextLine().trim();
                try {
                    switch (opcion) {
                        case "1" -> {
                            for (Producto p : servicio.listar()) System.out.println(p);
                        }
                        case "2" -> {
                            System.out.print("Número: "); int id = Integer.parseInt(teclado.nextLine());
                            System.out.print("Descripción: "); String nombre = teclado.nextLine();
                            System.out.print("Precio: "); BigDecimal precio = new BigDecimal(teclado.nextLine());
                            System.out.print("Stock: "); int stock = Integer.parseInt(teclado.nextLine());
                            System.out.println("Filas insertadas: " + servicio.insertar(new Producto(id,nombre,precio,stock)));
                        }
                        case "3" -> {
                            System.out.print("Número: "); int id = Integer.parseInt(teclado.nextLine());
                            System.out.print("Nuevo stock: "); int stock = Integer.parseInt(teclado.nextLine());
                            System.out.println("Filas actualizadas: " + servicio.actualizarStock(id,stock));
                        }
                        case "4" -> {
                            System.out.print("Número a eliminar: "); int id = Integer.parseInt(teclado.nextLine());
                            System.out.println("Filas eliminadas: " + servicio.eliminar(id));
                        }
                        case "0" -> salir = true;
                        default -> System.out.println("Opción no válida");
                    }
                } catch (SQLException e) {
                    System.err.printf("Error SQL: %s [SQLState=%s, código=%d]%n",e.getMessage(),e.getSQLState(),e.getErrorCode());
                } catch (IllegalArgumentException e) {
                    System.err.println("Entrada incorrecta: " + e.getMessage());
                }
            }
        }
    }
}
