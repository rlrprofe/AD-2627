package es.dam.jdbc.app;

import es.dam.jdbc.modelo.Producto;
import es.dam.jdbc.servicio.ProductoService;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Interfaz de consola para probar las operaciones CRUD de productos.
 * Delega las operaciones en ProductoService; no contiene SQL.
 */
public class MenuProductos {

    /**
     * Inicia el menú interactivo de productos.
     *
     * @param args argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        ProductoService servicio = new ProductoService();

        // Scanner implementa AutoCloseable: se cierra al terminar el menú.
        try (Scanner teclado = new Scanner(System.in)) {
            boolean salir = false;
            while (!salir) {
                System.out.println("\n1 Listar | 2 Insertar | 3 Cambiar stock | 4 Eliminar | 0 Salir");
                String opcion = teclado.nextLine().trim();

                try {
                    switch (opcion) {
                        case "1" -> {
                            // El servicio devuelve objetos; el menú solo los muestra.
                            for (Producto producto : servicio.listar()) {
                                System.out.println(producto);
                            }
                        }
                        case "2" -> {
                            System.out.print("Número: ");
                            int id = Integer.parseInt(teclado.nextLine());
                            System.out.print("Descripción: ");
                            String nombre = teclado.nextLine();
                            System.out.print("Precio: ");
                            BigDecimal precio = new BigDecimal(teclado.nextLine());
                            System.out.print("Stock: ");
                            int stock = Integer.parseInt(teclado.nextLine());
                            Producto producto = new Producto(id, nombre, precio, stock);
                            System.out.println("Filas insertadas: " + servicio.insertar(producto));
                        }
                        case "3" -> {
                            System.out.print("Número: ");
                            int id = Integer.parseInt(teclado.nextLine());
                            System.out.print("Nuevo stock: ");
                            int stock = Integer.parseInt(teclado.nextLine());
                            System.out.println("Filas actualizadas: " + servicio.actualizarStock(id, stock));
                        }
                        case "4" -> {
                            System.out.print("Número a eliminar: ");
                            int id = Integer.parseInt(teclado.nextLine());
                            System.out.println("Filas eliminadas: " + servicio.eliminar(id));
                        }
                        case "0" -> salir = true;
                        default -> System.out.println("Opción no válida");
                    }
                } catch (SQLException e) {
                    // Los errores de acceso a datos se muestran en la capa de presentación.
                    System.err.printf("Error SQL: %s [SQLState=%s, código=%d]%n",
                            e.getMessage(), e.getSQLState(), e.getErrorCode());
                } catch (IllegalArgumentException e) {
                    // Incluye errores de conversión numérica y validaciones del servicio.
                    System.err.println("Entrada incorrecta: " + e.getMessage());
                }
            }
        }
    }
}
