# JDBC: PreparedStatement — CRUD de productos

Proyecto didáctico de **Acceso a Datos (DAM)** con Java 21, Maven, MySQL y JDBC. Permite **listar, insertar, actualizar el stock y eliminar** registros de la tabla `productos` mediante `PreparedStatement`.

## Objetivos

- Comprender la separación de responsabilidades entre modelo, DAO, servicio y presentación.
- Aplicar encapsulación en el modelo `Producto` mediante atributos privados, constructor y métodos de acceso.
- Leer la configuración JDBC desde un archivo `db.properties` usando `java.util.Properties`.
- Utilizar `PreparedStatement` con parámetros `?`, evitando concatenar valores del usuario en SQL.
- Cerrar automáticamente los recursos con **try-with-resources**.
- Interpretar resultados de `executeQuery()` y `executeUpdate()` y gestionar errores SQL.

## Requisitos

- **JDK 21** y **Maven** disponibles (`java -version` y `mvn -version`).
- Servidor **MySQL 8 o superior**.
- Usuario de MySQL con permisos sobre la base de datos `curso`.
- Conector `com.mysql:mysql-connector-j:9.3.0`, gestionado por Maven.

## 1. Preparar la base de datos

Ejecuta `sql/01-curso-original.sql` en MySQL Workbench o en el cliente MySQL.

> **Atención:** el script original incluye `DROP DATABASE IF EXISTS CURSO`: **borra la base de datos existente** y sus datos. Úsalo únicamente en un entorno de prácticas.

Es recomendable utilizar un usuario específico en lugar de `root`. Ejemplo orientativo ejecutado por una cuenta administradora:

```sql
CREATE USER IF NOT EXISTS 'alumno'@'localhost' IDENTIFIED BY 'CAMBIA_ESTA_CLAVE';
GRANT SELECT, INSERT, UPDATE, DELETE ON curso.* TO 'alumno'@'localhost';
```

Comprueba que el usuario tenga acceso desde el host configurado en la URL JDBC.

## 2. Configurar la conexión con db.properties

1. Abre `src/main/resources/`.
2. **Copia** `db.properties.example` y cambia el nombre de la copia a `db.properties`.
3. Edita los datos para que coincidan con tu servidor MySQL:

```properties
db.url=jdbc:mysql://localhost:3306/curso
db.user=alumno
db.password=TU_CLAVE_LOCAL
```

La aplicación carga el archivo desde el **classpath** mediante `getResourceAsStream("db.properties")`. Maven copia los recursos de `src/main/resources` a `target/classes` durante la compilación.

**No se utiliza `System.getenv()` ni ninguna variable de entorno para la conexión.** El archivo `db.properties` está excluido en `.gitignore` para evitar subir contraseñas por accidente. La plantilla `.example` sí puede compartirse. No incluyas contraseñas reales en capturas ni en entregas.

## 3. Compilar

Abre una terminal en la carpeta que contiene `pom.xml` y ejecuta:

```powershell
mvn clean compile
```

El proyecto utiliza `<maven.compiler.release>21</maven.compiler.release>`.

## 4. Ejecutar

En VS Code, abre la carpeta raíz del proyecto y ejecuta la clase:

`es.dam.jdbc.app.MenuProductos`

Aparecerá el menú:

```text
1 Listar | 2 Insertar | 3 Cambiar stock | 4 Eliminar | 0 Salir
```

Prueba a listar los productos, insertar uno con identificador nuevo, modificar su stock y eliminarlo. Contrasta el resultado con MySQL Workbench. Las operaciones modifican realmente los datos de la base de prácticas.

## 5. Organización del proyecto

| Archivo o carpeta | Responsabilidad |
|---|---|
| `config/ConexionBD.java` | Lee `db.properties`, valida las claves y abre conexiones JDBC. |
| `modelo/Producto.java` | Clase modelo con atributos `private`, constructor, getters, setters y `toString()`. |
| `dao/ProductoDAO.java` | Contiene las sentencias SQL y convierte las filas en objetos. |
| `servicio/ProductoService.java` | Comprueba las reglas de validación y llama al DAO. |
| `app/MenuProductos.java` | Interactúa con el usuario y presenta los errores. |
| `src/main/resources/db.properties.example` | Plantilla de configuración sin credenciales reales. |
| `sql/01-curso-original.sql` | Crea la base de datos de prácticas y sus tablas. |

## 6. PreparedStatement y cierre de recursos

La inserción utiliza marcadores `?`:

```java
String sql = "INSERT INTO productos "
        + "(producto_no, descripcion, precio_actual, stock_disponible) VALUES (?, ?, ?, ?)";

try (Connection conexion = ConexionBD.abrir();
     PreparedStatement sentencia = conexion.prepareStatement(sql)) {
    sentencia.setInt(1, producto.getNumero());
    sentencia.setString(2, producto.getDescripcion());
    sentencia.setBigDecimal(3, producto.getPrecio());
    sentencia.setInt(4, producto.getStock());
    return sentencia.executeUpdate();
}
```

- `?` representa un parámetro; se establece con métodos como `setInt()` o `setString()`.
- `executeQuery()` devuelve un `ResultSet` para consultas `SELECT`.
- `executeUpdate()` devuelve el número de filas afectadas para `INSERT`, `UPDATE` y `DELETE`.
- `try-with-resources` cierra automáticamente `Connection`, `PreparedStatement`, `ResultSet`, `InputStream` y `Scanner` cuando corresponda, incluso si se produce una excepción.
- **Excepción necesaria:** `ConexionBD.abrir()` devuelve una conexión abierta. No puede cerrarla antes de devolverla: la cierra el DAO que la utiliza, dentro de su propio `try-with-resources`.

Los archivos Java incluyen comentarios internos explicativos y documentación **Javadoc** para facilitar su estudio.

## 7. Errores frecuentes

| Mensaje o síntoma | Qué revisar |
|---|---|
| `No se encuentra db.properties` | Copiar la plantilla con el nombre exacto `db.properties` dentro de `src/main/resources`. |
| `Falta la propiedad obligatoria` | Comprobar `db.url`, `db.user` y `db.password`. |
| `Access denied` | Usuario, contraseña y permisos en MySQL. |
| `Communications link failure` | Servidor MySQL iniciado, host y puerto. |
| `Unknown database` | Ejecutar el script SQL y revisar `db.url`. |
| `Table doesn't exist` | Revisar que existe `productos` en `curso`. |
| `No suitable driver` | Comprobar la dependencia de MySQL en Maven y actualizar el proyecto. |
| `mvn` no se reconoce | Revisar la instalación de Maven y la variable `PATH` de la terminal. |

## 8. Actividades de ampliación

1. Explicar qué responsabilidad tiene cada capa y por qué el menú no contiene SQL.
2. Identificar cada recurso que se cierra automáticamente y en qué orden.
3. Probar una inserción con identificador duplicado y analizar el error SQL.
4. Comprobar qué devuelve `executeUpdate()` al modificar un producto inexistente.
5. Añadir una búsqueda de productos por identificador usando `PreparedStatement`.
