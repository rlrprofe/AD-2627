package es.dam.jdbc.modelo;
import java.math.BigDecimal;
/** Petición de transferencia; la validación se realiza en el servicio. */
public record Transferencia(int origen, int destino, BigDecimal importe) { }
