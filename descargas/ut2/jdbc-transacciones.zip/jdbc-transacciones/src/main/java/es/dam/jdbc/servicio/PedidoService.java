package es.dam.jdbc.servicio;

import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/** Ejemplo de SAVEPOINT: el pedido se confirma aunque falle el albarán opcional. */
public class PedidoService {
    public void confirmarPedidoConAlbaranOpcional(int idPedido) throws SQLException {
        try (Connection con = ConexionBD.abrir()) {
            con.setAutoCommit(false);
            try {
                String sqlPedido = "UPDATE pedidos SET estado = 'CONFIRMADO' WHERE id = ?";
                try (PreparedStatement ps = con.prepareStatement(sqlPedido)) {
                    ps.setInt(1, idPedido);
                    if (ps.executeUpdate() != 1) {
                        throw new SQLException("No existe el pedido " + idPedido);
                    }
                }
                // Hasta aquí el pedido está preparado, pero todavía no confirmado.
                Savepoint antesAlbaran = con.setSavepoint("ANTES_ALBARAN");
                try {
                    String sqlAlbaran = "INSERT INTO albaranes (id_pedido, fecha) VALUES (?, ?)";
                    try (PreparedStatement ps = con.prepareStatement(sqlAlbaran)) {
                        ps.setInt(1, idPedido);
                        ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
                        ps.executeUpdate();
                    }
                } catch (SQLException falloAlbaran) {
                    // El albarán es opcional: deshacemos solo su inserción.
                    con.rollback(antesAlbaran);
                    System.err.println("Albarán no creado: " + falloAlbaran.getMessage());
                }
                con.commit(); // Confirma el cambio de estado del pedido.
            } catch (SQLException | RuntimeException error) {
                try { con.rollback(); } catch (SQLException fallo) { error.addSuppressed(fallo); }
                throw error;
            } finally {
                try { con.setAutoCommit(true); } catch (SQLException error) {
                    System.err.println("Aviso al restaurar autocommit: " + error.getMessage());
                }
            }
        }
    }
}
