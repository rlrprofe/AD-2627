package es.dam.jdbc.servicio;
import es.dam.jdbc.config.ConexionBD;
import es.dam.jdbc.dao.CuentaDAO;
import es.dam.jdbc.modelo.Transferencia;
import java.sql.Connection;
import java.sql.SQLException;

/** Controla el límite transaccional: o se actualizan ambas cuentas o ninguna. */
public class TransferenciaService {
    private final CuentaDAO dao = new CuentaDAO();
    public void transferir(Transferencia transferencia) throws SQLException {
        if (transferencia.origen() <= 0 || transferencia.destino() <= 0
                || transferencia.origen() == transferencia.destino()
                || transferencia.importe() == null || transferencia.importe().signum() <= 0) {
            throw new IllegalArgumentException("Transferencia no válida");
        }
        try (Connection con = ConexionBD.abrir()) {
            con.setAutoCommit(false);
            try {
                if (dao.descontar(con, transferencia.origen(), transferencia.importe()) != 1) {
                    throw new SQLException("Cuenta origen inexistente o saldo insuficiente");
                }
                if (dao.ingresar(con, transferencia.destino(), transferencia.importe()) != 1) {
                    throw new SQLException("Cuenta destino inexistente");
                }
                con.commit();
            } catch (SQLException | RuntimeException error) {
                try {
                    con.rollback();
                } catch (SQLException falloRollback) {
                    error.addSuppressed(falloRollback);
                }
                throw error;
            } finally {
                // Si la conexión vuelve a un pool, no debe quedar en modo manual.
                // Con DriverManager y cierre inmediato es una precaución didáctica.
                try { con.setAutoCommit(true); } catch (SQLException error) {
                    // Si el restablecimiento falla, el cierre automático sigue liberando la conexión.
                    System.err.println("Aviso al restaurar autocommit: " + error.getMessage());
                }
            }
        }
    }
}
