package es.dam.jdbc.dao;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/** DAO transaccional: recibe la MISMA conexión del servicio. */
public class CuentaDAO {
    public int descontar(Connection con, int cuenta, BigDecimal importe) throws SQLException {
        String sql = "UPDATE cuentas SET saldo = saldo - ? WHERE id = ? AND saldo >= ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, importe);
            ps.setInt(2, cuenta);
            ps.setBigDecimal(3, importe);
            return ps.executeUpdate();
        }
    }
    public int ingresar(Connection con, int cuenta, BigDecimal importe) throws SQLException {
        String sql = "UPDATE cuentas SET saldo = saldo + ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, importe);
            ps.setInt(2, cuenta);
            return ps.executeUpdate();
        }
    }
}
