package es.dam.jdbc.app;

import es.dam.jdbc.servicio.PedidoService;
import java.sql.SQLException;

/** Requiere el pedido 1001 creado por el script de empresa. */
public class DemoSavepoint {
    public static void main(String[] args) {
        try {
            new PedidoService().confirmarPedidoConAlbaranOpcional(1001);
            System.out.println("Pedido confirmado; comprueba el albarán en MySQL.");
        } catch (SQLException e) {
            System.err.println("Error al procesar el pedido: " + e.getMessage());
        }
    }
}
