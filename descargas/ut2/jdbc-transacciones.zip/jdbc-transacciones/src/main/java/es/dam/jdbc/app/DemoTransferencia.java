package es.dam.jdbc.app;
import es.dam.jdbc.modelo.Transferencia;
import es.dam.jdbc.servicio.TransferenciaService;
import java.math.BigDecimal;
import java.sql.SQLException;
/** Ejecutar sobre datos de prueba; cambia saldos reales de la BD empresa. */
public class DemoTransferencia {
    public static void main(String[] args) {
        try {
            new TransferenciaService().transferir(new Transferencia(1,2,new BigDecimal("20.00")));
            System.out.println("Transferencia confirmada: 20.00 de la cuenta 1 a la 2");
        } catch (SQLException | IllegalArgumentException e) {
            System.err.println("Transferencia cancelada: " + e.getMessage());
        }
    }
}
