# jdbc-resultados — JDBC, ResultSet y navegación por resultados

Proyecto didáctico **Java 21 + Maven + MySQL**. Parte del proyecto original y mantiene las demostraciones de resultados, metadatos, cursores desplazables y cursores actualizables. Se ha añadido un modelo `Empleado` convencional con atributos privados, constructor, getters, setters y `toString()`. Las clases y métodos incluyen Javadoc y comentarios internos para facilitar su explicación en clase.

## Objetivos de aprendizaje

1. Distinguir `Connection`, `PreparedStatement`, `Statement` y `ResultSet`.
2. Entender que el cursor de `ResultSet` comienza **antes de la primera fila** y que `next()` avanza hasta devolver `false`.
3. Leer valores con `getInt`, `getString`, `getBigDecimal` y tratar valores SQL `NULL`.
4. Convertir cada fila del `ResultSet` en un objeto del modelo `Empleado`.
5. Consultar `ResultSetMetaData` (etiqueta, nombre, tipo y nulabilidad) y `DatabaseMetaData` (capacidades del driver).
6. Probar cursores `TYPE_SCROLL_INSENSITIVE` con `first`, `last`, `absolute`, `previous` y `getRow`.
7. Reconocer las limitaciones de `CONCUR_UPDATABLE` y usar `updateRow()` solo en la demostración opcional.
8. Cerrar recursos JDBC con **try-with-resources**.

## Requisitos

- **JDK 21**, Maven y VS Code u otro IDE con soporte Maven.
- MySQL y una cuenta de prácticas con acceso a la base `curso`.
- Maven descarga `com.mysql:mysql-connector-j` desde `pom.xml`.

## Preparación de MySQL

El archivo `sql/01-curso-original.sql` prepara la base `curso` y sus tablas, entre ellas `empleados` y `productos`.

> **ATENCIÓN:** el script incluye `DROP DATABASE IF EXISTS CURSO`; elimina los datos existentes de esa base. Úsalo únicamente en un entorno de prácticas.

Crea o utiliza una cuenta de MySQL con los permisos mínimos. Las demostraciones de consulta requieren `SELECT`; la demostración **opcional** de cursor actualizable también necesita `UPDATE` sobre `productos`.

## Configuración mediante db.properties (sin System.getenv)

1. Copia `src/main/resources/db.properties.example`.
2. Renombra la copia como `src/main/resources/db.properties`.
3. Configura los valores para tu instalación local:

```properties
jdbc.url=jdbc:mysql://localhost:3306/curso
jdbc.user=alumno
jdbc.password=TU_CLAVE_LOCAL
```

`ConexionBD.abrir()` lee el archivo mediante `Properties` y `getResourceAsStream()`; no utiliza `System.getenv()`. Si falta el archivo o alguna propiedad, lanza `SQLException` con un mensaje orientativo.

**Seguridad:** `db.properties` figura en `.gitignore`. No compartas el archivo real ni distribuyas un JAR que lo incluya; Maven puede copiar los recursos a `target/classes`.

## Compilación y ejecución

Desde la carpeta que contiene `pom.xml`:

```powershell
mvn clean compile
```

En VS Code, abre el proyecto Maven y ejecuta el `main()` de cada clase mediante **Run Java**:

| Clase principal | Qué demuestra | ¿Modifica datos? |
|---|---|---|
| `es.dam.jdbc.app.DemoResultados` | `next()`, mapeo a `Empleado`, `ResultSetMetaData`, `DatabaseMetaData` | No |
| `es.dam.jdbc.app.DemoCursorDesplazable` | `first()`, `last()`, `absolute(2)`, `previous()`, `getRow()` | No |
| `es.dam.jdbc.app.DemoResultSetActualizable` | `CONCUR_UPDATABLE`, `updateInt()`, `updateRow()` | **Sí**, aumenta el stock del producto 9001 si existe |

**Clase principal recomendada para empezar:** `DemoResultados`.

## Organización del proyecto

```text
jdbc-resultados/
├── pom.xml
├── README.md
├── .gitignore
├── sql/01-curso-original.sql
└── src/main/
    ├── java/es/dam/jdbc/
    │   ├── config/ConexionBD.java
    │   ├── modelo/Empleado.java
    │   ├── dao/ConsultaDAO.java
    │   └── app/
    │       ├── DemoResultados.java
    │       ├── DemoCursorDesplazable.java
    │       └── DemoResultSetActualizable.java
    └── resources/db.properties.example
```

### Responsabilidades

- **`ConexionBD`**: lee propiedades y abre conexiones; no contiene contraseñas.
- **`Empleado`**: modelo de datos con campos privados, constructor, getters, setters y `toString()`; no conoce JDBC.
- **`ConsultaDAO`**: ejecuta consultas, recorre `ResultSet` y transforma cada fila en un `Empleado`; obtiene metadatos.
- **`DemoResultados`**: muestra los objetos y los metadatos, y gestiona los errores.
- **`DemoCursorDesplazable`**: ilustra cómo mover el cursor cuando el driver lo permite.
- **`DemoResultSetActualizable`**: ejemplo independiente y opcional de modificación de una fila.

## Conceptos importantes

- `ResultSet.next()` mueve el cursor; devuelve `false` al finalizar. No se debe leer una columna antes de situarse en una fila válida.
- Los índices de parámetros y columnas comienzan en **1**.
- `getColumnLabel()` puede devolver el alias SQL (`AS`); `getColumnName()` depende del driver.
- `getBigDecimal("comision")` devuelve `null` si la columna contiene SQL `NULL`; con `getInt()` habría que consultar `wasNull()` para distinguir un cero de un valor nulo.
- La compatibilidad con cursores desplazables y actualizables depende del driver, de la consulta y de la tabla.
- `try-with-resources` cierra `ResultSet`, sentencia y conexión incluso ante excepciones. `ResultSetMetaData` y `DatabaseMetaData` no son recursos que se cierren por separado.
- Para modificar datos normalmente es preferible `UPDATE ... WHERE ...` con `PreparedStatement`.

## Errores frecuentes

| Error | Qué revisar |
|---|---|
| `No se encuentra db.properties` | Copiar la plantilla a `src/main/resources/db.properties` y recompilar |
| `Falta la propiedad jdbc.password` | Completar `db.properties` |
| `Access denied` | Usuario, contraseña y permisos |
| `Communications link failure` | Servidor, host y puerto MySQL |
| `Unknown database` | Ejecutar el script de `curso` en una base de prácticas |
| `Table doesn't exist` | Revisar que existen `empleados` y `productos` |
| `ClassNotFoundException` al ejecutar desde VS Code | Ejecutar `mvn clean compile` y actualizar el espacio de trabajo Java |
| Cursor no desplazable/actualizable | Revisar capacidades del driver y restricciones de la consulta |

## Actividades propuestas

1. Cambia el departamento consultado (por ejemplo, 10, 20 o 30) y comprueba si se obtiene una lista vacía.
2. Explica línea a línea por qué se utiliza `while (rs.next())`.
3. Añade una columna a la consulta y actualiza el modelo `Empleado` y el mapeo del DAO.
4. Compara `getColumnLabel()` y `getColumnName()` para la columna `emp_no AS identificador`.
5. Investiga qué devuelve `getBigDecimal("comision")` cuando SQL almacena `NULL`.
6. Prueba `first()`, `last()`, `absolute(2)` y `previous()`; indica la posición del cursor.
7. **Solo en una base de pruebas:** inserta el producto 9001 y ejecuta la demostración de `updateRow()`; comprueba el stock antes y después.
8. Explica qué recursos cierra cada bloque `try-with-resources` y por qué no se cierra `DatabaseMetaData`.
