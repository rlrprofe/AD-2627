package es.dam.jdbc.app;

import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Ejemplo OPCIONAL de cursor actualizable: incrementa el stock del producto 9001.
 * Modifica datos reales de la base de prácticas y requiere soporte del driver.
 * Para aplicaciones habituales se recomienda UPDATE con PreparedStatement.
 */
public final class DemoResultSetActualizable {
    /** Impide crear instancias de la clase de demostración. */
    private DemoResultSetActualizable() { }

    /**
     * Localiza un producto y actualiza su fila mediante updateRow().
     *
     * @param args argumentos no utilizados
     */
    public static void main(String[] args) {
        // Incluimos la clave primaria para facilitar un ResultSet actualizable.
        String sql = "SELECT producto_no, descripcion, stock_disponible "
                + "FROM productos WHERE producto_no = 9001";
        try (Connection con = ConexionBD.abrir();
             Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                     ResultSet.CONCUR_UPDATABLE);
             ResultSet rs = st.executeQuery(sql)) {
            // getConcurrency() indica la concurrencia real del resultado.
            if (rs.getConcurrency() != ResultSet.CONCUR_UPDATABLE) {
                System.out.println("El driver no ofrece un cursor actualizable para esta consulta.");
                return;
            }
            if (rs.next()) {
                int nuevoStock = rs.getInt("stock_disponible") + 1;
                // updateInt prepara el cambio en la fila del cursor.
                rs.updateInt("stock_disponible", nuevoStock);
                // updateRow envía el cambio a la base de datos.
                rs.updateRow();
                System.out.println("Nuevo stock del producto 9001: " + nuevoStock);
            } else {
                System.out.println("No existe el producto 9001. No se ha modificado ningún registro.");
            }
        } catch (SQLException e) {
            System.err.printf("Cursor no disponible o error SQL: %s [SQLState=%s]%n",
                    e.getMessage(), e.getSQLState());
        }
    }
}
