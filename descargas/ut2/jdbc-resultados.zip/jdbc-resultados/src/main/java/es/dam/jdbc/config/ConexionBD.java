package es.dam.jdbc.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Centraliza la conexión a MySQL mediante un archivo de propiedades.
 * La configuración se carga desde el classpath (src/main/resources).
 * Nunca se incluyen contraseñas reales en el código fuente.
 */
public final class ConexionBD {
    private static final String ARCHIVO = "db.properties";

    /** Impide crear objetos de esta clase de utilidades. */
    private ConexionBD() { }

    /**
     * Abre una conexión nueva con los datos del archivo db.properties.
     * El método llamador debe cerrar la conexión con try-with-resources.
     *
     * @return conexión JDBC abierta
     * @throws SQLException si falta la configuración o falla la conexión
     */
    public static Connection abrir() throws SQLException {
        Properties propiedades = new Properties();

        // getResourceAsStream busca el fichero en el classpath de Maven.
        // InputStream se cierra incluso si la lectura provoca una excepción.
        try (InputStream entrada = ConexionBD.class.getClassLoader().getResourceAsStream(ARCHIVO)) {
            if (entrada == null) {
                throw new SQLException("No se encuentra db.properties en src/main/resources. "
                        + "Copia db.properties.example y configura tu conexión.");
            }
            propiedades.load(entrada);
        } catch (IOException e) {
            throw new SQLException("No se pudo leer db.properties", e);
        }

        String url = obligatorio(propiedades, "jdbc.url");
        String usuario = obligatorio(propiedades, "jdbc.user");
        String clave = obligatorio(propiedades, "jdbc.password");
        return DriverManager.getConnection(url, usuario, clave);
    }

    /**
     * Comprueba que una propiedad necesaria tenga contenido.
     *
     * @param propiedades configuración cargada
     * @param clave nombre de la propiedad
     * @return valor configurado
     * @throws SQLException si la propiedad no existe o está vacía
     */
    private static String obligatorio(Properties propiedades, String clave) throws SQLException {
        String valor = propiedades.getProperty(clave);
        if (valor == null || valor.isBlank()) {
            throw new SQLException("Falta la propiedad " + clave + " en db.properties");
        }
        return valor.trim();
    }
}
