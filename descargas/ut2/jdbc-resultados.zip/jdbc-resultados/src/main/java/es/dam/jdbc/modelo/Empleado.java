package es.dam.jdbc.modelo;

import java.math.BigDecimal;

/**
 * Modelo de un empleado recuperado de la tabla EMPLEADOS.
 * No conoce JDBC ni ejecuta SQL: solo almacena los datos de una fila.
 */
public class Empleado {
    private int numero;
    private String apellido;
    private BigDecimal salario;
    private BigDecimal comision;

    /**
     * Crea un empleado con los valores recuperados de la base de datos.
     *
     * @param numero identificador del empleado
     * @param apellido apellido del empleado
     * @param salario salario del empleado
     * @param comision comisión; puede ser null si en SQL es NULL
     */
    public Empleado(int numero, String apellido, BigDecimal salario, BigDecimal comision) {
        this.numero = numero;
        this.apellido = apellido;
        this.salario = salario;
        this.comision = comision;
    }

    /** @return identificador del empleado */
    public int getNumero() { return numero; }
    /** @param numero nuevo identificador */
    public void setNumero(int numero) { this.numero = numero; }
    /** @return apellido del empleado */
    public String getApellido() { return apellido; }
    /** @param apellido nuevo apellido */
    public void setApellido(String apellido) { this.apellido = apellido; }
    /** @return salario del empleado */
    public BigDecimal getSalario() { return salario; }
    /** @param salario nuevo salario */
    public void setSalario(BigDecimal salario) { this.salario = salario; }
    /** @return comisión, o null si no existe */
    public BigDecimal getComision() { return comision; }
    /** @param comision nueva comisión, admite null */
    public void setComision(BigDecimal comision) { this.comision = comision; }

    /** @return representación legible de los datos del empleado */
    @Override
    public String toString() {
        return "Empleado{numero=" + numero + ", apellido='" + apellido + "', salario=" + salario
                + ", comision=" + (comision == null ? "sin comisión" : comision) + "}";
    }
}
