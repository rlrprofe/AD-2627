package es.dam.jdbc.dao;

import es.dam.jdbc.config.ConexionBD;
import es.dam.jdbc.modelo.Empleado;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de consultas: ejecuta SQL y transforma filas de ResultSet en objetos.
 * No pide datos por teclado ni contiene lógica de presentación.
 */
public class ConsultaDAO {

    /**
     * Consulta los empleados de un departamento usando un parámetro SQL.
     *
     * @param departamento identificador del departamento
     * @return lista de empleados; vacía si no hay coincidencias
     * @throws SQLException si falla la consulta
     */
    public List<Empleado> buscarPorDepartamento(int departamento) throws SQLException {
        String sql = "SELECT emp_no, apellido, salario, comision "
                + "FROM empleados WHERE dep_no = ? ORDER BY emp_no";
        List<Empleado> empleados = new ArrayList<>();

        // Se cierran la conexión y la sentencia automáticamente.
        try (Connection con = ConexionBD.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            // Los parámetros ? empiezan a numerarse desde 1.
            ps.setInt(1, departamento);
            // ResultSet también debe cerrarse, por eso tiene su propio try.
            try (ResultSet rs = ps.executeQuery()) {
                // El cursor empieza ANTES de la primera fila.
                while (rs.next()) {
                    // Se lee la fila actual y se convierte en un objeto del modelo.
                    empleados.add(new Empleado(
                            rs.getInt("emp_no"),
                            rs.getString("apellido"),
                            rs.getBigDecimal("salario"),
                            rs.getBigDecimal("comision"))); // SQL NULL -> null
                }
            }
        }
        return empleados;
    }

    /**
     * Muestra los metadatos de las columnas de una consulta.
     *
     * @throws SQLException si falla el acceso a la base de datos
     */
    public void mostrarMetadatos() throws SQLException {
        String sql = "SELECT emp_no AS identificador, apellido, salario FROM empleados";
        try (Connection con = ConexionBD.abrir();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            // Los metadatos describen columnas, incluso si no se devuelve ninguna fila.
            ResultSetMetaData meta = rs.getMetaData();
            System.out.println("Columnas: " + meta.getColumnCount());
            for (int columna = 1; columna <= meta.getColumnCount(); columna++) {
                // label refleja el alias AS; name depende del comportamiento del driver.
                System.out.printf("%d: etiqueta=%s, nombre=%s, tipo=%s, admite NULL=%s%n",
                        columna, meta.getColumnLabel(columna), meta.getColumnName(columna),
                        meta.getColumnTypeName(columna),
                        meta.isNullable(columna) == ResultSetMetaData.columnNoNulls ? "no" : "sí/desconocido");
            }
        }
    }

    /**
     * Consulta qué tipos de cursores admite el driver JDBC.
     *
     * @throws SQLException si falla la consulta de capacidades
     */
    public void mostrarCapacidadesCursor() throws SQLException {
        try (Connection con = ConexionBD.abrir()) {
            // DatabaseMetaData no se cierra por separado: depende de la conexión.
            DatabaseMetaData md = con.getMetaData();
            System.out.println("Driver: " + md.getDriverName() + " " + md.getDriverVersion());
            System.out.println("FORWARD_ONLY: " + md.supportsResultSetType(ResultSet.TYPE_FORWARD_ONLY));
            System.out.println("SCROLL_INSENSITIVE: " + md.supportsResultSetType(ResultSet.TYPE_SCROLL_INSENSITIVE));
            System.out.println("SCROLL_SENSITIVE: " + md.supportsResultSetType(ResultSet.TYPE_SCROLL_SENSITIVE));
            System.out.println("Cursor actualizable: " + md.supportsResultSetConcurrency(
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE));
        }
    }
}
