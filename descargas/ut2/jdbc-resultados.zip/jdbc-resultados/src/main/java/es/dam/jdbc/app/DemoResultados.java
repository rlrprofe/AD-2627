package es.dam.jdbc.app;

import es.dam.jdbc.dao.ConsultaDAO;
import es.dam.jdbc.modelo.Empleado;
import java.sql.SQLException;
import java.util.List;

/**
 * Ejemplo principal: recorre un ResultSet, convierte filas en objetos Empleado
 * y muestra información sobre las columnas y el driver JDBC.
 */
public final class DemoResultados {
    /** Impide instanciar la clase que contiene el punto de entrada. */
    private DemoResultados() { }

    /**
     * Ejecuta las demostraciones de consultas y metadatos.
     *
     * @param args argumentos de línea de comandos (no se utilizan)
     */
    public static void main(String[] args) {
        ConsultaDAO dao = new ConsultaDAO();
        try {
            System.out.println("=== Empleados del departamento 30 ===");
            List<Empleado> empleados = dao.buscarPorDepartamento(30);
            if (empleados.isEmpty()) {
                System.out.println("No se encontraron empleados.");
            } else {
                // La capa de presentación muestra los objetos que devuelve el DAO.
                for (Empleado empleado : empleados) {
                    System.out.println(empleado);
                }
            }
            System.out.println("\n=== Metadatos de columnas ===");
            dao.mostrarMetadatos();
            System.out.println("\n=== Capacidades del driver ===");
            dao.mostrarCapacidadesCursor();
        } catch (SQLException e) {
            // SQLState y el código ayudan a diagnosticar el error sin mostrar claves.
            System.err.printf("Error SQL: %s [SQLState=%s, código=%d]%n",
                    e.getMessage(), e.getSQLState(), e.getErrorCode());
        }
    }
}
