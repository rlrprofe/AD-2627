package es.dam.jdbc.app;

import es.dam.jdbc.config.ConexionBD;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Demuestra los movimientos de un cursor desplazable de solo lectura.
 * Su disponibilidad depende del driver JDBC.
 */
public final class DemoCursorDesplazable {
    /** Impide crear instancias de la clase de demostración. */
    private DemoCursorDesplazable() { }

    /**
     * Recorre el resultado con first(), last(), absolute() y previous().
     *
     * @param args argumentos no utilizados
     */
    public static void main(String[] args) {
        String sql = "SELECT emp_no, apellido FROM empleados ORDER BY emp_no";
        try (Connection con = ConexionBD.abrir();
             Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                     ResultSet.CONCUR_READ_ONLY);
             ResultSet rs = st.executeQuery(sql)) {
            // Comprueba el tipo efectivo: el driver puede ofrecer otro distinto.
            System.out.println("Tipo de cursor: " + rs.getType());
            if (rs.first()) {
                System.out.println("Primero (fila " + rs.getRow() + "): " + rs.getString("apellido"));
            } else {
                System.out.println("La consulta no devuelve filas.");
                return;
            }
            if (rs.last()) {
                System.out.println("Último (fila " + rs.getRow() + "): " + rs.getString("apellido"));
            }
            // absolute(2) sitúa el cursor en la segunda fila, si existe.
            if (rs.absolute(2)) {
                System.out.println("Segundo: " + rs.getString("apellido"));
                // previous() vuelve a la fila anterior.
                if (rs.previous()) {
                    System.out.println("Anterior al segundo: " + rs.getString("apellido"));
                }
            }
        } catch (SQLException e) {
            System.err.printf("Error SQL/cursor: %s [SQLState=%s]%n", e.getMessage(), e.getSQLState());
        }
    }
}
