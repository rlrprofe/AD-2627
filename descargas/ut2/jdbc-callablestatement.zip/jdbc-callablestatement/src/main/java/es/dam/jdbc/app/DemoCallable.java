package es.dam.jdbc.app;

import es.dam.jdbc.dao.ProcedimientoDAO;
import java.sql.SQLException;

/**
 * Demostración inicial de CallableStatement sin modificar datos.
 * Ejecuta un procedimiento OUT y otro INOUT; el ejemplo IN se deja como ampliación.
 */
public final class DemoCallable {
    private DemoCallable() { }

    /**
     * Punto de entrada de la aplicación.
     * @param args no se utilizan argumentos de consola
     */
    public static void main(String[] args) {
        ProcedimientoDAO dao = new ProcedimientoDAO();
        try {
            // OUT: el procedimiento calcula el total y Java recupera la salida.
            System.out.println("Total empleados: " + dao.contarEmpleados());
            // INOUT: enviamos 12 y recibimos 24 desde MySQL.
            System.out.println("El doble de 12 es: " + dao.doblarNumero(12));

            // IN: modifica salarios y añade una fila al log. Solo ejecutar
            // manualmente en la base de pruebas, tras verificar los datos:
            // dao.aumentarSalario(30, new BigDecimal("5.00"));
        } catch (SQLException e) {
            // SQLState y código del proveedor ayudan a localizar el fallo.
            System.err.printf("Error SQL: %s [SQLState=%s, código=%d]%n",
                    e.getMessage(), e.getSQLState(), e.getErrorCode());
        }
    }
}
