package es.dam.jdbc.app;
import es.dam.jdbc.dao.ProcedimientoDAO;
import java.sql.SQLException;
/** Ejemplos de parámetros OUT e INOUT sin modificar salarios. */
public class DemoCallable {
    public static void main(String[] args) {
        ProcedimientoDAO dao = new ProcedimientoDAO();
        try {
            System.out.println("Total empleados: " + dao.contarEmpleados());
            System.out.println("El doble de 12 es: " + dao.doblarNumero(12));
            // dao.aumentarSalario(...) modifica datos: usar solo en ejercicios controlados.
        } catch (SQLException e) {
            System.err.printf("Error SQL: %s [SQLState=%s, código=%d]%n", e.getMessage(),e.getSQLState(),e.getErrorCode());
        }
    }
}
