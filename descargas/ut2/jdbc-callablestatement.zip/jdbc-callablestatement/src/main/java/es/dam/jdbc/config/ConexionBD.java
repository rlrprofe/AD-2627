package es.dam.jdbc.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Centraliza la apertura de conexiones JDBC. No guarda contraseñas en el código. */
public final class ConexionBD {
    private ConexionBD() { }

    public static Connection abrir() throws SQLException {
        String url = System.getenv().getOrDefault("JDBC_URL", "jdbc:mysql://localhost:3306/curso");
        String usuario = System.getenv().getOrDefault("JDBC_USER", "alumno");
        String clave = System.getenv("JDBC_PASSWORD");
        if (clave == null || clave.isBlank()) {
            throw new SQLException("Falta JDBC_PASSWORD. Configura la variable de entorno antes de ejecutar.");
        }
        return DriverManager.getConnection(url, usuario, clave);
    }
}
