package es.dam.jdbc.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Centraliza la apertura de conexiones a MySQL a partir de db.properties.
 * La clase no almacena credenciales en constantes ni lee variables de entorno.
 */
public final class ConexionBD {
    /** Clase de utilidades: no se permite crear instancias. */
    private ConexionBD() { }

    /**
     * Lee los parámetros JDBC desde el classpath y abre una conexión nueva.
     * Cada llamada devuelve una conexión que el código cliente debe cerrar.
     *
     * @return conexión abierta a la base de datos configurada
     * @throws SQLException si falta el fichero, algún dato o falla la conexión
     */
    public static Connection abrir() throws SQLException {
        Properties propiedades = new Properties();
        // Maven copia src/main/resources al classpath durante la compilación.
        try (InputStream entrada = ConexionBD.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (entrada == null) {
                throw new SQLException("No se encuentra db.properties. Copia db.properties.example a db.properties en src/main/resources.");
            }
            // load interpreta las líneas del archivo como pares clave=valor.
            propiedades.load(entrada);
        } catch (IOException e) {
            throw new SQLException("No se ha podido leer db.properties", e);
        }

        String url = obligatorio(propiedades, "jdbc.url");
        String usuario = obligatorio(propiedades, "jdbc.user");
        String clave = obligatorio(propiedades, "jdbc.password");
        // DriverManager obtiene el driver MySQL incluido por Maven.
        return DriverManager.getConnection(url, usuario, clave);
    }

    /** Comprueba que una propiedad obligatoria está presente y no está vacía. */
    private static String obligatorio(Properties propiedades, String clave) throws SQLException {
        String valor = propiedades.getProperty(clave);
        if (valor == null || valor.isBlank()) {
            throw new SQLException("Falta la propiedad obligatoria: " + clave);
        }
        return valor.trim();
    }
}
