package es.dam.jdbc.dao;

import es.dam.jdbc.config.ConexionBD;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Accede a procedimientos almacenados de la base de datos curso.
 * Ilustra los tres modos de parámetro: IN, OUT e INOUT.
 * No lee datos del teclado ni imprime mensajes: esas tareas corresponden a la app.
 */
public class ProcedimientoDAO {
    /**
     * Ejecuta contarEmpleados, que devuelve el total en un parámetro OUT.
     * @return número de empleados de la tabla
     * @throws SQLException si falla la llamada al procedimiento
     */
    public int contarEmpleados() throws SQLException {
        // La notación JDBC {call ...} invoca un procedimiento almacenado.
        try (Connection con = ConexionBD.abrir();
             CallableStatement cs = con.prepareCall("{call contarEmpleados(?)}")) {
            // El primer '?' es OUT: MySQL escribirá aquí el resultado.
            cs.registerOutParameter(1, Types.INTEGER);
            cs.execute();
            // Después de ejecutar, recuperamos el valor de salida.
            return cs.getInt(1);
        } // try-with-resources cierra primero cs y luego con.
    }

    /**
     * Ejecuta doblarNumero con un parámetro INOUT.
     * @param numero valor de entrada que el procedimiento multiplicará por dos
     * @return valor actualizado por el procedimiento
     * @throws SQLException si falla la llamada
     */
    public int doblarNumero(int numero) throws SQLException {
        try (Connection con = ConexionBD.abrir();
             CallableStatement cs = con.prepareCall("{call doblarNumero(?)}")) {
            cs.setInt(1, numero); // IN: entregamos el número al procedimiento.
            cs.registerOutParameter(1, Types.INTEGER); // OUT: el mismo parámetro devuelve otro valor.
            cs.execute();
            return cs.getInt(1);
        }
    }

    /**
     * Ejecuta aumentarSalario con dos parámetros IN; MODIFICA DATOS.
     * El procedimiento actualiza salarios y escribe una fila en log_acciones.
     * @param departamento identificador del departamento afectado
     * @param porcentaje porcentaje de aumento, p. ej. 5.00 para un cinco por ciento
     * @throws SQLException si falla la ejecución
     */
    public void aumentarSalario(int departamento, BigDecimal porcentaje) throws SQLException {
        if (departamento <= 0) {
            throw new IllegalArgumentException("El departamento debe ser positivo");
        }
        if (porcentaje == null || porcentaje.signum() <= 0) {
            throw new IllegalArgumentException("El porcentaje debe ser positivo");
        }
        try (Connection con = ConexionBD.abrir();
             CallableStatement cs = con.prepareCall("{call aumentarSalario(?, ?)}")) {
            // Ambos '?' son IN; el procedimiento no tiene parámetro de salida.
            cs.setInt(1, departamento);
            cs.setBigDecimal(2, porcentaje);
            cs.execute();
            // No devolvemos filas afectadas: el procedimiento no expone ese dato.
        }
    }
}
