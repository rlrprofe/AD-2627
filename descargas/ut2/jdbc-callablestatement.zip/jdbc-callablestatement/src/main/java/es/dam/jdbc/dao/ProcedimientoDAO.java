package es.dam.jdbc.dao;
import es.dam.jdbc.config.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
/** Ejecuta procedimientos almacenados; distingue IN, OUT e INOUT. */
public class ProcedimientoDAO {
    public int contarEmpleados() throws SQLException {
        try (Connection con = ConexionBD.abrir();
             CallableStatement cs = con.prepareCall("{call contarEmpleados(?)}")) {
            cs.registerOutParameter(1, Types.INTEGER); // Parámetro de salida.
            cs.execute();
            return cs.getInt(1);
        }
    }
    public int doblarNumero(int numero) throws SQLException {
        try (Connection con = ConexionBD.abrir();
             CallableStatement cs = con.prepareCall("{call doblarNumero(?)}")) {
            cs.setInt(1, numero);                  // Valor de entrada.
            cs.registerOutParameter(1, Types.INTEGER); // También es salida (INOUT).
            cs.execute();
            return cs.getInt(1);
        }
    }
    public int aumentarSalario(int departamento, java.math.BigDecimal porcentaje) throws SQLException {
        try (Connection con = ConexionBD.abrir();
             CallableStatement cs = con.prepareCall("{call aumentarSalario(?, ?)}")) {
            cs.setInt(1, departamento);
            cs.setBigDecimal(2, porcentaje);
            cs.execute();
            return 0; // El procedimiento original no devuelve el número de filas afectadas.
        }
    }
}
