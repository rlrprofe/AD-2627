# JDBC · CallableStatement y procedimientos almacenados (UT2)

## Finalidad didáctica

Este proyecto muestra cómo **Java invoca procedimientos almacenados de MySQL** mediante `CallableStatement`. El alumnado aprenderá a distinguir los parámetros **OUT**, **INOUT** e **IN**, a asignar entradas (`setInt`, `setBigDecimal`), registrar salidas (`registerOutParameter`), ejecutar (`execute`) y recuperar resultados (`getInt`). También practicará el cierre automático de recursos con `try-with-resources` y la interpretación de errores SQL.

La clase principal `es.dam.jdbc.app.DemoCallable` ejecuta **dos demostraciones de solo lectura**: `contarEmpleados` (OUT) y `doblarNumero` (INOUT). La operación `aumentarSalario` (IN) está implementada en el DAO, pero **no se ejecuta automáticamente**, ya que modifica salarios y registra la acción.

## Requisitos

- JDK **21**, Maven y VS Code (o IDE compatible).
- MySQL 8 y usuario de prácticas con permisos adecuados sobre `curso`.
- Dependencia `com.mysql:mysql-connector-j` gestionada en `pom.xml`.

## 1. Preparación de MySQL

Ejecuta en este orden los scripts de `sql/`:

1. `01-curso-original.sql`: crea la base de datos y sus tablas.
2. `02-procedimientos-curso.sql`: crea los procedimientos `contarEmpleados`, `doblarNumero` y `aumentarSalario`, además de funciones de ampliación.

**Aviso:** el primer script contiene `DROP DATABASE IF EXISTS CURSO`; elimina la base de datos existente. Utilízalo únicamente en un entorno de prácticas. El segundo script recrea la tabla `log_acciones`.

## 2. Configuración mediante db.properties

Copia `src/main/resources/db.properties.example` como `src/main/resources/db.properties` y edita los valores:

```properties
jdbc.url=jdbc:mysql://localhost:3306/curso
jdbc.user=alumno
jdbc.password=TU_CLAVE_LOCAL
```

`ConexionBD` carga este fichero con `Properties` y `getResourceAsStream`. **No utiliza `System.getenv()`**. El archivo privado está excluido en `.gitignore`, pero recuerda que Maven puede copiarlo a `target/classes`: **no compartas compilados o JAR con contraseñas**.

## 3. Compilación y ejecución

Desde la carpeta del proyecto:

```powershell
mvn clean compile
```

Abre `src/main/java/es/dam/jdbc/app/DemoCallable.java` en VS Code y pulsa **Run Java** sobre `main`. Comprueba que el programa muestra el total de empleados y el doble de 12 (24).

## 4. Organización y responsabilidades

| Archivo | Función |
|---|---|
| `config/ConexionBD.java` | Lee `db.properties`, valida sus claves y abre conexiones JDBC |
| `dao/ProcedimientoDAO.java` | Prepara y ejecuta llamadas SQL a procedimientos almacenados |
| `app/DemoCallable.java` | Ejecuta ejemplos y muestra resultados o errores |
| `sql/02-procedimientos-curso.sql` | Define los procedimientos y funciones MySQL |

**No existe clase de modelo en este ejemplo**, porque los procedimientos devuelven valores escalares (`int`) y no entidades completas. Añadir getters y setters artificiales no aportaría nada al objetivo didáctico. Las clases Java incluyen Javadoc y comentarios internos para facilitar su lectura.

## 5. Qué hace cada procedimiento

| Procedimiento | Tipo | Llamada Java | Resultado |
|---|---|---|---|
| `contarEmpleados(OUT total)` | OUT | `registerOutParameter(1, Types.INTEGER)` | Número total de empleados |
| `doblarNumero(INOUT valor)` | INOUT | `setInt(1, 12)` y `registerOutParameter(1, Types.INTEGER)` | Devuelve 24 |
| `aumentarSalario(IN dep, IN porcentaje)` | IN | `setInt` y `setBigDecimal` | Actualiza salarios y escribe en `log_acciones` |

`aumentarSalario` **no devuelve un número de filas afectadas** en su definición SQL; por eso el método Java devuelve `void`. Si necesitas saber cuántos empleados se han modificado, deberás modificar el procedimiento para exponer esa información mediante un parámetro OUT u otro resultado explícito.

## 6. Ejercicios de comprobación

1. Explica por qué `registerOutParameter()` se ejecuta **antes** de `execute()`.
2. Cambia el número enviado a `doblarNumero` y comprueba el resultado.
3. Localiza en el script SQL los parámetros `IN`, `OUT` e `INOUT`.
4. Describe qué conexiones y sentencias cierra cada `try-with-resources`.
5. **Solo en una base de pruebas**, ejecuta `aumentarSalario` desde un ejercicio separado y comprueba los salarios y la tabla `log_acciones` antes y después.

## 7. Errores frecuentes

| Error | Qué revisar |
|---|---|
| `No se encuentra db.properties` | Copiar la plantilla al archivo real en `src/main/resources` y recompilar |
| `Access denied` | Usuario, contraseña y permisos `EXECUTE` |
| `Unknown database 'curso'` | Ejecutar el script inicial |
| `PROCEDURE ... does not exist` | Ejecutar el script de procedimientos en la BD correcta |
| `Communications link failure` | MySQL iniciado, host y puerto |
| `ClassNotFoundException` | Ejecutar `mvn clean compile` y recargar el proyecto Java en VS Code |

**Importante:** no publiques contraseñas, no uses una base con datos reales y no ejecutes repetidamente el aumento salarial sin restablecer los datos.
