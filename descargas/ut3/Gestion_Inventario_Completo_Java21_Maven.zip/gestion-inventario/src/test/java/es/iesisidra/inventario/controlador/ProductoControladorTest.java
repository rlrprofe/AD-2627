package es.iesisidra.inventario.controlador;

import es.iesisidra.inventario.dao.ProductoFicheroDAO;
import es.iesisidra.inventario.servicio.ProductoService;
import es.iesisidra.inventario.vista.ConsolaVista;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;

class ProductoControladorTest {
    @TempDir Path carpeta;
    @Test void permiteAltaBusquedaListadoYSalida() {
        String entradas = "1\n7\nMonitor\n129.95\n3\n2\n7\n3\n0\n";
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ConsolaVista vista = new ConsolaVista(new Scanner(entradas), new PrintStream(bytes, true, StandardCharsets.UTF_8));
        ProductoService servicio = new ProductoService(new ProductoFicheroDAO(carpeta.resolve("productos.csv")));
        new ProductoControlador(servicio, vista).iniciar();
        String salida = bytes.toString(StandardCharsets.UTF_8);
        assertTrue(salida.contains("Producto registrado"));
        assertTrue(salida.contains("Monitor"));
        assertEquals(1, servicio.listar().size());
    }
    @Test void entradaInvalidaNoTerminaAplicacion() {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ConsolaVista vista = new ConsolaVista(new Scanner("abc\n0\n"), new PrintStream(bytes, true, StandardCharsets.UTF_8));
        new ProductoControlador(new ProductoService(new ProductoFicheroDAO(carpeta.resolve("x.csv"))), vista).iniciar();
        assertTrue(bytes.toString(StandardCharsets.UTF_8).contains("entero válido"));
    }
}
