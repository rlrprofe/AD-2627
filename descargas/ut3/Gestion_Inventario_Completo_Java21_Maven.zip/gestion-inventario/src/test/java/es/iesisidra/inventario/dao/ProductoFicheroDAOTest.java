package es.iesisidra.inventario.dao;

import es.iesisidra.inventario.modelo.Producto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class ProductoFicheroDAOTest {
    @TempDir Path carpeta;
    @Test void crudPersistente() {
        Path archivo = carpeta.resolve("productos.csv");
        ProductoDAO dao = new ProductoFicheroDAO(archivo);
        Producto p = new Producto(1, "Teclado", 19.95, 4);
        dao.insertar(p);
        assertEquals(p, new ProductoFicheroDAO(archivo).buscarPorId(1).orElseThrow());
        assertTrue(dao.actualizar(new Producto(1, "Teclado mecánico", 50, 2)));
        assertEquals(50, dao.buscarPorId(1).orElseThrow().precio());
        assertTrue(dao.eliminar(1));
        assertTrue(dao.listar().isEmpty());
    }
    @Test void noCorrompeArchivoAnteNombreIncompatible() {
        ProductoDAO dao = new ProductoFicheroDAO(carpeta.resolve("productos.csv"));
        dao.insertar(new Producto(1, "Correcto", 2, 3));
        assertThrows(IllegalArgumentException.class, () -> dao.insertar(new Producto(2, "A;B", 2, 3)));
        assertEquals(1, dao.listar().size());
    }
}
