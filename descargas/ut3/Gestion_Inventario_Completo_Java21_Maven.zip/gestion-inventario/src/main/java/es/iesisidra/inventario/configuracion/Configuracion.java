package es.iesisidra.inventario.configuracion;

import es.iesisidra.inventario.dao.*;
import java.nio.file.Path;
import java.util.Locale;

/** Selecciona el mecanismo de persistencia sin acoplar el controlador a su implementación. */
public final class Configuracion {
    private Configuracion() { }
    public static ProductoDAO crearDao() {
        String modo = System.getenv().getOrDefault("INVENTARIO_STORAGE", "csv").trim().toLowerCase(Locale.ROOT);
        return switch (modo) {
            case "csv" -> new ProductoFicheroDAO(Path.of("datos", "productos.csv"));
            case "mysql" -> new ProductoJdbcDAO();
            default -> throw new IllegalArgumentException("INVENTARIO_STORAGE debe ser csv o mysql: " + modo);
        };
    }
}
