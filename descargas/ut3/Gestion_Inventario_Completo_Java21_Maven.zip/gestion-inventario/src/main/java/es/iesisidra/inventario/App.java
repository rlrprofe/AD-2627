package es.iesisidra.inventario;

import es.iesisidra.inventario.configuracion.Configuracion;
import es.iesisidra.inventario.controlador.ProductoControlador;
import es.iesisidra.inventario.dao.ProductoDAO;
import es.iesisidra.inventario.servicio.ProductoService;
import es.iesisidra.inventario.vista.ConsolaVista;
import java.util.Scanner;

/** Punto de entrada y composición de componentes: no contiene menús ni reglas de negocio. */
public final class App {
    private App() { }
    public static void main(String[] args) {
        try {
            ProductoDAO dao = Configuracion.crearDao();
            ProductoService servicio = new ProductoService(dao);
            try (Scanner scanner = new Scanner(System.in)) {
                ConsolaVista vista = new ConsolaVista(scanner, System.out);
                new ProductoControlador(servicio, vista).iniciar();
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Error de configuración: " + e.getMessage());
        }
    }
}
