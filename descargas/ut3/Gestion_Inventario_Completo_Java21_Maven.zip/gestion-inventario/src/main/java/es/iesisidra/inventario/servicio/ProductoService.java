package es.iesisidra.inventario.servicio;

import es.iesisidra.inventario.dao.ProductoDAO;
import es.iesisidra.inventario.modelo.Producto;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/** Reglas de negocio independientes de la interfaz y del almacenamiento. */
public final class ProductoService {
    private final ProductoDAO dao;
    public ProductoService(ProductoDAO dao) { this.dao = Objects.requireNonNull(dao); }
    public void alta(Producto producto) {
        validar(producto);
        if (dao.buscarPorId(producto.id()).isPresent()) throw new IllegalArgumentException("El ID ya existe");
        dao.insertar(producto);
    }
    public Optional<Producto> buscar(int id) { validarId(id); return dao.buscarPorId(id); }
    public List<Producto> listar() { return dao.listar().stream().sorted(Comparator.comparingInt(Producto::id)).toList(); }
    public boolean modificar(Producto producto) { validar(producto); return dao.actualizar(producto); }
    public boolean baja(int id) { validarId(id); return dao.eliminar(id); }
    private void validarId(int id) {
        if (id <= 0) throw new IllegalArgumentException("El ID debe ser positivo");
    }
    private void validar(Producto p) {
        Objects.requireNonNull(p, "El producto no puede ser nulo");
        validarId(p.id());
        if (p.nombre() == null || p.nombre().isBlank() || p.nombre().length() > 150)
            throw new IllegalArgumentException("El nombre es obligatorio (máximo 150 caracteres)");
        if (!Double.isFinite(p.precio()) || p.precio() < 0)
            throw new IllegalArgumentException("El precio debe ser un número no negativo");
        if (p.stock() < 0) throw new IllegalArgumentException("El stock no puede ser negativo");
    }
}
