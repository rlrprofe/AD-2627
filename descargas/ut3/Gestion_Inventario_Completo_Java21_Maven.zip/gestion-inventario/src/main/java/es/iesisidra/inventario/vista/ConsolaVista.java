package es.iesisidra.inventario.vista;

import es.iesisidra.inventario.modelo.Producto;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

/** Única clase responsable de leer del teclado y escribir en la consola. */
public final class ConsolaVista {
    private final Scanner entrada;
    private final PrintStream salida;
    public ConsolaVista(Scanner entrada, PrintStream salida) {
        this.entrada = entrada;
        this.salida = salida;
    }
    public int solicitarOpcion() {
        salida.println("\n=== GESTIÓN DE INVENTARIO ===");
        salida.println("1. Alta | 2. Buscar | 3. Listar | 4. Modificar | 5. Eliminar | 0. Salir");
        return leerEntero("Opción: ");
    }
    public Producto solicitarProducto() {
        int id = leerEntero("ID: ");
        String nombre = leerTexto("Nombre: ");
        double precio = leerDecimal("Precio (usar punto decimal): ");
        int stock = leerEntero("Stock: ");
        return new Producto(id, nombre, precio, stock);
    }
    public int solicitarId() { return leerEntero("ID: "); }
    public void mostrarProducto(Producto producto) {
        salida.printf("ID: %d | Nombre: %s | Precio: %.2f | Stock: %d%n",
                producto.id(), producto.nombre(), producto.precio(), producto.stock());
    }
    public void mostrarProductos(List<Producto> productos) {
        if (productos.isEmpty()) { mostrarMensaje("No hay productos registrados."); return; }
        productos.forEach(this::mostrarProducto);
    }
    public void mostrarMensaje(String mensaje) { salida.println(mensaje); }
    public void mostrarError(String mensaje) { salida.println("Error: " + mensaje); }
    private String leerTexto(String etiqueta) {
        salida.print(etiqueta);
        if (!entrada.hasNextLine()) throw new EntradaFinalizadaException();
        return entrada.nextLine().trim();
    }
    private int leerEntero(String etiqueta) {
        while (true) {
            try { return Integer.parseInt(leerTexto(etiqueta)); }
            catch (NumberFormatException e) { mostrarError("Introduce un número entero válido."); }
        }
    }
    private double leerDecimal(String etiqueta) {
        while (true) {
            try {
                double valor = Double.parseDouble(leerTexto(etiqueta));
                if (!Double.isFinite(valor)) throw new NumberFormatException();
                return valor;
            } catch (NumberFormatException e) { mostrarError("Introduce un número decimal válido, por ejemplo 19.95."); }
        }
    }
    public static final class EntradaFinalizadaException extends RuntimeException { }
}
