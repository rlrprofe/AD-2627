package es.iesisidra.inventario.controlador;

import es.iesisidra.inventario.modelo.Producto;
import es.iesisidra.inventario.servicio.ProductoService;
import es.iesisidra.inventario.vista.ConsolaVista;
import es.iesisidra.inventario.vista.ConsolaVista.EntradaFinalizadaException;

/** Coordina las acciones del usuario; no lee teclado ni conoce CSV/JDBC. */
public final class ProductoControlador {
    private final ProductoService servicio;
    private final ConsolaVista vista;
    public ProductoControlador(ProductoService servicio, ConsolaVista vista) {
        this.servicio = servicio;
        this.vista = vista;
    }
    public void iniciar() {
        try {
            boolean continuar = true;
            while (continuar) {
                try { continuar = ejecutar(vista.solicitarOpcion()); }
                catch (IllegalArgumentException | IllegalStateException e) { vista.mostrarError(e.getMessage()); }
            }
        } catch (EntradaFinalizadaException e) {
            vista.mostrarMensaje("Entrada finalizada. Cerrando aplicación.");
        }
    }
    private boolean ejecutar(int opcion) {
        switch (opcion) {
            case 0 -> { vista.mostrarMensaje("Hasta pronto."); return false; }
            case 1 -> alta();
            case 2 -> buscar();
            case 3 -> listar();
            case 4 -> modificar();
            case 5 -> eliminar();
            default -> vista.mostrarError("Opción no válida.");
        }
        return true;
    }
    private void alta() {
        Producto producto = vista.solicitarProducto();
        servicio.alta(producto);
        vista.mostrarMensaje("Producto registrado.");
    }
    private void buscar() {
        servicio.buscar(vista.solicitarId()).ifPresentOrElse(
                vista::mostrarProducto, () -> vista.mostrarMensaje("Producto no encontrado."));
    }
    private void listar() { vista.mostrarProductos(servicio.listar()); }
    private void modificar() {
        boolean actualizado = servicio.modificar(vista.solicitarProducto());
        vista.mostrarMensaje(actualizado ? "Producto modificado." : "Producto no encontrado.");
    }
    private void eliminar() {
        boolean eliminado = servicio.baja(vista.solicitarId());
        vista.mostrarMensaje(eliminado ? "Producto eliminado." : "Producto no encontrado.");
    }
}
