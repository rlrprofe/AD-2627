package es.iesisidra.inventario.dao;

import es.iesisidra.inventario.modelo.Producto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** DAO docente para CSV simple, con escritura temporal y sustitución del fichero. */
public final class ProductoFicheroDAO implements ProductoDAO {
    private static final String CABECERA = "id;nombre;precio;stock";
    private final Path ruta;
    public ProductoFicheroDAO(Path ruta) { this.ruta = Objects.requireNonNull(ruta); }
    @Override public List<Producto> listar() {
        if (!Files.exists(ruta)) return new ArrayList<>();
        try {
            List<Producto> resultado = new ArrayList<>();
            int numero = 0;
            for (String linea : Files.readAllLines(ruta, StandardCharsets.UTF_8)) {
                numero++;
                if (linea.isBlank() || (numero == 1 && linea.equals(CABECERA))) continue;
                String[] campos = linea.split(";", -1);
                if (campos.length != 4) throw new IllegalStateException("CSV incorrecto en línea " + numero);
                try {
                    resultado.add(new Producto(Integer.parseInt(campos[0]), campos[1],
                            Double.parseDouble(campos[2]), Integer.parseInt(campos[3])));
                } catch (NumberFormatException e) {
                    throw new IllegalStateException("Datos numéricos incorrectos en línea " + numero, e);
                }
            }
            return resultado;
        } catch (IOException e) { throw new IllegalStateException("No se pudo leer el CSV: " + ruta, e); }
    }
    @Override public Optional<Producto> buscarPorId(int id) {
        return listar().stream().filter(p -> p.id() == id).findFirst();
    }
    @Override public void insertar(Producto p) {
        List<Producto> productos = listar();
        if (productos.stream().anyMatch(x -> x.id() == p.id())) throw new IllegalArgumentException("El ID ya existe");
        productos.add(p);
        guardar(productos);
    }
    @Override public boolean actualizar(Producto p) {
        List<Producto> productos = listar();
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).id() == p.id()) {
                productos.set(i, p); guardar(productos); return true;
            }
        }
        return false;
    }
    @Override public boolean eliminar(int id) {
        List<Producto> productos = listar();
        boolean eliminado = productos.removeIf(p -> p.id() == id);
        if (eliminado) guardar(productos);
        return eliminado;
    }
    private void guardar(List<Producto> productos) {
        List<String> lineas = new ArrayList<>();
        lineas.add(CABECERA);
        for (Producto p : productos) {
            if (p.nombre() == null || p.nombre().contains(";") || p.nombre().contains("\n") || p.nombre().contains("\r"))
                throw new IllegalArgumentException("El nombre no puede contener punto y coma ni saltos de línea en CSV simple");
            lineas.add(p.id() + ";" + p.nombre() + ";" + p.precio() + ";" + p.stock());
        }
        Path temporal = null;
        try {
            Path destino = ruta.toAbsolutePath();
            Path carpeta = destino.getParent();
            Files.createDirectories(carpeta);
            temporal = Files.createTempFile(carpeta, "productos-", ".tmp");
            Files.write(temporal, lineas, StandardCharsets.UTF_8);
            try { Files.move(temporal, destino, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporal, destino, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { throw new IllegalStateException("No se pudo guardar el CSV: " + ruta, e); }
        finally { if (temporal != null) try { Files.deleteIfExists(temporal); } catch (IOException ignored) { } }
    }
}
