# Gestión de inventario — solución mejorada UT3 (Java 21 + Maven)

Esta versión parte de la solución de la UT3 y mantiene las operaciones **alta, búsqueda, listado, modificación y eliminación** con persistencia **CSV o MySQL**. Su objetivo didáctico es separar responsabilidades mediante **MVC + servicio + DAO**.

## Arquitectura

```text
App (crea y conecta objetos; no muestra menús)
 ├─ Configuracion → ProductoDAO
 │                   ├─ ProductoFicheroDAO → datos/productos.csv
 │                   └─ ProductoJdbcDAO → MySQL
 └─ ProductoControlador → ProductoService → ProductoDAO
             ↕
        ConsolaVista (teclado y pantalla)
```

| Clase | Responsabilidad |
|---|---|
| `App` | Punto de entrada y composición de dependencias. |
| `Configuracion` | Selección del DAO según `INVENTARIO_STORAGE`. |
| `ConsolaVista` | Menús, mensajes, formato y lectura validada de números. |
| `ProductoControlador` | Interpreta opciones y coordina vista y servicio. |
| `ProductoService` | Valida datos y aplica reglas de negocio. |
| `Producto` | Modelo de datos inmutable (`record`). |
| `ProductoDAO` | Contrato CRUD de persistencia. |
| `ProductoFicheroDAO` | Persistencia en CSV simple. |
| `ProductoJdbcDAO` | Persistencia JDBC con `PreparedStatement`. |
| `ConexionBD` | Obtención de conexiones JDBC. |

**Flujo de un alta:** `ConsolaVista` solicita los datos → `ProductoControlador` los envía a `ProductoService` → el servicio valida y usa `ProductoDAO` → el DAO guarda en CSV o MySQL → el controlador solicita a la vista mostrar el resultado.

## Requisitos y ejecución

- JDK 21 y Maven 3.9 o posterior compatible.
- MySQL solo si se usa el modo JDBC.

```bash
mvn clean test
mvn clean package
java -jar target/gestion-inventario-1.0-SNAPSHOT.jar
```

Por defecto se usa **CSV**. Ejecuta desde la raíz del proyecto porque `datos/productos.csv` es una ruta relativa. Para comenzar con datos vacíos, haz una copia de seguridad del CSV y elimina los registros existentes.

## Modo MySQL

1. Ejecuta `sql/inventario.sql` en MySQL (crea la base `inventario` y la tabla `producto`).
2. Crea un usuario con permisos sobre esa base.
3. Configura las variables de entorno **fuera del código**.

PowerShell:

```powershell
$env:INVENTARIO_STORAGE="mysql"
$env:INVENTARIO_DB_URL="jdbc:mysql://localhost:3306/inventario"
$env:INVENTARIO_DB_USER="inventario_app"
$env:INVENTARIO_DB_PASSWORD="TU_CLAVE_LOCAL"
java -jar target/gestion-inventario-1.0-SNAPSHOT.jar
```

Para volver al modo CSV en la misma terminal:

```powershell
$env:INVENTARIO_STORAGE="csv"
```

## Qué se ha mejorado respecto a la solución anterior

1. `App` ya no contiene el menú, la lectura de números ni las operaciones CRUD.
2. La vista concentra **toda la entrada y salida** y presenta los productos con formato.
3. El controlador contiene métodos pequeños para cada operación.
4. El servicio concentra validaciones y devuelve el listado ordenado por ID.
5. El CSV se escribe primero en un archivo temporal y se sustituye el destino, para reducir el riesgo de pérdida de datos si la escritura falla.
6. Se añaden pruebas del controlador, la vista simulada y el DAO de fichero, sin necesitar MySQL.

## Limitaciones didácticas

- Se mantiene `double` para el precio por coherencia con la UT3 original; en producción se recomienda `BigDecimal`.
- El CSV es deliberadamente simple: no admite `;` ni saltos de línea en los nombres; no es un lector CSV completo ni está preparado para escrituras simultáneas.
- Las operaciones de fichero reescriben el CSV completo; resulta adecuado para un ejemplo pequeño, no para grandes volúmenes.
- La aplicación usa una vista de consola; MVC no exige una interfaz gráfica.
- No se han incluido pruebas de integración MySQL: necesitan una instancia configurada y datos de prueba controlados.
- Se conserva la estructura y el esquema SQL de la solución original; el archivo `01-productos.sql` adjunto corresponde a **otro esquema** (`ut3_componentes.productos`) y no se debe mezclar con este proyecto.
