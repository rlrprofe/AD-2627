package com.example.ejemplo1;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Manejador SAX para biblioteca.xml.
 * Reacciona a los eventos durante la lectura:
 * - apertura de etiquetas
 * - texto interno
 * - cierre de etiquetas
 */
public class ManejadorBiblioteca extends DefaultHandler {

    private String etiquetaActual = "";  // guarda el nombre de la etiqueta activa
    private String id, genero, titulo, autor, anio;

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Inicio del documento XML.");
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Fin del documento XML.");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        etiquetaActual = qName;  // guarda la etiqueta actual
        if (qName.equals("libro")) {
            id = attributes.getValue("id");
            genero = attributes.getValue("genero");
            System.out.println("\nLibro ID: " + id + "  (" + genero + ")");
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // Extrae el texto dentro de una etiqueta
        String texto = new String(ch, start, length).trim();

        // Ignora textos vacíos o saltos de línea
        if (texto.isEmpty()) return;

        // Detecta en qué etiqueta estamos
        switch (etiquetaActual) {
            case "titulo":
                titulo = texto;
                break;
            case "autor":
                autor = texto;
                break;
            case "anio":
                anio = texto;
                break;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals("libro")) {
            // Al cerrar <libro> mostramos la información completa
            System.out.println("  Título: " + titulo);
            System.out.println("  Autor: " + autor);
            System.out.println("  Año: " + anio);
        }
        etiquetaActual = ""; // reiniciar
    }
}
