package com.example.ejemplo3;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import java.util.ArrayList;
import java.util.List;

/**
 * Manejador SAX que convierte el XML en objetos Alumno.
 * Estrategia:
 * - Cuando empieza <alumno>, se crea un Alumno y se leen atributos id/curso.
 * - En characters() se acumula texto en un buffer (por si el parser lo trocea).
 * - Al cerrar </nombre>, </edad>, </nota> se copian los datos al Alumno.
 * - Al cerrar </alumno>, se añade el Alumno a la lista.
 */
public class ManejadorObjetosAlumno extends DefaultHandler {

    private List<Alumno> alumnos = new ArrayList<>();
    private Alumno actual;                 // Alumno que se está construyendo
    private String etiquetaActual = "";    // Nombre de la etiqueta abierta
    private StringBuilder bufferTexto = new StringBuilder(); // Acumula texto entre etiquetas

    public List<Alumno> getAlumnos() {
        return alumnos;
    }

    @Override
    public void startDocument() throws SAXException {
        // No hacemos nada especial al inicio
    }

    @Override
    public void endDocument() throws SAXException {
        // No hacemos nada especial al final
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        etiquetaActual = qName;
        bufferTexto.setLength(0); // limpiar buffer al abrir una etiqueta

        if ("alumno".equals(qName)) {
            actual = new Alumno();
            // Leer atributos id y curso
            actual.setId(atts.getValue("id"));
            actual.setCurso(atts.getValue("curso"));
        }
        // Para nombre, edad, nota no creamos nada aquí; solo preparamos bufferTexto
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // Acumular el texto tal cual (sin trim aquí) porque puede venir troceado
        bufferTexto.append(ch, start, length);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // Al cerrar etiquetas hoja, trasladamos el texto acumulado al objeto Alumno
        String texto = bufferTexto.toString().trim();

        if ("nombre".equals(qName)) {
            actual.setNombre(texto);
        } else if ("edad".equals(qName)) {
            if (!texto.isEmpty()) {
                actual.setEdad(Integer.parseInt(texto));
            }
        } else if ("nota".equals(qName)) {
            if (!texto.isEmpty()) {
                actual.setNota(Double.parseDouble(texto.replace(',', '.')));
            }
        } else if ("alumno".equals(qName)) {
            // Cerramos el alumno y lo añadimos a la lista
            alumnos.add(actual);
            actual = null;
        }

        // Reiniciar estado para la siguiente etiqueta
        etiquetaActual = "";
        bufferTexto.setLength(0);
    }
}
