package com.example.ejemplo2;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * Ejemplo SAX con centro/alumnos.
 * Procesa un XML de alumnos y muestra sus datos sin cargar todo el documento en memoria.
 */
public class LeerAlumnos_SAX {
    public static void main(String[] args) {
        try {
            // 1) Crear la fábrica de parsers SAX
            SAXParserFactory factory = SAXParserFactory.newInstance();

            // 2) Crear el parser
            SAXParser parser = factory.newSAXParser();

            // 3) Crear el manejador (listener de eventos)
            ManejadorAlumnos manejador = new ManejadorAlumnos();

            // 4) Procesar el XML
            parser.parse("resources/alumnos.xml", manejador);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
