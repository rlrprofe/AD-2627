package com.example.ejemplo1;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * Ejemplo de lectura con SAX: biblioteca.xml
 * Muestra los datos de cada libro usando un manejador de eventos.
 */
public class LeerXML_SAX {
    public static void main(String[] args) {
        try {
            // 1) Crear la fábrica y el parser SAX
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();

            // 2) Crear el manejador personalizado
            ManejadorBiblioteca manejador = new ManejadorBiblioteca();

            // 3) Procesar el XML
            parser.parse("resources/biblioteca.xml", manejador);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
/*
 * En SAX, los datos se procesan al vuelo, sin guardarse todo en memoria.
 * No existe un árbol ni posibilidad de “volver atrás” como en DOM.
 * Ideal para leer ficheros XML muy grandes o flujos de datos (por ejemplo, logs, catálogos, facturas electrónicas…).
 */