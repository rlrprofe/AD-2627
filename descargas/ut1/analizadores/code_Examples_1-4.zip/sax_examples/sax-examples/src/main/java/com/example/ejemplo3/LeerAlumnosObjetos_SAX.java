package com.example.ejemplo3;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.util.Comparator;
import java.util.List;

/**
 * Lee alumnos.xml con SAX y construye una lista de Alumno.
 * Luego muestra los alumnos, calcula estadísticas y filtra resultados.
 */
public class LeerAlumnosObjetos_SAX {
    public static void main(String[] args) {
        try {
            // 1) Crear parser SAX
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();

            // 2) Usar manejador que crea objetos
            ManejadorObjetosAlumno handler = new ManejadorObjetosAlumno();
            parser.parse("resources/alumnos.xml", handler);

            // 3) Obtener la lista resultante
            List<Alumno> alumnos = handler.getAlumnos();

            // 4) Mostrar alumnos leídos
            System.out.println("Alumnos leídos:");
            alumnos.forEach(System.out::println);

            // 5) Estadísticas simples: media de notas
            double media = alumnos.stream().mapToDouble(Alumno::getNota).average().orElse(0.0);
            System.out.printf("%nMedia de notas: %.2f%n", media);

            // 6) Filtrar alumnos con nota >= 8.0
            System.out.println("\nAlumnos con nota >= 8.0:");
            alumnos.stream()
                   .filter(a -> a.getNota() >= 8.0)
                   .sorted(Comparator.comparingDouble(Alumno::getNota).reversed())
                   .forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
