package com.example.ejemplo2;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Manejador SAX para el XML de alumnos.
 * Demuestra cómo procesar atributos, texto y cerrar elementos.
 */
public class ManejadorAlumnos extends DefaultHandler {

    private String etiquetaActual = "";
    private String id, curso, nombre, edad, nota;
    private int contador = 0; // cuenta cuántos alumnos hay

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Inicio del documento XML de alumnos.\n");
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("\nFin del documento. Total de alumnos procesados: " + contador);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        etiquetaActual = qName; // guarda el nombre de la etiqueta actual

        // Cuando se abre un <alumno>, obtenemos sus atributos
        if (qName.equals("alumno")) {
            id = attributes.getValue("id");
            curso = attributes.getValue("curso");
            System.out.println("Alumno ID: " + id + " | Curso: " + curso);
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // Captura el texto entre etiquetas (puede haber espacios o saltos)
        String texto = new String(ch, start, length).trim();
        if (texto.isEmpty()) return;

        // Según la etiqueta actual, guardamos la información
        switch (etiquetaActual) {
            case "nombre":
                nombre = texto;
                break;
            case "edad":
                edad = texto;
                break;
            case "nota":
                nota = texto;
                break;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // Cuando se cierra una etiqueta <alumno>, mostramos toda la información
        if (qName.equals("alumno")) {
            contador++;
            System.out.println("  Nombre: " + nombre);
            System.out.println("  Edad: " + edad + " años");
            System.out.println("  Nota: " + nota);
            System.out.println("-----------------------------------------");
        }
        etiquetaActual = ""; // reiniciamos al salir de la etiqueta
    }
}

