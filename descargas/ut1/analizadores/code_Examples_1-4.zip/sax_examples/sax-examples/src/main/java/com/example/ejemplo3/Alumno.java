package com.example.ejemplo3;

public class Alumno {
    private String id;
    private String curso;
    private String nombre;
    private int    edad;
    private double nota;

    public Alumno() {}

    public Alumno(String id, String curso, String nombre, int edad, double nota) {
        this.id = id;
        this.curso = curso;
        this.nombre = nombre;
        this.edad = edad;
        this.nota = nota;
    }

    public String getId() { return id; }
    public String getCurso() { return curso; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    public double getNota() { return nota; }

    public void setId(String id) { this.id = id; }
    public void setCurso(String curso) { this.curso = curso; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEdad(int edad) { this.edad = edad; }
    public void setNota(double nota) { this.nota = nota; }

    @Override
    public String toString() {
        return "[" + id + "] " + nombre + " (" + curso + "), edad=" + edad + ", nota=" + nota;
    }
}
