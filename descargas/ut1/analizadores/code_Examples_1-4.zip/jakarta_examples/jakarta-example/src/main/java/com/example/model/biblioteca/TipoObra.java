package com.example.model.biblioteca;
import jakarta.xml.bind.annotation.XmlEnum;
import jakarta.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum TipoObra {
    @XmlEnumValue("LIBRO") LIBRO,
    @XmlEnumValue("REVISTA") REVISTA,
    @XmlEnumValue("COMIC") COMIC
}

