package com.example;

import jakarta.xml.bind.*;
import java.io.File;
import com.example.model.biblioteca.*;

public class MainBiblioteca {
    public static void main(String[] args) throws Exception {
        // Construimos una biblioteca de prueba
        Biblioteca b = new Biblioteca();
        b.addObra(new Obra("O01", "Cien años de soledad", "G.G. Márquez", 1967,
                TipoObra.LIBRO, new Comentario("Imprescindible en narrativa hispanoamericana")));
        b.addObra(new Obra("O02", "Astérix en Hispania", "Uderzo & Goscinny", 1969,
                TipoObra.COMIC, new Comentario("Clásico del cómic europeo")));

        JAXBContext ctx = JAXBContext.newInstance(Biblioteca.class, Obra.class, Comentario.class, TipoObra.class);
        Marshaller m = ctx.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // A consola y fichero
        m.marshal(b, System.out);
        File f = new File("biblioteca.xml");
        m.marshal(b, f);

        // Leemos de vuelta
        Unmarshaller u = ctx.createUnmarshaller();
        Biblioteca leida = (Biblioteca) u.unmarshal(f);
        System.out.println("\nObras leídas: " + leida.getObras().size());
    }
}
/*
 * Cosas importantes de este ejemplo:
Constructor vacío obligatorio y no mezclar javax.xml.bind.* con jakarta.xml.bind.*.

@XmlAccessorType(XmlAccessType.FIELD) simplifica mucho (no hay que anotar getters).

@XmlElementWrapper + @XmlElement es el patrón estándar para listas.

@XmlType(propOrder=...) controla el orden de las etiquetas en el XML.

@XmlEnum/@XmlEnumValue te permite decidir cómo se escriben los enum.

@XmlTransient excluye campos del XML (útil para contraseñas, notas internas, etc.).

@XmlValue es perfecto para contenido textual directo sin subelementos.
 * 
 */