package com.example.model.biblioteca;

// Representa un libro simple. Usamos anotaciones JAXB para mapear a XML.
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "libro")                 // <libro ...> es la raíz del XML
@XmlAccessorType(XmlAccessType.FIELD)           // JAXB accede por CAMPOS (no por getters)
public class Libro {
    @XmlAttribute(name = "id")                  // <libro id="L001">
    private String id;

    @XmlElement(name = "titulo")                //   <titulo>...</titulo>
    private String titulo;

    @XmlElement(name = "autor")                 //   <autor>...</autor>
    private String autor;

    // JAXB necesita constructor sin argumentos
    public Libro() {}

    public Libro(String id, String titulo, String autor) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
    }

    // Getters/setters recomendables para uso general (aunque usemos FIELD)
    public String getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public void setId(String id) { this.id = id; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setAutor(String autor) { this.autor = autor; }
}
