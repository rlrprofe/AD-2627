/*Un Curso contiene múltiples alumnos. */

package com.example.model;

import jakarta.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "curso")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"codigo", "nombre", "alumnos"}) // Orden deseado en el XML
public class Curso {

    @XmlAttribute(name = "anyo") // atributo en la raíz <curso anyo="2025">
    private int anyo;

    @XmlElement
    private String codigo;

    @XmlElement
    private String nombre;

    // Envolvemos la lista en <alumnos> ... </alumnos>
    @XmlElementWrapper(name = "alumnos")
    @XmlElement(name = "alumno")
    private List<Alumno> alumnos = new ArrayList<>();

    @XmlTransient
    private String notaInterna; // no se serializa

    public Curso() {}
    public Curso(int anyo, String codigo, String nombre) {
        this.anyo = anyo; this.codigo = codigo; this.nombre = nombre;
    }

    // Utilidad
    public void addAlumno(Alumno a) { alumnos.add(a); }

    // Getters/setters
    public int getAnyo() { return anyo; }
    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public List<Alumno> getAlumnos() { return alumnos; }
    public void setAnyo(int anyo) { this.anyo = anyo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setAlumnos(List<Alumno> alumnos) { this.alumnos = alumnos; }
}
