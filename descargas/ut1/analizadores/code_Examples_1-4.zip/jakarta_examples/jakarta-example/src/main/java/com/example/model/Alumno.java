package com.example.model;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Alumno {
    @XmlAttribute
    private String id;

    @XmlElement
    private String nombre;

    @XmlElement
    private int edad;

    public Alumno() {}
    public Alumno(String id, String nombre, int edad) {
        this.id = id; this.nombre = nombre; this.edad = edad;
    }

    // Getters/setters
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    public void setId(String id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEdad(int edad) { this.edad = edad; }
}
