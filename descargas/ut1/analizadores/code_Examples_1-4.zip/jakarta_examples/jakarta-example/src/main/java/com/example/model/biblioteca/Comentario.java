package com.example.model.biblioteca;

import jakarta.xml.bind.annotation.XmlValue;

// Representa un texto simple dentro de una etiqueta <comentario>Texto...</comentario>
public class Comentario {
    @XmlValue
    private String texto;

    public Comentario() {}
    public Comentario(String texto) { this.texto = texto; }

    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }
}
