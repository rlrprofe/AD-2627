package com.example;

// Demuestra marshalling y unmarshalling con la clase Libro.
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import java.io.File;

import com.example.model.biblioteca.Libro;


public class MainLibro {
    public static void main(String[] args) throws Exception {
        // 1) Creamos un objeto normal de Java
        Libro libro = new Libro("L001", "El Quijote", "Miguel de Cervantes");

        // 2) Preparamos JAXB para la clase Libro
        JAXBContext ctx = JAXBContext.newInstance(Libro.class);

        // 3) Marshalling: objeto -> XML (o otro formato)
        Marshaller marshaller = ctx.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // A) A consola
        marshaller.marshal(libro, System.out);

        // B) A fichero
        File out = new File("resources/libro.xml");
        marshaller.marshal(libro, out);

        // 4) Unmarshalling: XML -> objeto
        Unmarshaller unmarshaller = ctx.createUnmarshaller();
        Libro leido = (Libro) unmarshaller.unmarshal(out);

        System.out.println("\nLeído desde XML: " + leido.getId() + " - " +
                leido.getTitulo() + " - " + leido.getAutor());
    }
}

