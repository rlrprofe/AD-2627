package com.example.model.biblioteca;
import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"titulo", "autor", "anio", "tipo", "comentario"})
public class Obra {

    @XmlAttribute
    private String id;

    @XmlElement
    private String titulo;

    @XmlElement
    private String autor;

    @XmlElement(name = "anioPublicacion")
    private int anio;

    @XmlElement
    private TipoObra tipo;

    @XmlElement
    private Comentario comentario; // <comentario>Texto...</comentario>

    public Obra() {}
    public Obra(String id, String titulo, String autor, int anio, TipoObra tipo, Comentario comentario) {
        this.id = id; this.titulo = titulo; this.autor = autor; this.anio = anio; this.tipo = tipo; this.comentario = comentario;
    }

    // Getters/setters
    public String getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public int getAnio() { return anio; }
    public TipoObra getTipo() { return tipo; }
    public Comentario getComentario() { return comentario; }
    public void setId(String id) { this.id = id; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setAutor(String autor) { this.autor = autor; }
    public void setAnio(int anio) { this.anio = anio; }
    public void setTipo(TipoObra tipo) { this.tipo = tipo; }
    public void setComentario(Comentario comentario) { this.comentario = comentario; }
}
