package com.example;

import jakarta.xml.bind.*;
import java.io.File;
import com.example.model.Alumno;
import com.example.model.Curso;

public class MainCurso {
    public static void main(String[] args) throws Exception {
        Curso c = new Curso(2025, "DAM-AD", "Acceso a Datos");
        c.addAlumno(new Alumno("A01", "Lucía", 21));
        c.addAlumno(new Alumno("A02", "Hugo", 20));

        JAXBContext ctx = JAXBContext.newInstance(Curso.class);
        Marshaller m = ctx.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // A consola y a fichero
        m.marshal(c, System.out);
        File f = new File("resources/curso.xml");
        m.marshal(c, f);

        // Leemos de nuevo
        Unmarshaller u = ctx.createUnmarshaller();
        Curso leido = (Curso) u.unmarshal(f);
        System.out.println("\nLeído: " + leido.getCodigo() + " con " + leido.getAlumnos().size() + " alumnos.");
    }
}
