package com.example.model.biblioteca;

import jakarta.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "biblioteca")
@XmlAccessorType(XmlAccessType.FIELD)
public class Biblioteca {

    @XmlElementWrapper(name = "obras")    // Contenedor de la lista
    @XmlElement(name = "obra")            // Nombre de cada item
    private List<Obra> obras = new ArrayList<>();

    public Biblioteca() {}
    public List<Obra> getObras() { return obras; }
    public void setObras(List<Obra> obras) { this.obras = obras; }
    public void addObra(Obra o) { obras.add(o); }
}
