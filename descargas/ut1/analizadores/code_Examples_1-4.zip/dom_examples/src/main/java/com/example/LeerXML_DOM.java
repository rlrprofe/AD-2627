package com.example;

/**
 * Ejemplo de lectura XML DOM
 */
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.File;

public class LeerXML_DOM {
    public static void main(String[] args) {
        try {
            // Crear "fábrica" y parser DOM
            //Entendemos por fábrica una clase que se encarga de crear objetos de un tipo concreto, en nuestro caso parsers DOM
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // Cargar el XML en memoria como árbol DOM
            Document doc = builder.parse(new File("resources/alumnos.xml"));

            // Normalizar el documento (recomendada siempre)
             /* Cuando el parser DOM construye el árbol de nodos, puede encontrarse espacios en blanco, 
             * saltos de línea o fragmentos de texto que hacen que el árbol quede fragmentado o con nodos de texto innecesarios.
             * La normalización reorganiza el DOM en un estado "limpio"
             */
            doc.getDocumentElement().normalize();


            /*
             * doc → es el objeto Document, que representa el XML completo.
            * getDocumentElement() → devuelve el primer nodo de tipo Element, es decir, la etiqueta raíz.
             */
         
            Element raiz = doc.getDocumentElement();    // Obtener el nodo raíz <alumnos>

            System.out.println("Raíz del documento: " + raiz.getNodeName());

            // Obtener lista de nodos <alumno>
            NodeList listaAlumnos = doc.getElementsByTagName("alumno");

            // Recorrer los nodos <alumno>
            for (int i = 0; i < listaAlumnos.getLength(); i++) {
                Node nodo = listaAlumnos.item(i);
                /*
                    * Cuando el parser DOM analiza un XML, crea distintos tipos de nodos en el árbol.
                    * El método getNodeType() devuelve un número constante que indica el tipo de cada nodo.
                    * Solo quiero procesar los nodos que son etiquetas XML reales (por ejemplo <alumno>),
                    * y no los nodos de texto, espacios en blanco ni comentarios
                    */
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                  
                    Element alumno = (Element) nodo;

                    // Leer atributo y subelementos
                    String id = alumno.getAttribute("id");
                    String nombre = alumno.getElementsByTagName("nombre")
                                          .item(0).getTextContent();
                    String edad = alumno.getElementsByTagName("edad")
                                          .item(0).getTextContent();

                    System.out.printf("Alumno %s → %s (%s años)%n", id, nombre, edad);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
