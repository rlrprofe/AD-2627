package com.example;
/*
 * Segundo ejemplo DOM más completo para practicar distintos métodos del API (getChildNodes, getTagName, getNodeValue, setTextContent, setAttribute, etc.).
*  También incluye ejemplos de lectura, modificación y creación de nuevos nodos.
 */
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import java.io.File;

public class GestionBiblioteca_DOM {

    public static void main(String[] args) {
        try {
            // Crear parser y cargar el XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File("resources/biblioteca.xml"));
            doc.getDocumentElement().normalize();

            // Obtener el nodo raíz <biblioteca>
            Element raiz = doc.getDocumentElement();
            System.out.println("Raíz: " + raiz.getNodeName());

            // Listar todos los libros
            NodeList listaLibros = doc.getElementsByTagName("libro");
            System.out.println("Total de libros: " + listaLibros.getLength());
            System.out.println("--------------------------------------------------");

            for (int i = 0; i < listaLibros.getLength(); i++) {
                Element libro = (Element) listaLibros.item(i);
                String id = libro.getAttribute("id");
                String genero = libro.getAttribute("genero");
                String titulo = libro.getElementsByTagName("titulo").item(0).getTextContent();
                String autor = libro.getElementsByTagName("autor").item(0).getTextContent();
                String anio = libro.getElementsByTagName("anio").item(0).getTextContent();

                System.out.printf("[%s] %s (%s) - %s, %s%n", id, titulo, genero, autor, anio);
            }

            System.out.println("--------------------------------------------------");

            // Modificar el contenido de un nodo
            Element primerLibro = (Element) listaLibros.item(0);
            Element anio = (Element) primerLibro.getElementsByTagName("anio").item(0);
            anio.setTextContent("1938"); // cambiamos el año de publicación
            System.out.println("Año actualizado del primer libro.");

            // Añadir un nuevo atributo a un libro existente
            primerLibro.setAttribute("edicion", "Revisada");

            // Crear un nuevo libro desde cero
            Element nuevoLibro = doc.createElement("libro");
            nuevoLibro.setAttribute("id", "L03");
            nuevoLibro.setAttribute("genero", "Fantasía");

            Element titulo = doc.createElement("titulo");
            titulo.setTextContent("Harry Potter y la piedra filosofal");

            Element autor = doc.createElement("autor");
            autor.setTextContent("J.K. Rowling");

            Element anioNuevo = doc.createElement("anio");
            anioNuevo.setTextContent("1997");

            // Añadir los subnodos al nuevo libro
            nuevoLibro.appendChild(titulo);
            nuevoLibro.appendChild(autor);
            nuevoLibro.appendChild(anioNuevo);

            // Añadir el libro completo a la raíz
            raiz.appendChild(nuevoLibro);
            System.out.println("Nuevo libro añadido.");

            // Mostrar todos los hijos de la raíz (usando getChildNodes)
            NodeList hijosRaiz = raiz.getChildNodes();
            System.out.println("Hijos de <biblioteca>:");
            for (int i = 0; i < hijosRaiz.getLength(); i++) {
                Node nodo = hijosRaiz.item(i);
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    System.out.println("→ " + nodo.getNodeName());
                }
            }

            // Guardar los cambios en un nuevo fichero XML
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); // formato legible
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("resources/biblioteca_modificada.xml"));
            transformer.transform(source, result);

            System.out.println("\n Archivo 'biblioteca_modificada.xml' guardado correctamente.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
