package com.example;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import java.io.File;

/**
 * CRUD con DOM sobre biblioteca.xml
 * - Listar todos los libros
 * - Añadir un libro
 * - Modificar un libro existente (por id)
 * - Eliminar un libro (por id)
 * - Guardar el resultado limpio (sin líneas en blanco innecesarias)
 *
 * Requisitos:
 * - Colocar biblioteca.xml en /resources
 */
public class GestionBibliotecaCRUD_DOM {

    public static void main(String[] args) {
        try {
            // 1) Crear parser DOM
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // 2) Cargar el XML en memoria
            Document doc = builder.parse(new File("resources/biblioteca.xml"));
            doc.getDocumentElement().normalize();

            // 3) Raíz del documento <biblioteca>
            Element raiz = doc.getDocumentElement();

            // 4) Listado inicial
            System.out.println("Listado inicial:");
            listarLibros(doc);
            System.out.println("--------------------------------------------------");

            // 5) Añadir un libro nuevo
            System.out.println("Añadiendo libro L03...");
            anadirLibro(doc, "L03", "Fantasía", "Harry Potter y la piedra filosofal", "J.K. Rowling", "1997");

            // 6) Modificar un libro existente
            System.out.println("Modificando libro L01 (año y atributo edicion)...");
            modificarLibro(doc, "L01", "El Hobbit", "J.R.R. Tolkien", "1938", "Ficción", "Revisada");

            // 7) Eliminar un libro por id
            System.out.println("Eliminando libro L02...");
            eliminarLibro(doc, "L02");

            // 8) Listado final tras operaciones
            System.out.println("Listado final:");
            listarLibros(doc);
            System.out.println("--------------------------------------------------");

            // 9) Limpiar nodos de texto vacíos para evitar líneas en blanco al guardar
            removeEmptyTextNodes(raiz);

            // 10) Guardar resultado con indentación legible
            guardar(doc, "resources/biblioteca_modificada_crud.xml");

            System.out.println("Archivo 'biblioteca_modificada_crud.xml' guardado correctamente.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ========= Operaciones CRUD ========= */

    /** Lista todos los libros del documento por consola. */
    private static void listarLibros(Document doc) {
        NodeList lista = doc.getElementsByTagName("libro");
        System.out.println("Total de libros: " + lista.getLength());
        for (int i = 0; i < lista.getLength(); i++) {
            Element libro = (Element) lista.item(i);
            String id = libro.getAttribute("id");
            String genero = libro.getAttribute("genero");
            String titulo = getTextOf(libro, "titulo");
            String autor = getTextOf(libro, "autor");
            String anio = getTextOf(libro, "anio");
            System.out.printf("[%s] %s (%s) - %s, %s%n", id, titulo, genero, autor, anio);
        }
    }

    /**
     * Añade un libro a la raíz.
     * Si ya existe un libro con el mismo id, no lo añade (id único).
     */
    private static void anadirLibro(Document doc, String id, String genero, String titulo, String autor, String anio) {
        if (findLibroById(doc, id) != null) {
            System.out.println("No se añade: ya existe un libro con id " + id);
            return;
        }
        Element raiz = doc.getDocumentElement();

        Element libro = doc.createElement("libro");
        libro.setAttribute("id", id);
        libro.setAttribute("genero", genero);

        Element eTitulo = doc.createElement("titulo");
        eTitulo.setTextContent(titulo);

        Element eAutor = doc.createElement("autor");
        eAutor.setTextContent(autor);

        Element eAnio = doc.createElement("anio");
        eAnio.setTextContent(anio);

        libro.appendChild(eTitulo);
        libro.appendChild(eAutor);
        libro.appendChild(eAnio);

        raiz.appendChild(libro);
    }

    /**
     * Modifica un libro existente por id.
     * Si alguno de los campos es null, no se cambia ese campo.
     * Puede opcionalmente establecer el atributo "edicion"; si es null, no se toca.
     */
    private static void modificarLibro(Document doc, String id, String nuevoTitulo, String nuevoAutor,
                                       String nuevoAnio, String nuevoGenero, String edicion) {
        Element libro = findLibroById(doc, id);
        if (libro == null) {
            System.out.println("No existe el libro con id " + id + ". No se modifica.");
            return;
        }
        if (nuevoTitulo != null) setTextOf(libro, "titulo", nuevoTitulo);
        if (nuevoAutor != null) setTextOf(libro, "autor", nuevoAutor);
        if (nuevoAnio != null) setTextOf(libro, "anio", nuevoAnio);
        if (nuevoGenero != null) libro.setAttribute("genero", nuevoGenero);
        if (edicion != null) libro.setAttribute("edicion", edicion);
    }

    /**
     * Elimina un libro por id.
     * Si no existe, no hace nada.
     */
    private static void eliminarLibro(Document doc, String id) {
        Element libro = findLibroById(doc, id);
        if (libro == null) {
            System.out.println("No existe el libro con id " + id + ". No se elimina.");
            return;
        }
        Node padre = libro.getParentNode();
        padre.removeChild(libro);
    }

    /* ========= Utilidades DOM (esto estaría en otro fichero, no lo complico más pero estaría como una utlidad de DOM) ========= */

    /** Busca y devuelve el elemento <libro> con el atributo id indicado, o null si no existe. */
    private static Element findLibroById(Document doc, String id) {
        NodeList lista = doc.getElementsByTagName("libro");
        for (int i = 0; i < lista.getLength(); i++) {
            Element libro = (Element) lista.item(i);
            if (id.equals(libro.getAttribute("id"))) {
                return libro;
            }
        }
        return null;
    }

    /** Devuelve el texto del primer subelemento con esa etiqueta. Si no existe, devuelve cadena vacía. */
    private static String getTextOf(Element padre, String tag) {
        Node n = padre.getElementsByTagName(tag).item(0);
        return (n != null) ? n.getTextContent() : "";
    }

    /** Cambia el texto del primer subelemento con esa etiqueta, si existe. */
    private static void setTextOf(Element padre, String tag, String texto) {
        Node n = padre.getElementsByTagName(tag).item(0);
        if (n != null) {
            n.setTextContent(texto);
        }
    }

    /**
     * Elimina nodos de texto vacíos (espacios y saltos entre etiquetas).
     * Esto evita líneas en blanco al guardar.
     */
    private static void removeEmptyTextNodes(Node node) {
        NodeList hijos = node.getChildNodes();
        for (int i = 0; i < hijos.getLength(); i++) {
            Node hijo = hijos.item(i);
            if (hijo.getNodeType() == Node.TEXT_NODE) {
                String txt = hijo.getTextContent();
                if (txt == null || txt.trim().isEmpty()) {
                    node.removeChild(hijo);
                    i--; // reajustar índice tras eliminar
                }
            } else if (hijo.hasChildNodes()) {
                removeEmptyTextNodes(hijo);
            }
        }
    }

    /** Guarda el árbol DOM en un fichero con indentación legible. */
    private static void guardar(Document doc, String nombreSalida) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        // Propiedad específica de Xalan para cantidad de espacios de indentación
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File(nombreSalida));
        transformer.transform(source, result);
    }
}
