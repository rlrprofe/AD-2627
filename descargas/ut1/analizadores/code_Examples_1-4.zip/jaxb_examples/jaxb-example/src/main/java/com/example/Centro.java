package com.example;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase raíz que corresponde a la etiqueta <centro>.
 * Contiene una lista de <alumno> envuelta por <alumnos>.
 */
@XmlRootElement(name = "centro")          // Mapea la raíz del documento
@XmlAccessorType(XmlAccessType.FIELD)
public class Centro {

    // <alumnos> envuelve una lista de <alumno>
    @XmlElementWrapper(name = "alumnos")  // Crea/espera el contenedor <alumnos>
    @XmlElement(name = "alumno")          // Elementos individuales dentro de <alumnos>
    private List<Alumno> alumnos = new ArrayList<>();

    public Centro() {}

    public List<Alumno> getAlumnos() { return alumnos; }
    public void setAlumnos(List<Alumno> alumnos) { this.alumnos = alumnos; }
}
