package com.example;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * Clase de dominio que representa a un alumno.
 * Anotamos campos para que JAXB sepa cómo mapear XML <-> Java.
 */
@XmlAccessorType(XmlAccessType.FIELD) // JAXB usará directamente los campos (no requiere getters/setters)
public class Alumno {

    // Atributos XML del elemento <alumno ...>
    @XmlAttribute
    private String id;

    @XmlAttribute
    private String curso;

    // Sub-elementos XML (<nombre>, <edad>, <nota>)
    @XmlElement
    private String nombre;

    @XmlElement
    private int edad;

    @XmlElement
    private double nota;

    // JAXB necesita un constructor vacío
    public Alumno() {}

    public Alumno(String id, String curso, String nombre, int edad, double nota) {
        this.id = id;
        this.curso = curso;
        this.nombre = nombre;
        this.edad = edad;
        this.nota = nota;
    }

    // Getters y setters recomendables (aunque con FIELD no estrictamente necesarios)
    public String getId() { return id; }
    public String getCurso() { return curso; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    public double getNota() { return nota; }

    public void setId(String id) { this.id = id; }
    public void setCurso(String curso) { this.curso = curso; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEdad(int edad) { this.edad = edad; }
    public void setNota(double nota) { this.nota = nota; }

    @Override
    public String toString() {
        return "[" + id + "] " + nombre + " (" + curso + "), edad=" + edad + ", nota=" + nota;
    }
}

