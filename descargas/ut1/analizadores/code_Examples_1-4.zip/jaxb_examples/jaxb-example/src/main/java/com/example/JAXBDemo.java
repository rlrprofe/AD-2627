package com.example;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import java.io.File;
import java.util.Comparator;

/**
 * Demostración de JAXB (Jakarta):
 * - Unmarshal: XML -> objetos (Centro, Alumno)
 * - Operaciones en memoria (añadir y ordenar)
 * - Marshal: objetos -> XML formateado
 */
public class JAXBDemo {

    public static void main(String[] args) {
        try {
            // 1) Crear un contexto JAXB con las clases involucradas
            //    El contexto analiza las anotaciones y prepara el mapeo XML <-> Java
            JAXBContext ctx = JAXBContext.newInstance(Centro.class, Alumno.class);

            // 2) Unmarshaller: convierte XML a objetos Java
            Unmarshaller um = ctx.createUnmarshaller();

            // Cargar XML. Si lo tienes en src/main/resources, puedes usar getResourceAsStream.
            Centro centro = (Centro) um.unmarshal(new File("resources/centro.xml"));

            // 3) Mostrar los alumnos cargados
            System.out.println("Alumnos leídos desde XML:");
            centro.getAlumnos().forEach(System.out::println);

            // 4) Modificar el modelo en memoria (añadir un alumno y ordenar por nota desc)
            centro.getAlumnos().add(new Alumno("A03", "2DAM", "María Torres", 21, 9.2));
            centro.getAlumnos().sort(Comparator.comparingDouble(Alumno::getNota).reversed());

            // 5) Marshaller: convierte objetos Java a XML
            Marshaller m = ctx.createMarshaller();
            // Propiedades de salida: legible e indicando codificación
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");

            // 5.1) Guardar a un nuevo archivo XML
            File salida = new File("resources/centro_modificado.xml");
            m.marshal(centro, salida);

            // 5.2) Mostrar también el XML por consola (útil para depuración)
            System.out.println("\nXML generado:");
            m.marshal(centro, System.out);

            System.out.println("\nArchivo escrito: " + salida.getAbsolutePath());

        } catch (Exception e) {
            // En un entorno real, conviene manejar JAXBException, etc. por separado
            e.printStackTrace();
        }
    }
}
