package com.example.xml;
import jakarta.xml.bind.annotation.*;

@XmlRootElement(name = "alumno")
@XmlAccessorType(XmlAccessType.FIELD)
public class Alumno {
    @XmlAttribute private String id;
    @XmlElement private String nombre;
    @XmlElement private int edad;

    public Alumno() {}
    public Alumno(String id, String nombre, int edad) {
        this.id = id; this.nombre = nombre; this.edad = edad;
    }
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    @Override public String toString() {
        return id + " - " + nombre + " - " + edad;
    }
}
