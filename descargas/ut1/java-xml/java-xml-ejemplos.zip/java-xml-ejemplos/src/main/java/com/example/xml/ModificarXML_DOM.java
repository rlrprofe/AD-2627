package com.example.xml;
import java.io.File;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class ModificarXML_DOM {
    public static void main(String[] args) throws Exception {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.parse(new File("data/alumnos.xml"));
        Element alumno = (Element) doc.getElementsByTagName("alumno").item(0);
        alumno.getElementsByTagName("edad").item(0).setTextContent("21");
        alumno.setAttribute("revisado", "true");

        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.transform(new DOMSource(doc),
                new StreamResult(new File("data/alumnos_modificado.xml")));
    }
}
