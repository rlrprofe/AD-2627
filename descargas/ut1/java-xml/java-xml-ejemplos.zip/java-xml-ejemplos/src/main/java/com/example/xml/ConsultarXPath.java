package com.example.xml;
import java.io.File;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.w3c.dom.*;

public class ConsultarXPath {
    public static void main(String[] args) throws Exception {
        Document doc = DocumentBuilderFactory.newInstance()
                .newDocumentBuilder().parse(new File("data/alumnos.xml"));
        XPath xpath = XPathFactory.newInstance().newXPath();

        NodeList mayores = (NodeList) xpath.evaluate(
                "//alumno[edad > 20]", doc, XPathConstants.NODESET);

        for (int i = 0; i < mayores.getLength(); i++) {
            Element alumno = (Element) mayores.item(i);
            System.out.println(alumno.getElementsByTagName("nombre")
                    .item(0).getTextContent());
        }
    }
}
