package com.example.xml.app;

import com.example.xml.repository.AlumnoXmlRepository;
import java.nio.file.Path;
import javax.xml.xpath.*;
import org.w3c.dom.*;

/** Ejemplo 4: XPath selecciona nodos sin recorrer manualmente todo el árbol. */
public class ConsultarXPath {
    public static void main(String[] args) {
        try {
            Document documento = new AlumnoXmlRepository().leer(Path.of("data/alumnos.xml"));
            XPath xpath = XPathFactory.newInstance().newXPath();
            // Selecciona los elementos alumno cuyo subelemento edad es mayor que 20.
            NodeList mayores = (NodeList) xpath.evaluate(
                    "//alumno[edad > 20]", documento, XPathConstants.NODESET);
            for (int i = 0; i < mayores.getLength(); i++) {
                Element alumno = (Element) mayores.item(i);
                System.out.println(alumno.getElementsByTagName("nombre").item(0).getTextContent());
            }
        } catch (Exception e) {
            System.err.println("Error al consultar XPath: " + e.getMessage());
        }
    }
}
