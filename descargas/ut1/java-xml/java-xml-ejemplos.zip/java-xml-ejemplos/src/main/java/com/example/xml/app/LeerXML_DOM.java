package com.example.xml.app;

import com.example.xml.repository.AlumnoXmlRepository;
import java.nio.file.Path;
import org.w3c.dom.*;

/** Ejemplo 1: DOM carga el XML completo en memoria como árbol de nodos. */
public class LeerXML_DOM {
    public static void main(String[] args) {
        try {
            Document documento = new AlumnoXmlRepository().leer(Path.of("data/alumnos.xml"));
            NodeList lista = documento.getElementsByTagName("alumno");
            for (int i = 0; i < lista.getLength(); i++) {
                Element alumno = (Element) lista.item(i);
                String id = alumno.getAttribute("id");
                String nombre = alumno.getElementsByTagName("nombre").item(0).getTextContent();
                int edad = Integer.parseInt(alumno.getElementsByTagName("edad").item(0).getTextContent());
                System.out.printf("%s - %s - %d%n", id, nombre, edad);
            }
        } catch (Exception e) {
            System.err.println("No se pudo leer el XML: " + e.getMessage());
        }
    }
}
