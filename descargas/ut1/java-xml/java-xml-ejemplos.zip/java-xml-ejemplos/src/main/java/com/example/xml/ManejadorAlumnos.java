package com.example.xml;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class ManejadorAlumnos extends DefaultHandler {
    private StringBuilder texto = new StringBuilder();

    @Override
    public void startElement(String uri, String localName, String qName,
                             Attributes attributes) {
        texto.setLength(0);
        if ("alumno".equals(qName)) {
            System.out.println("Alumno " + attributes.getValue("id"));
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) {
        texto.append(ch, start, length);
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        String valor = texto.toString().trim();
        if ("nombre".equals(qName) || "edad".equals(qName)) {
            System.out.println("  " + qName + ": " + valor);
        }
    }
}
