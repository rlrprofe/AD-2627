package com.example.xml.app;

import com.example.xml.model.Alumno;
import jakarta.xml.bind.*;
import java.nio.file.Files;
import java.nio.file.Path;

/** Ejemplo 5: JAXB convierte objetos Java a XML y viceversa. */
public class JaxbEjemplo {
    public static void main(String[] args) {
        Path ruta = Path.of("data/alumno_jaxb.xml");
        try {
            JAXBContext contexto = JAXBContext.newInstance(Alumno.class);
            Alumno original = new Alumno("A010", "Lucía", 21);
            Marshaller escritor = contexto.createMarshaller();
            escritor.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            escritor.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            // marshal: objeto Java -> documento XML.
            try (var salida = Files.newOutputStream(ruta)) {
                escritor.marshal(original, salida);
            }
            Unmarshaller lector = contexto.createUnmarshaller();
            // unmarshal: documento XML -> objeto Java.
            try (var entrada = Files.newInputStream(ruta)) {
                Alumno recuperado = (Alumno) lector.unmarshal(entrada);
                System.out.println(recuperado);
            }
        } catch (Exception e) {
            System.err.println("Error al serializar o deserializar con JAXB: " + e.getMessage());
        }
    }
}
