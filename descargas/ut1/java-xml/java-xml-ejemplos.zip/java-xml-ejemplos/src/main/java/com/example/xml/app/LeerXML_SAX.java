package com.example.xml.app;

import com.example.xml.config.XmlConfig;
import java.nio.file.Files;
import java.nio.file.Path;

/** Ejemplo 3: SAX procesa el XML por eventos, sin cargar todo el árbol. */
public class LeerXML_SAX {
    public static void main(String[] args) {
        try (var entrada = Files.newInputStream(Path.of("data/alumnos.xml"))) {
            var analizador = XmlConfig.saxFactory().newSAXParser();
            analizador.parse(entrada, new ManejadorAlumnos());
        } catch (Exception e) {
            System.err.println("No se pudo procesar el XML con SAX: " + e.getMessage());
        }
    }
}
