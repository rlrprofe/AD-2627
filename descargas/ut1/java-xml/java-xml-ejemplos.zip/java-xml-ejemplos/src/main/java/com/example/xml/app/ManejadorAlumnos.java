package com.example.xml.app;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Manejador SAX: recibe eventos de inicio, texto y fin de cada etiqueta.
 * characters() puede llamarse varias veces para un mismo elemento.
 */
public class ManejadorAlumnos extends DefaultHandler {
    private final StringBuilder texto = new StringBuilder();

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        texto.setLength(0);
        if ("alumno".equals(qName)) {
            System.out.println("Alumno " + attributes.getValue("id"));
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) {
        // Acumulamos fragmentos: no debemos asumir una sola llamada por etiqueta.
        texto.append(ch, start, length);
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        if ("nombre".equals(qName) || "edad".equals(qName)) {
            System.out.println("  " + qName + ": " + texto.toString().trim());
        }
        texto.setLength(0);
    }
}
