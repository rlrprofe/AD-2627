package com.example.xml;
import java.io.File;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class LeerXML_DOM {
    public static void main(String[] args) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new File("data/alumnos.xml"));
        doc.getDocumentElement().normalize();

        NodeList lista = doc.getElementsByTagName("alumno");
        for (int i = 0; i < lista.getLength(); i++) {
            Node nodo = lista.item(i);
            if (nodo.getNodeType() != Node.ELEMENT_NODE) continue;
            Element alumno = (Element) nodo;
            String id = alumno.getAttribute("id");
            String nombre = alumno.getElementsByTagName("nombre").item(0).getTextContent();
            int edad = Integer.parseInt(alumno.getElementsByTagName("edad").item(0).getTextContent());
            System.out.printf("%s - %s - %d%n", id, nombre, edad);
        }
    }
}
