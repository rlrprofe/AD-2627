package com.example.xml;
import java.io.File;
import javax.xml.parsers.*;

public class LeerXML_SAX {
    public static void main(String[] args) throws Exception {
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(new File("data/alumnos.xml"), new ManejadorAlumnos());
    }
}
