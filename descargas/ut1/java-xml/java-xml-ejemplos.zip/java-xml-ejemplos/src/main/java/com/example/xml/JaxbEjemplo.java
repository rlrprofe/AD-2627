package com.example.xml;
import java.io.File;
import jakarta.xml.bind.*;

public class JaxbEjemplo {
    public static void main(String[] args) throws Exception {
        JAXBContext context = JAXBContext.newInstance(Alumno.class);

        Alumno original = new Alumno("A010", "Lucía", 21);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.marshal(original, new File("data/alumno_jaxb.xml"));

        Unmarshaller unmarshaller = context.createUnmarshaller();
        Alumno recuperado = (Alumno) unmarshaller.unmarshal(
                new File("data/alumno_jaxb.xml"));
        System.out.println(recuperado);
    }
}
