package com.example.xml.app;

import com.example.xml.repository.AlumnoXmlRepository;
import java.nio.file.Path;
import org.w3c.dom.*;

/** Ejemplo 2: modifica el árbol DOM y lo guarda en un fichero distinto. */
public class ModificarXML_DOM {
    public static void main(String[] args) {
        try {
            AlumnoXmlRepository repositorio = new AlumnoXmlRepository();
            Document documento = repositorio.leer(Path.of("data/alumnos.xml"));
            Element alumno = (Element) documento.getElementsByTagName("alumno").item(0);
            if (alumno == null) {
                System.err.println("El documento no contiene alumnos.");
                return;
            }
            // setTextContent cambia el valor de un elemento; setAttribute añade un atributo.
            alumno.getElementsByTagName("edad").item(0).setTextContent("21");
            alumno.setAttribute("revisado", "true");
            repositorio.guardar(documento, Path.of("data/alumnos_modificado.xml"));
            System.out.println("Guardado data/alumnos_modificado.xml");
        } catch (Exception e) {
            System.err.println("No se pudo modificar el XML: " + e.getMessage());
        }
    }
}
