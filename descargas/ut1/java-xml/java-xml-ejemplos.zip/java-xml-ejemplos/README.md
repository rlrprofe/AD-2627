# Ejemplos XML con Java — 2.º DAM

Proyecto Maven para **Java 21**. Abre esta carpeta (donde está `pom.xml`) en VS Code.

## Orden didáctico

| Paso | Archivo | Qué aprenderás | ¿Ejecutar? |
| --- | --- | --- | --- |
| 1 | `data/alumnos.xml` | Estructura del documento: raíz, elementos y atributos | No |
| 2 | `repository/AlumnoXmlRepository.java` y `config/XmlConfig.java` | `Path`, `Files`, `try-with-resources`, lectura DOM y protección XXE | No |
| 3 | `app/LeerXML_DOM.java` | Recorrer un árbol DOM, `NodeList` y `Element` | Sí |
| 4 | `app/ModificarXML_DOM.java` | Modificar elementos/atributos y guardar otro XML | Sí |
| 5 | `app/ManejadorAlumnos.java` | Eventos `startElement`, `characters` y `endElement` de SAX | No |
| 6 | `app/LeerXML_SAX.java` | Lectura por eventos con SAX | Sí |
| 7 | `app/ConsultarXPath.java` | Filtrar alumnos con una expresión XPath | Sí |
| 8 | `model/Alumno.java` | POJO y anotaciones JAXB (`@XmlRootElement`, `@XmlAttribute`, `@XmlElement`) | No |
| 9 | `app/JaxbEjemplo.java` | `Marshaller` y `Unmarshaller`: objetos ↔ XML | Sí |

**Importante:** ejecuta desde la carpeta raíz del proyecto, ya que `data/alumnos.xml` es una ruta relativa. El ejemplo DOM modificado escribe `data/alumnos_modificado.xml` y JAXB genera `data/alumno_jaxb.xml`; el original permanece intacto.

## Estructura

```text
src/main/java/com/example/xml/
├── model/Alumno.java
├── config/XmlConfig.java
├── repository/AlumnoXmlRepository.java
└── app/
    ├── LeerXML_DOM.java
    ├── ModificarXML_DOM.java
    ├── ManejadorAlumnos.java
    ├── LeerXML_SAX.java
    ├── ConsultarXPath.java
    └── JaxbEjemplo.java
data/alumnos.xml
pom.xml
```

## Buenas prácticas

- **Java 21 y Maven**: las dependencias JAXB se gestionan en `pom.xml`; DOM, SAX y XPath vienen con el JDK.
- **Separación de responsabilidades**: `model` representa datos, `config` crea parsers seguros, `repository` centraliza persistencia y `app` reúne las demostraciones.
- **Cierre de recursos**: `try-with-resources` para entradas y salidas.
- **XML seguro**: se prohíben DTD y entidades externas en los parsers DOM/SAX para evitar ataques XXE.
- **Codificación**: los XML generados indican UTF-8.
- **Errores**: los ejemplos muestran mensajes comprensibles en lugar de propagar `throws Exception` desde `main`.

## Preguntas para comprobar lo aprendido

1. ¿Qué diferencia existe entre DOM y SAX respecto al uso de memoria?
2. ¿Por qué `ManejadorAlumnos` acumula los caracteres en un `StringBuilder`?
3. ¿Qué devuelve la expresión `//alumno[edad > 20]`?
4. ¿Qué clases contienen la lógica de acceso a ficheros?
5. ¿Por qué JAXB necesita un constructor sin argumentos en `Alumno`?

Para compilar: `mvn clean compile`. Para ejecutar, usa el botón **Run** de cada clase `app` en VS Code.
