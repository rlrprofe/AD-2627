# Java XML - ejemplos

Proyecto Maven de apoyo al bloque **XML con Java** de Acceso a Datos (2.º DAM).

## Requisitos

- JDK 21
- Maven

DOM, SAX y XPath pertenecen a la JDK. El `pom.xml` añade Jakarta XML Binding para los ejemplos JAXB.

## Orden recomendado

1. `LeerXML_DOM.java`
2. `ModificarXML_DOM.java`
3. `ConsultarXPath.java`
4. `LeerXML_SAX.java` + `ManejadorAlumnos.java`
5. `JaxbEjemplo.java` + `Alumno.java`

Los ficheros XML se encuentran en `data/`.
