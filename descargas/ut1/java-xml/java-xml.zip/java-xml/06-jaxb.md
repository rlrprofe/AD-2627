# JAXB / Jakarta XML Binding

## 1. ¿Qué es binding?

El **binding** permite convertir automáticamente:

```text
XML ⇄ objetos Java
```

Sin recorrer manualmente nodos DOM ni gestionar eventos SAX.

Los dos procesos reciben nombres específicos:

```text
XML → Java     unmarshalling
Java → XML     marshalling
```

## 2. Jakarta en Java moderno

JAXB estaba incluido en versiones antiguas del JDK bajo `javax.xml.bind`.

Desde Java 11 ya no forma parte de la JDK. En proyectos actuales utilizaremos **Jakarta XML Binding**, con paquetes:

```java
jakarta.xml.bind
jakarta.xml.bind.annotation
```

No debemos mezclar `javax.xml.bind` y `jakarta.xml.bind` en un mismo proyecto.

## 3. Proyecto Maven con JDK 21

```xml
<properties>
    <maven.compiler.release>21</maven.compiler.release>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
</properties>
```

Dependencias:

```xml
<dependencies>
    <dependency>
        <groupId>jakarta.xml.bind</groupId>
        <artifactId>jakarta.xml.bind-api</artifactId>
        <version>4.0.2</version>
    </dependency>

    <dependency>
        <groupId>org.glassfish.jaxb</groupId>
        <artifactId>jaxb-runtime</artifactId>
        <version>4.0.5</version>
    </dependency>
</dependencies>
```

## 4. Modelo Java

```java
@XmlRootElement(name = "alumno")
@XmlAccessorType(XmlAccessType.FIELD)
public class Alumno {

    @XmlAttribute
    private String id;

    @XmlElement
    private String nombre;

    @XmlElement
    private int edad;

    public Alumno() {
    }

    public Alumno(
            String id,
            String nombre,
            int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }
}
```

## 5. Constructor vacío

Las clases que JAXB debe crear durante el unmarshalling necesitan un constructor sin argumentos:

```java
public Alumno() {
}
```

## 6. Anotaciones fundamentales

| Anotación | Uso |
|---|---|
| `@XmlRootElement` | elemento raíz |
| `@XmlElement` | subelemento |
| `@XmlAttribute` | atributo XML |
| `@XmlAccessorType` | estrategia de acceso |
| `@XmlElementWrapper` | contenedor de una colección |
| `@XmlType` | orden/configuración del tipo |
| `@XmlTransient` | excluir una propiedad |
| `@XmlValue` | texto directo de un elemento |

## 7. Marshalling: Java → XML

```java
JAXBContext context =
        JAXBContext.newInstance(
            Alumno.class
        );

Marshaller marshaller =
        context.createMarshaller();

marshaller.setProperty(
        Marshaller.JAXB_FORMATTED_OUTPUT,
        true
);

Alumno alumno =
        new Alumno(
            "A001",
            "Ana",
            20
        );

marshaller.marshal(
        alumno,
        new File("data/alumno.xml")
);
```

## 8. Resultado

```xml
<alumno id="A001">
    <nombre>Ana</nombre>
    <edad>20</edad>
</alumno>
```

## 9. Unmarshalling: XML → Java

```java
Unmarshaller unmarshaller =
        context.createUnmarshaller();

Alumno alumno =
        (Alumno) unmarshaller.unmarshal(
            new File("data/alumno.xml")
        );

System.out.println(
        alumno.getNombre()
);
```

## 10. Listas de objetos

Para representar:

```xml
<curso>
    <alumnos>
        <alumno>...</alumno>
        <alumno>...</alumno>
    </alumnos>
</curso>
```

podemos utilizar:

```java
@XmlElementWrapper(name = "alumnos")
@XmlElement(name = "alumno")
private List<Alumno> alumnos;
```

## 11. Flujo de trabajo

```text
1. Definir clases
2. Añadir anotaciones
3. Crear JAXBContext
4. Crear Marshaller o Unmarshaller
5. Convertir
```

## 12. Ventajas

- código compacto;
- trabajamos con objetos Java;
- muy legible;
- adecuado para modelos de dominio estables;
- facilita importación y exportación.

## 13. Limitaciones

- requiere modelar las clases;
- estructuras XML irregulares pueden complicar las anotaciones;
- consume memoria para los objetos creados;
- necesita dependencia externa en Java moderno.

## 14. Cuándo utilizarlo

JAXB resulta especialmente adecuado cuando el XML representa claramente entidades de nuestra aplicación:

```text
Curso
├── Alumno
├── Alumno
└── Alumno
```

Si solo queremos procesar secuencialmente millones de registros, SAX será más apropiado.
