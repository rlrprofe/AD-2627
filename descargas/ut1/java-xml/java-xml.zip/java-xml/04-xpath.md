# XPath: consultar un documento XML

## 1. ¿Qué es XPath?

XPath (**XML Path Language**) permite seleccionar partes de un documento XML mediante expresiones.

Podemos pensar en XPath como una combinación de:

```text
ruta + filtro
```

aplicada al árbol XML.

## 2. XML de ejemplo

```xml
<alumnos>
    <alumno id="A001">
        <nombre>Ana</nombre>
        <edad>20</edad>
    </alumno>

    <alumno id="A002">
        <nombre>Luis</nombre>
        <edad>22</edad>
    </alumno>
</alumnos>
```

## 3. Expresiones básicas

| XPath | Resultado |
|---|---|
| `/alumnos` | raíz `alumnos` |
| `//alumno` | todos los alumnos |
| `//nombre` | todos los nombres |
| `//alumno[1]` | primer alumno |
| `//alumno[@id='A002']` | alumno con ese id |
| `//alumno[edad > 20]` | alumnos mayores de 20 |
| `//alumno[nombre='Ana']` | alumnos llamados Ana |
| `//alumno/edad/text()` | texto de las edades |
| `count(//alumno)` | número de alumnos |

## 4. Símbolos importantes

```text
/       camino directo
//      búsqueda en descendientes
@       atributo
[...]   predicado o filtro
text()  contenido textual
```

## 5. XPath en Java

Clases principales:

```java
javax.xml.xpath.XPathFactory
javax.xml.xpath.XPath
javax.xml.xpath.XPathConstants
```

## 6. Crear XPath

```java
XPathFactory factory =
        XPathFactory.newInstance();

XPath xpath =
        factory.newXPath();
```

## 7. Obtener un texto

```java
String nombre =
        xpath.evaluate(
            "//alumno[@id='A002']/nombre/text()",
            doc
        );

System.out.println(nombre);
```

## 8. Obtener varios nodos

```java
NodeList alumnos =
        (NodeList) xpath.evaluate(
            "//alumno[edad > 20]",
            doc,
            XPathConstants.NODESET
        );
```

## 9. Contar nodos

```java
Double cantidad =
        (Double) xpath.evaluate(
            "count(//alumno)",
            doc,
            XPathConstants.NUMBER
        );
```

## 10. DOM frente a XPath

Sin XPath podemos recorrer manualmente el árbol:

```text
buscar alumnos
→ recorrer
→ leer edad
→ comparar
→ seleccionar
```

Con XPath expresamos directamente:

```xpath
//alumno[edad > 20]
```

## 11. Cuándo utilizar XPath

XPath resulta especialmente útil cuando ya tenemos un DOM cargado y necesitamos:

- localizar elementos;
- filtrar por atributos;
- filtrar por valores;
- seleccionar posiciones;
- obtener texto;
- contar nodos.

No sustituye al parser: normalmente XPath consulta un documento que previamente hemos cargado con DOM.
