# SAX: lectura XML mediante eventos

## 1. ¿Qué es SAX?

SAX (**Simple API for XML**) procesa el XML de forma secuencial.

No crea un árbol completo en memoria.

```text
XML
 ↓
parser SAX
 ↓
evento
 ↓
evento
 ↓
evento
 ↓
fin
```

## 2. DOM frente a SAX

| Característica | DOM | SAX |
|---|---|---|
| Modelo | árbol | eventos |
| Memoria | documento completo | fragmento actual |
| Acceso | aleatorio | secuencial |
| Modificación | sí | no |
| XML grandes | menos adecuado | muy adecuado |
| Complejidad | navegación directa | estado + eventos |

## 3. Clases principales

```java
SAXParserFactory
SAXParser
DefaultHandler
Attributes
```

Los parsers se crean desde `javax.xml.parsers` y los eventos pertenecen al API SAX.

## 4. Crear el parser

```java
SAXParserFactory factory =
        SAXParserFactory.newInstance();

SAXParser parser =
        factory.newSAXParser();
```

## 5. El manejador

Creamos una clase que hereda de:

```java
DefaultHandler
```

y sobrescribimos los eventos que necesitamos.

## 6. Eventos principales

```java
startDocument()
startElement(...)
characters(...)
endElement(...)
endDocument()
```

El orden sigue la lectura del XML.

## 7. `startElement()`

```java
@Override
public void startElement(
        String uri,
        String localName,
        String qName,
        Attributes attributes) {

    System.out.println(
        "Inicio: " + qName
    );
}
```

Podemos leer atributos:

```java
String id =
        attributes.getValue("id");
```

## 8. `characters()`

```java
@Override
public void characters(
        char[] ch,
        int start,
        int length) {

    String texto =
        new String(
            ch,
            start,
            length
        );
}
```

!!! warning
    SAX puede llamar a `characters()` varias veces para un mismo contenido. No debemos asumir que todo el texto llegará en una única llamada.

## 9. `endElement()`

```java
@Override
public void endElement(
        String uri,
        String localName,
        String qName) {

    System.out.println(
        "Fin: " + qName
    );
}
```

## 10. Construir objetos durante la lectura

Un patrón habitual consiste en mantener:

```java
private Alumno alumnoActual;
private StringBuilder texto;
private List<Alumno> alumnos;
```

Al abrir `<alumno>` creamos el objeto.

Al leer `<nombre>` o `<edad>` guardamos los valores.

Al cerrar `</alumno>` añadimos el objeto a la lista.

## 11. Ejecutar el parser

```java
ManejadorAlumnos handler =
        new ManejadorAlumnos();

parser.parse(
        new File("data/alumnos.xml"),
        handler
);
```

## 12. Ventajas

- bajo consumo de memoria;
- procesamiento secuencial;
- adecuado para XML grandes;
- útil para importaciones, logs y flujos.

## 13. Limitaciones

- no podemos volver atrás;
- no existe un árbol navegable;
- no permite modificar directamente el XML;
- el código puede ser más complejo cuando hay mucho estado.

## 14. Cuándo utilizar SAX

SAX es una buena elección cuando:

```text
XML grande
+
solo lectura
+
procesamiento secuencial
```

Si necesitamos modificar el documento, DOM suele resultar más apropiado.
