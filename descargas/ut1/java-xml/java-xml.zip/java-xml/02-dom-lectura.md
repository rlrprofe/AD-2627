# DOM: lectura y navegación

## 1. ¿Qué es DOM?

DOM (**Document Object Model**) carga el XML completo en memoria y lo representa como un árbol de objetos.

Las clases principales pertenecen a:

```java
org.w3c.dom
javax.xml.parsers
```

DOM forma parte de la JDK, por lo que no necesitamos añadir una dependencia Maven externa.

## 2. Flujo de lectura

```text
fichero XML
    │
    ▼
DocumentBuilderFactory
    │
    ▼
DocumentBuilder
    │ parse()
    ▼
Document
    │
    ▼
árbol DOM
```

## 3. Crear el parser

```java
DocumentBuilderFactory factory =
        DocumentBuilderFactory.newInstance();

DocumentBuilder builder =
        factory.newDocumentBuilder();
```

`DocumentBuilderFactory` crea y configura el parser.

`DocumentBuilder` realiza el análisis del XML.

## 4. Leer el fichero

```java
Document doc =
        builder.parse("data/alumnos.xml");
```

`parse()` lee el documento y construye el árbol DOM.

## 5. Normalizar

```java
doc.getDocumentElement().normalize();
```

La normalización ayuda a unificar la representación interna de los nodos de texto.

## 6. Obtener la raíz

```java
Element raiz =
        doc.getDocumentElement();

System.out.println(
        raiz.getTagName()
);
```

Resultado:

```text
alumnos
```

## 7. Buscar elementos

```java
NodeList lista =
        doc.getElementsByTagName("alumno");
```

`NodeList` contiene los nodos encontrados.

```java
System.out.println(lista.getLength());
```

## 8. Recorrer un NodeList

```java
for (int i = 0; i < lista.getLength(); i++) {

    Node nodo = lista.item(i);

    if (nodo.getNodeType()
            == Node.ELEMENT_NODE) {

        Element alumno =
                (Element) nodo;

        // ...
    }
}
```

La comprobación del tipo es importante porque un DOM puede contener nodos de distintos tipos.

## 9. Leer atributos

Para:

```xml
<alumno id="A001">
```

utilizamos:

```java
String id =
        alumno.getAttribute("id");
```

## 10. Leer subelementos

```java
String nombre =
        alumno
            .getElementsByTagName("nombre")
            .item(0)
            .getTextContent();

String edad =
        alumno
            .getElementsByTagName("edad")
            .item(0)
            .getTextContent();
```

## 11. Ejemplo completo

```java
DocumentBuilderFactory factory =
        DocumentBuilderFactory.newInstance();

DocumentBuilder builder =
        factory.newDocumentBuilder();

Document doc =
        builder.parse("data/alumnos.xml");

doc.getDocumentElement().normalize();

NodeList alumnos =
        doc.getElementsByTagName("alumno");

for (int i = 0;
     i < alumnos.getLength();
     i++) {

    Node nodo = alumnos.item(i);

    if (nodo.getNodeType()
            != Node.ELEMENT_NODE) {
        continue;
    }

    Element alumno =
            (Element) nodo;

    String id =
            alumno.getAttribute("id");

    String nombre =
            alumno
                .getElementsByTagName("nombre")
                .item(0)
                .getTextContent();

    int edad =
            Integer.parseInt(
                alumno
                    .getElementsByTagName("edad")
                    .item(0)
                    .getTextContent()
            );

    System.out.printf(
            "%s - %s - %d%n",
            id,
            nombre,
            edad
    );
}
```

## 12. Clases DOM fundamentales

| Clase | Función |
|---|---|
| `Document` | Representa todo el XML |
| `Element` | Representa una etiqueta |
| `Node` | Tipo general de nodo |
| `NodeList` | Colección de nodos |
| `DocumentBuilderFactory` | Configura el parser |
| `DocumentBuilder` | Construye el DOM |

## 13. Métodos frecuentes

| Método | Uso |
|---|---|
| `getDocumentElement()` | raíz |
| `getElementsByTagName()` | buscar elementos |
| `getAttribute()` | leer atributo |
| `getTextContent()` | leer texto |
| `getNodeType()` | conocer tipo de nodo |
| `getChildNodes()` | obtener hijos |
| `item(i)` | acceder a un nodo |
| `getLength()` | tamaño de `NodeList` |

## 14. Tipos de nodo

Algunos valores habituales de `getNodeType()`:

| Constante | Valor | Ejemplo |
|---|---:|---|
| `Node.ELEMENT_NODE` | 1 | `<alumno>` |
| `Node.ATTRIBUTE_NODE` | 2 | `id="A01"` |
| `Node.TEXT_NODE` | 3 | `Ana` |
| `Node.COMMENT_NODE` | 8 | `<!-- ... -->` |
| `Node.DOCUMENT_NODE` | 9 | documento completo |

## 15. Cuándo utilizar DOM

DOM resulta adecuado cuando:

- el fichero es pequeño o mediano;
- necesitamos navegar libremente;
- queremos modificar elementos o atributos;
- necesitamos crear nuevos nodos;
- vamos a guardar posteriormente los cambios.

Su principal coste es que mantiene el documento completo en memoria.
