# Comparativa y resumen

## 1. Tres formas principales de procesar XML

```text
DOM  → árbol
SAX  → eventos
JAXB → objetos
```

XPath complementa especialmente a DOM permitiendo realizar consultas.

## 2. Comparativa

| Criterio | DOM | SAX | JAXB |
|---|---|---|---|
| Modelo | árbol | eventos | objetos |
| Memoria | alta | baja | media |
| Acceso | aleatorio | secuencial | mediante objetos |
| Modificar XML | sí | no | indirectamente |
| Guardar XML | sí | no directamente | sí |
| XML grandes | menos adecuado | excelente | depende del modelo |
| Modelo de dominio | opcional | opcional | necesario |
| Curva inicial | media | media/alta | baja/media |

## 3. ¿Dónde encaja XPath?

XPath no sustituye a DOM.

Normalmente:

```text
XML
 ↓
DOM
 ↓
Document
 ↓
XPath
 ↓
nodos seleccionados
```

## 4. Elegir DOM

Utiliza DOM cuando:

- necesitas leer y modificar;
- quieres navegar libremente;
- el XML cabe razonablemente en memoria;
- necesitas XPath;
- quieres implementar CRUD sobre nodos.

## 5. Elegir SAX

Utiliza SAX cuando:

- el XML es grande;
- solo necesitas lectura;
- procesas los datos secuencialmente;
- quieres minimizar memoria.

## 6. Elegir JAXB

Utiliza JAXB cuando:

- tienes clases de dominio claras;
- quieres XML ⇄ objetos;
- prefieres trabajar con objetos en lugar de nodos;
- la estructura del XML es estable.

## 7. Clases que debes reconocer

### DOM

```text
DocumentBuilderFactory
DocumentBuilder
Document
Node
Element
NodeList
Transformer
```

### SAX

```text
SAXParserFactory
SAXParser
DefaultHandler
Attributes
```

### XPath

```text
XPathFactory
XPath
XPathConstants
```

### JAXB

```text
JAXBContext
Marshaller
Unmarshaller
@XmlRootElement
@XmlElement
@XmlAttribute
```

## 8. Operaciones esenciales DOM

```java
doc.getDocumentElement();
doc.getElementsByTagName("alumno");
element.getAttribute("id");
element.getTextContent();
element.setTextContent("...");
element.setAttribute("...", "...");
doc.createElement("...");
parent.appendChild(...);
parent.removeChild(...);
```

## 9. Operaciones esenciales SAX

```java
startDocument()
startElement(...)
characters(...)
endElement(...)
endDocument()
```

## 10. Operaciones esenciales JAXB

```text
marshal   → Java → XML
unmarshal → XML → Java
```

## 11. Preguntas de repaso

1. ¿Qué diferencia existe entre un XML bien formado y uno válido?
2. ¿Qué representa `Document` en DOM?
3. ¿Para qué sirve `DocumentBuilderFactory`?
4. ¿Qué diferencia existe entre `Node` y `Element`?
5. ¿Cómo se obtiene un atributo con DOM?
6. ¿Qué clase permite guardar un DOM en disco?
7. ¿Qué ventaja ofrece XPath frente a recorrer manualmente el árbol?
8. ¿Por qué SAX consume menos memoria que DOM?
9. ¿Qué evento SAX se produce al encontrar una etiqueta de apertura?
10. ¿Por qué `characters()` requiere especial cuidado?
11. ¿Qué significan marshalling y unmarshalling?
12. ¿Por qué JAXB necesita una dependencia externa en Java 21?
13. ¿Cuándo elegirías DOM en lugar de SAX?
14. ¿Cuándo elegirías JAXB?

## 12. Regla rápida

```text
¿Necesito modificar/navegar? → DOM

¿XML muy grande y solo lectura? → SAX

¿Quiero trabajar con objetos? → JAXB

¿Quiero buscar/filtrar un DOM? → XPath
```
