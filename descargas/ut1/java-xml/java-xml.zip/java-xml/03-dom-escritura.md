# DOM: modificar y guardar XML

## 1. DOM no es solo lectura

Una vez cargado el árbol podemos modificarlo:

```text
XML
 ↓ parse()
Document
 ↓ modificar
Document modificado
 ↓ Transformer
XML
```

## 2. Modificar el texto de un elemento

```java
Element anio =
        (Element) libro
            .getElementsByTagName("anio")
            .item(0);

anio.setTextContent("2026");
```

## 3. Modificar un atributo

```java
libro.setAttribute(
        "edicion",
        "2"
);
```

Si el atributo no existe, `setAttribute()` lo crea.

## 4. Crear un elemento

```java
Element libroNuevo =
        doc.createElement("libro");
```

## 5. Crear un atributo

```java
libroNuevo.setAttribute(
        "id",
        "L003"
);
```

## 6. Crear subelementos

```java
Element titulo =
        doc.createElement("titulo");

titulo.setTextContent(
        "Clean Code"
);

libroNuevo.appendChild(titulo);
```

Podemos repetir el proceso para autor, año, editorial, etc.

## 7. Añadir el nuevo nodo al árbol

```java
Element raiz =
        doc.getDocumentElement();

raiz.appendChild(libroNuevo);
```

Hasta este momento hemos modificado **el DOM en memoria**, no el fichero original.

## 8. Eliminar un elemento

```java
Node padre =
        libro.getParentNode();

padre.removeChild(libro);
```

## 9. Guardar mediante Transformer

Las clases principales son:

```java
TransformerFactory
Transformer
DOMSource
StreamResult
```

## 10. Crear el Transformer

```java
TransformerFactory factory =
        TransformerFactory.newInstance();

Transformer transformer =
        factory.newTransformer();
```

## 11. Configurar una salida legible

```java
transformer.setOutputProperty(
        OutputKeys.INDENT,
        "yes"
);

transformer.setOutputProperty(
        OutputKeys.ENCODING,
        "UTF-8"
);
```

## 12. Escribir el documento

```java
DOMSource source =
        new DOMSource(doc);

StreamResult result =
        new StreamResult(
            new File(
                "data/biblioteca_modificada.xml"
            )
        );

transformer.transform(
        source,
        result
);
```

## 13. CRUD con DOM

DOM permite implementar las cuatro operaciones:

| CRUD | DOM |
|---|---|
| Create | `createElement()`, `appendChild()` |
| Read | `getElementsByTagName()`, `getTextContent()` |
| Update | `setTextContent()`, `setAttribute()` |
| Delete | `removeChild()` |

## 14. Diferencia importante

Modificar:

```java
doc
```

no modifica automáticamente:

```text
biblioteca.xml
```

Necesitamos ejecutar posteriormente el `Transformer`.

## 15. Idea clave

DOM trabaja en dos fases:

```text
1. Manipular árbol en memoria
2. Persistir árbol en disco
```

Esto lo diferencia claramente de SAX, que no mantiene un árbol editable.
