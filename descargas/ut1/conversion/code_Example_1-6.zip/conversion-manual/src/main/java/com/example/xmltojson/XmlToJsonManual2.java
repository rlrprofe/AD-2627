package com.example.xmltojson;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Conversión MANUAL de XML → JSON usando XPath. (DOM + XPath)
 *
 * En este ejemplo:
 *  - Leemos el XML con DOM.
 *  - Usamos XPath para seleccionar directamente los nodos y valores deseados.
 *  - Creamos una estructura intermedia List<Map<String,Object>>.
 *  - Convertimos esa estructura a JSON con Gson.
 */
public class XmlToJsonManual2 {

    public static void main(String[] args) {
        File xmlFile = new File("resources/clientes.xml");
        Path outDir = Paths.get("salida");
        Path outJson = outDir.resolve("clientes_xpath.json");

        try {
            // --------------------------------------------------------------
            // 1) Cargar el XML con DOM (solo una vez)
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            Document doc = dbf.newDocumentBuilder().parse(xmlFile);
            doc.getDocumentElement().normalize();

            System.out.println(" XML cargado: " + xmlFile.getAbsolutePath());

            // --------------------------------------------------------------
            // 2) Crear el evaluador XPath
            // --------------------------------------------------------------
            XPath xp = XPathFactory.newInstance().newXPath();

            // Expresión para seleccionar todos los nodos <cliente>
            NodeList clientes = (NodeList) xp.evaluate("//cliente", doc, XPathConstants.NODESET);

            // Lista de salida (cada cliente se guarda como un mapa clave–valor)
            List<Map<String, Object>> lista = new ArrayList<>();

            // --------------------------------------------------------------
            // 3) Recorrer cada nodo <cliente>
            // --------------------------------------------------------------
            for (int i = 0; i < clientes.getLength(); i++) {
                Element c = (Element) clientes.item(i);
                Map<String, Object> cliente = new LinkedHashMap<>();

                // Atributo id
                String id = c.getAttribute("id");
                cliente.put("id", id);

                // Obtener nombre mediante XPath relativa al nodo actual
                String nombre = (String) xp.evaluate("nombre/text()", c, XPathConstants.STRING);
                cliente.put("nombre", nombre);

                // Obtener edad mediante XPath
                Double edad = (Double) xp.evaluate("number(edad)", c, XPathConstants.NUMBER);
                cliente.put("edad", edad.intValue());

                lista.add(cliente);
            }

            // --------------------------------------------------------------
            // 4) Serializar a JSON
            // --------------------------------------------------------------
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json = gson.toJson(lista);

            // Crear carpeta y escribir el fichero
            if (Files.notExists(outDir)) {
                Files.createDirectories(outDir);
            }
            Files.writeString(outJson, json);

            System.out.println(" JSON generado: " + outJson.toAbsolutePath());
            System.out.println(json);

        } catch (ParserConfigurationException e) {
            System.err.println(" Error configurando parser DOM: " + e.getMessage());
        } catch (SAXException e) {
            System.err.println(" XML mal formado: " + e.getMessage());
        } catch (IOException e) {
            System.err.println(" Error de lectura o escritura: " + e.getMessage());
        } catch (XPathExpressionException e) {
            System.err.println(" Error en expresión XPath: " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}

/*
 Por qué ArrayList en la lista principal

    -La lista List<Map<String,Object>> lista = new ArrayList<>(); contiene varios objetos del mismo tipo (clientes).
    -En JSON, esto equivale a un array ([...]).
    -ArrayList es ideal para representar colecciones ordenadas y dinámicas, donde:
        el orden de inserción sí importa (primer cliente → primer objeto en el JSON),
        y los elementos pueden repetirse o cambiarse fácilmente.

    Ventaja práctica:
        Cuando Gson convierte una List a JSON, lo traduce automáticamente a un array JSON, respetando el orden de inserción.

 */