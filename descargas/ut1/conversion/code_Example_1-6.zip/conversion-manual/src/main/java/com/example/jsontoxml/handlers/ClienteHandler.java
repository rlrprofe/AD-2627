package com.example.jsontoxml.handlers;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.*;

/**
 * Manejador SAX para procesar nodos <cliente> y generar una lista
 * de mapas con los datos extraídos.
 *
 * Este manejador se encarga de capturar los eventos generados
 * por el analizador SAX: inicio de etiqueta, texto y fin de etiqueta.
 */
public class ClienteHandler extends DefaultHandler {

    // Lista donde se almacenarán los clientes
    private final List<Map<String, Object>> clientes;

    // Objeto temporal para el cliente que se está leyendo
    private Map<String, Object> clienteActual;

    // Buffer para acumular el texto entre etiquetas
    private StringBuilder texto = new StringBuilder();

    /**
     * Constructor que recibe la lista donde se almacenarán los datos.
     */
    public ClienteHandler(List<Map<String, Object>> clientes) {
        this.clientes = clientes;
    }

    // --------------------------------------------------------------
    // Evento: inicio de una etiqueta
    // --------------------------------------------------------------
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attrs)
            throws SAXException {

        texto.setLength(0); // limpiar el buffer antes de empezar una etiqueta

        if ("cliente".equals(qName)) {
            // Nuevo cliente encontrado → crear mapa para sus datos
            clienteActual = new LinkedHashMap<>();
            String id = attrs.getValue("id"); // atributo id
            if (id != null) {
                clienteActual.put("id", id);
            }
        }
    }

    // --------------------------------------------------------------
    // Evento: contenido de texto dentro de una etiqueta
    // --------------------------------------------------------------
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        texto.append(ch, start, length);
    }

    // --------------------------------------------------------------
    // Evento: cierre de una etiqueta
    // --------------------------------------------------------------
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        String contenido = texto.toString().trim();

        if (clienteActual != null) {
            switch (qName) {
                case "nombre":
                    clienteActual.put("nombre", contenido);
                    break;

                case "edad":
                    // Intentar convertir a número si es posible
                    try {
                        clienteActual.put("edad", Integer.parseInt(contenido));
                    } catch (NumberFormatException e) {
                        clienteActual.put("edad", null);
                    }
                    break;

                case "cliente":
                    // Fin del cliente actual → añadirlo a la lista
                    clientes.add(clienteActual);
                    clienteActual = null;
                    break;
            }
        }

        texto.setLength(0); // limpiar el buffer tras cerrar una etiqueta
    }
}