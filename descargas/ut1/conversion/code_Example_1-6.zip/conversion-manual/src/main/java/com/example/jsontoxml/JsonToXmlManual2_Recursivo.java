package com.example.jsontoxml;


import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import java.io.FileReader;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.util.*;

/**
 * * Ojo este dificil es complejo porque estamos contando con una estructura de xml más compleja
 * 
 * Conversión MANUAL de JSON → XML (DOM + Gson) con soporte para:
 *   ▪ Objetos anidados (p.ej., "direccion": { "ciudad": "Madrid", "cp": "28001" })
 *   ▪ Listas/arrays      (p.ej., "telefonos": ["600111222","600333444"])
 *
 * Entrada admitida (igual que en JsonToXmlManual1):
 *   A) Array JSON directo:   [ { ... }, { ... } ]
 *   B) Objeto con clave:     { "clientes": [ { ... }, { ... } ] }
 *
 * Salida (esquema base):
 *   <clientes>
 *     <cliente id="C01">
 *       <nombre>...</nombre>
 *       <edad>...</edad>
 *       <direccion><ciudad>...</ciudad><cp>...</cp></direccion>
 *       <telefonos><telefono>...</telefono><telefono>...</telefono></telefonos>
 *     </cliente>
 *     ...
 *   </clientes>
 *
 * NOTA :
 *  - Esta versión es 100% MANUAL: construimos el DOM elemento a elemento.
 *  - Añadimos recursividad para mapear estructuras JSON reales (objetos/arrays).
 */


public class JsonToXmlManual2_Recursivo {
    public static void main(String[] args) {
        // --------------------------------------------------------------
        // Rutas de entrada/salida 
        // --------------------------------------------------------------
        Path in = Path.of("resources/clientes.json");
        Path outDir = Path.of("salida");
        Path out = outDir.resolve("clientes_recursivo.xml");

        try {
            Files.createDirectories(outDir);

            // --------------------------------------------------------------
            // 1) Leer el JSON con Gson
            // --------------------------------------------------------------
            Gson gson = new Gson();
            JsonElement root = JsonParser.parseReader(new FileReader(in.toFile()));
            System.out.println("JSON cargado: " + in.toAbsolutePath());

            // --------------------------------------------------------------
            // 2) Normalizar a List<Map<String,Object>>
            // (igual que en JsonToXmlManual1, pero admitiendo anidados)
            // --------------------------------------------------------------
            List<Map<String, Object>> clientes = new ArrayList<>();

            if (root.isJsonArray()) {
                Type listType = new TypeToken<List<Map<String, Object>>>() {
                }.getType();
                clientes = gson.fromJson(root, listType);

            } else if (root.isJsonObject()) {
                JsonObject obj = root.getAsJsonObject();
                JsonElement arr = obj.get("clientes");
                if (arr != null && arr.isJsonArray()) {
                    Type listType = new TypeToken<List<Map<String, Object>>>() {
                    }.getType();
                    clientes = gson.fromJson(arr, listType);
                } else {
                    throw new IllegalArgumentException("El JSON no contiene un array 'clientes'.");
                }
            } else {
                throw new IllegalArgumentException(
                        "Formato JSON no soportado (se esperaba array u objeto con 'clientes').");
            }

            // --------------------------------------------------------------
            // 3) Construir el XML (DOM) de forma recursiva para anidados
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            Document doc = dbf.newDocumentBuilder().newDocument();

            // <clientes> raíz
            Element raiz = doc.createElement("clientes");
            doc.appendChild(raiz);

            // Por cada cliente del array JSON…
            for (Map<String, Object> c : clientes) {
                Element eCliente = doc.createElement("cliente");

                // Atributo id (si existe)
                Object idVal = c.get("id");
                if (idVal != null) {
                    eCliente.setAttribute("id", String.valueOf(idVal));
                }

                // Para el resto de campos, decidir si son primitivos / objeto / lista
                for (Map.Entry<String, Object> entry : c.entrySet()) {
                    String key = entry.getKey();
                    if ("id".equals(key))
                        continue; // ya tratado como atributo

                    Object value = entry.getValue();
                    appendRec(doc, eCliente, key, value); // ← recursividad
                }

                raiz.appendChild(eCliente);
            }

            // --------------------------------------------------------------
            // 4) Guardar el XML en disco (formateado y UTF-8)
            // --------------------------------------------------------------
            Transformer tf = TransformerFactory.newInstance().newTransformer();
            tf.setOutputProperty(OutputKeys.INDENT, "yes");
            tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

            tf.transform(new DOMSource(doc), new StreamResult(out.toFile()));
            System.out.println("XML (recursivo) generado: " + out.toAbsolutePath());

        } catch (Exception e) {
            System.err.println("Error JSON→XML (recursivo): " + e.getMessage());
        }
    }

   

    /**
     * Añade a 'parent' un hijo llamado 'name' en función del tipo de 'value':
     * ▪ String/Number/Boolean → <name>valor</name>
     * ▪ Map → <name>…subelementos…</name>
     * ▪ List → <name> <itemName>…</itemName> ... </name>
     *
     * Esta función es el corazón “recursivo” del mapeo.
     */
    @SuppressWarnings("unchecked")
    private static void appendRec(Document doc, Element parent, String name, Object value) {
        if (value == null) {
            // Política simple: omitimos nulos (si quieres, podrías emitir <name/>).
            return;
        }

        // Caso 1: primitivos → elemento simple con texto
        if (isPrimitive(value)) {
            Element child = doc.createElement(name);
            child.setTextContent(String.valueOf(value));
            parent.appendChild(child);
            return;
        }

        // Caso 2: objetos → crear un contenedor <name> y añadir sus hijos
        if (value instanceof Map) {
            Element container = doc.createElement(name);
            parent.appendChild(container);

            Map<String, Object> map = (Map<String, Object>) value;
            for (Map.Entry<String, Object> e : map.entrySet()) {
                appendRec(doc, container, e.getKey(), e.getValue());
            }
            return;
        }

        // Caso 3: listas → wrapper <name> y elementos <itemName> para cada entrada
        if (value instanceof List) {
            Element wrapper = doc.createElement(name);
            parent.appendChild(wrapper);

            String itemName = singularize(name); // telefonos → telefono, clientes → cliente (heurística simple)
            for (Object item : (List<?>) value) {
                appendRec(doc, wrapper, itemName, item);
            }
            return;
        }

        //  cualquier otro tipo lo escribimos como texto
        Element child = doc.createElement(name);
        child.setTextContent(String.valueOf(value));
        parent.appendChild(child);
    }

    /** ¿Es un valor primitivo para efectos de salida XML? */
    private static boolean isPrimitive(Object v) {
        return v instanceof String || v instanceof Number || v instanceof Boolean;
    }

    /**
     * Heurística MUY simple para singularizar nombres de lista:
     * "telefonos" → "telefono", "clientes" → "cliente".
     * (Si no acaba en 's', se deja tal cual.)
     */
    private static String singularize(String name) {
        return (name.endsWith("s") && name.length() > 1)
                ? name.substring(0, name.length() - 1)
                : name;
    }
}
