package com.example.xmltojson;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Conversión MANUAL de XML -> JSON (DOM)
 *
 * Pasos:
 *  1) Cargar el XML en DOM.
 *  2) Recorrer los nodos <cliente> y extraer sus datos.
 *  3) Volcar a una estructura intermedia (List<Map<String,Object>>).
 *  4) Serializar esa estructura a JSON con Gson (pretty printing).
 *  5) Guardar en disco la salida JSON.
 */
public class XmlToJsonManual1 {

    public static void main(String[] args) {
        // Rutas de E/S (puedes ajustarlas si lo prefieres)
        File xmlFile = new File("resources/clientes.xml");
        Path outDir = Paths.get("salida");
        Path outJson = outDir.resolve("clientes.json");

        try {
            // --------------------------------------------------------------
            // 1) Cargar el XML en memoria (DOM)
            //    - Usamos DocumentBuilderFactory sin namespaces
            //    - Normalizamos para evitar nodos de texto partidos
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);

            Document doc = dbf.newDocumentBuilder().parse(xmlFile);
            doc.getDocumentElement().normalize();

            System.out.println(" XML cargado: " + xmlFile.getAbsolutePath());

            // --------------------------------------------------------------
            // 2) Recorrer los nodos <cliente> y extraer valores
            //    - Opción A: DOM puro (getElementsByTagName)
            //    - Opción B: XPath (si quieres filtrar/consultar)
            //    Aquí usamos DOM para mantenerlo simple.
            // --------------------------------------------------------------
            NodeList listaClientes = doc.getElementsByTagName("cliente");

            // Estructura intermedia:
            // Una lista de mapas, cada mapa representa un "cliente"
            // con sus claves id, nombre, edad
            List<Map<String, Object>> salida = new ArrayList<>();

            for (int i = 0; i < listaClientes.getLength(); i++) {
                Element c = (Element) listaClientes.item(i);

                // Atributo id
                String id = c.getAttribute("id");

                // Hijos: <nombre> y <edad>
                String nombre = getTextContent(c, "nombre"); // helper abajo
                String edadStr = getTextContent(c, "edad");
                Integer edad = safeParseInt(edadStr); // convierte con seguridad

                // ----------------------------------------------------------
                // 3) Construir el objeto intermedio (Map<String,Object>)
                // ----------------------------------------------------------
                Map<String, Object> cliente = new LinkedHashMap<>();
                cliente.put("id", id);
                cliente.put("nombre", nombre);
                cliente.put("edad", edad);

                salida.add(cliente);
            }

            // --------------------------------------------------------------
            // 4) Serializar a JSON con Gson (formato legible)
            // --------------------------------------------------------------
            Gson gson = new GsonBuilder()
                    .setPrettyPrinting() // JSON con sangrías
                    .disableHtmlEscaping()
                    .create();

            String json = gson.toJson(salida);

            // --------------------------------------------------------------
            // 5) Guardar el JSON en disco
            //    - Creamos la carpeta "salida" si no existe
            // --------------------------------------------------------------
            if (Files.notExists(outDir)) {
                Files.createDirectories(outDir);
            }
            Files.writeString(outJson, json);

            System.out.println(" JSON generado: " + outJson.toAbsolutePath());
            System.out.println(json); // mostrar por consola (opcional)

        } catch (ParserConfigurationException e) {
            System.err.println(" Error configurando el parser DOM: " + e.getMessage());
        } catch (SAXException e) {
            System.err.println(" XML mal formado: " + e.getMessage());
        } catch (IOException e) {
            System.err.println(" Error de E/S (revisar ruta/permiso): " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }

    // --------------------------------------------------------------
    // Helpers
    // --------------------------------------------------------------

    /**
     * Devuelve el texto de la PRIMERA ocurrencia del hijo <tag> dentro de e.
     * Si no existe, devuelve cadena vacía.
     */
    private static String getTextContent(Element e, String tag) {
        Node n = e.getElementsByTagName(tag).item(0);
        return (n != null) ? n.getTextContent().trim() : "";
    }

    /**
     * Convierte string a Integer de forma segura.
     * Si no es numérico, devuelve null (evita NumberFormatException).
     */
    private static Integer safeParseInt(String s) {
        try {
            return (s == null || s.isBlank()) ? null : Integer.parseInt(s.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}

/*
 * Observaciones:
 * 
 ¿Por qué usamos un LinkedHashMap en lugar de un HashMap?
    -La razón está en el orden de los elementos:
        HashMap no mantiene el orden de inserción de las claves. Si metes id, nombre, edad, podrían aparecer luego en otro orden al generar el JSON.
        LinkedHashMap mantiene el orden en que se insertaron los elementos.
    -Esto es importante si quieres que el JSON resultante tenga siempre la misma estructura visual (primero id, luego nombre, etc.).
 */