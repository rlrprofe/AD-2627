package com.example.jsontoxml;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.util.*;

/**
 * Conversión MANUAL de JSON → XML (con DOM + Gson)
 *
 * Admite dos formatos de entrada:
 *  A) Array JSON:        [ {id, nombre, edad}, ... ]
 *  B) Objeto con array:  { "clientes": [ {id, nombre, edad}, ... ] }
 *
 * Pasos:
 *  1) Leer y parsear JSON con Gson.
 *  2) Normalizar a List<Map<String,Object>>.
 *  3) Construir DOM con la forma <clientes><cliente ...>...</cliente></clientes>.
 *  4) Guardar el XML con sangría en la carpeta "salida".
 */
public class JsonToXmlManual1 {

    public static void main(String[] args) {
        File jsonFile = new File("resources/clientes.json");
        Path outDir = Paths.get("salida");
        Path outXml = outDir.resolve("clientes_convertidos.xml");

        try {
            // --------------------------------------------------------------
            // 1) Leer JSON con Gson
            // --------------------------------------------------------------
            Gson gson = new Gson();
            JsonElement root = JsonParser.parseReader(new FileReader(jsonFile));
            System.out.println(" JSON cargado: " + jsonFile.getAbsolutePath());

            // --------------------------------------------------------------
            // 2) Normalizar a List<Map<String,Object>>
            //    - Si la raíz es un array: lo convertimos directamente.
            //    - Si la raíz es objeto: buscamos la clave "clientes".
            // --------------------------------------------------------------
            List<Map<String, Object>> clientes = new ArrayList<>();

            if (root.isJsonArray()) {
                Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
                clientes = gson.fromJson(root, listType);

            } else if (root.isJsonObject()) {
                JsonObject obj = root.getAsJsonObject();
                JsonElement arr = obj.get("clientes");
                if (arr != null && arr.isJsonArray()) {
                    Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
                    clientes = gson.fromJson(arr, listType);
                } else {
                    throw new IllegalArgumentException("El JSON no contiene un array 'clientes'.");
                }
            } else {
                throw new IllegalArgumentException("Formato JSON no soportado (se esperaba array u objeto con 'clientes').");
            }

            // --------------------------------------------------------------
            // 3) Construir el XML en memoria (DOM)
            //    <clientes>
            //      <cliente id="...">
            //        <nombre>...</nombre>
            //        <edad>...</edad>
            //      </cliente>
            //    </clientes>
            // --------------------------------------------------------------
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            Document doc = dbf.newDocumentBuilder().newDocument();

            Element raiz = doc.createElement("clientes");
            doc.appendChild(raiz);

            for (Map<String, Object> c : clientes) {
                // Creamos <cliente>
                Element eCliente = doc.createElement("cliente");

                // Atributo id (si está)
                Object idVal = c.get("id");
                if (idVal != null) {
                    eCliente.setAttribute("id", String.valueOf(idVal));
                }

                // Hijo <nombre>
                Object nomVal = c.get("nombre");
                if (nomVal != null) {
                    Element eNombre = doc.createElement("nombre");
                    eNombre.setTextContent(String.valueOf(nomVal));
                    eCliente.appendChild(eNombre);
                }

                // Hijo <edad> (acepta número o string)
                Object edadVal = c.get("edad");
                if (edadVal != null) {
                    Element eEdad = doc.createElement("edad");
                    eEdad.setTextContent(String.valueOf(edadVal));
                    eCliente.appendChild(eEdad);
                }

                // Si hubiera más campos, decide si son atributos o hijos:
                // por ejemplo, tratar "activo": true como <activo>true</activo>
                // o "ciudad": "Madrid" como atributo, según tu política.

                raiz.appendChild(eCliente);
            }

            // --------------------------------------------------------------
            // 4) Guardar el XML en disco con sangría
            // --------------------------------------------------------------
            if (Files.notExists(outDir)) {
                Files.createDirectories(outDir);
            }

            Transformer tf = TransformerFactory.newInstance().newTransformer();
            tf.setOutputProperty(OutputKeys.INDENT, "yes");
            tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

            tf.transform(new DOMSource(doc), new StreamResult(outXml.toFile()));

            System.out.println(" XML generado: " + outXml.toAbsolutePath());

        } catch (ParserConfigurationException e) {
            System.err.println(" Error configurando DOM: " + e.getMessage());
        } catch (IOException e) {
            System.err.println(" Error de E/S: " + e.getMessage());
        } catch (TransformerException e) {
            System.err.println(" Error transformando/guardando XML: " + e.getMessage());
        } catch (Exception e) {
            System.err.println(" Error inesperado: " + e.getMessage());
        }
    }
}
