package com.example.xmltojson;

import javax.xml.parsers.SAXParserFactory;

import com.example.xmltojson.handlers.ClienteHandler;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.InputStream;

import java.nio.file.*;
import java.util.*;   


/**
 * Conversión MANUAL de XML → JSON utilizando SAX (lectura por eventos) + Gson.
 *
 * ¿Qué hace este programa?
 *  1) Lee un fichero XML con la estructura:
 *     <clientes>
 *        <cliente id="C01">
 *           <nombre>Ana</nombre>
 *           <edad>20</edad>
 *        </cliente>
 *        ...
 *     </clientes>
 *  2) Usa SAX para recorrer el XML SIN cargarlo entero en memoria (ideal para ficheros grandes).
 *  3) Construye una estructura intermedia en memoria: List<Map<String,Object>> (una lista de clientes).
 *  4) Serializa esa lista a JSON legible utilizando Gson.
 *  5) Guarda el resultado en "salida/clientes_sax.json".
 *
 *  - SAX funciona por "eventos": cuando encuentra inicio/fin de etiqueta o texto, nos avisa.
 *  - Consumo de memoria mucho más bajo que DOM (no construye el árbol completo).
 *  - Perfecto para "leer y convertir" de forma eficiente.
 *

 */
public class XmlToJsonManual3 {
     public static void main(String[] args) {
        // --------------------------------------------------------------
        // 0) Definir rutas de entrada (XML) y salida (JSON)
        // --------------------------------------------------------------
        Path in = Path.of("resources/clientes.xml");
        Path outDir = Path.of("salida");
        Path out = outDir.resolve("clientes_sax.json");

        try {
            // Crear la carpeta de salida si no existe
            Files.createDirectories(outDir);

            // --------------------------------------------------------------
            // 1) Crear la lista donde el handler volcará los datos convertidos.
            //    Cada "cliente" será un Map<String,Object> con claves: id, nombre, edad.
            // --------------------------------------------------------------
            List<Map<String, Object>> clientes = new ArrayList<>();

            // --------------------------------------------------------------
            // 2) Configurar el analizador SAX
            //    - setNamespaceAware(false): no trabajamos con namespaces en este ejemplo.
            //    - (Opcional) Podríamos activar medidas anti-XXE si cargásemos desde red.
            // --------------------------------------------------------------
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(false);

            // Nuestro manejador personalizado: recibe la lista a rellenar
            ClienteHandler handler = new ClienteHandler(clientes);

            // --------------------------------------------------------------
            // 3) Ejecutar el parseo SAX: le pasamos el InputStream y el handler
            //    - El handler recibirá "eventos" y construirá la lista "clientes".
            // --------------------------------------------------------------
            try (InputStream input = Files.newInputStream(in)) {
                spf.newSAXParser().parse(input, handler);
            }

            // --------------------------------------------------------------
            // 4) Convertir la estructura intermedia a JSON legible (pretty)
            // --------------------------------------------------------------
            Gson gson = new GsonBuilder()
                    .setPrettyPrinting()   // JSON con sangrías
                    .disableHtmlEscaping() // evita escapar &, <, > innecesariamente
                    .create();

            String json = gson.toJson(clientes);

            // --------------------------------------------------------------
            // 5) Guardar el JSON en disco (UTF-8 por defecto en writeString)
            // --------------------------------------------------------------
            Files.writeString(out, json);

            System.out.println("XML leído y convertido correctamente con SAX.");
            System.out.println("Archivo JSON generado en: " + out.toAbsolutePath());

        } catch (Exception e) {
            // Errores típicos:
            // - Fichero XML no encontrado / sin permisos
            // - XML mal formado
            // - Problemas al crear el parser SAX
            System.err.println("Error durante la conversión (SAX → JSON): " + e.getMessage());
        }
    }
    
}

/*
 Observaciones didácticas:
 ▪ En DOM/XPath recorrías el árbol; aquí "escuchas" eventos:
    - startElement(): comienza una etiqueta → inicializas estructuras/lees atributos.
    - characters(): aparece texto → acumulas en un StringBuilder.
    - endElement(): cierra una etiqueta → decides qué hacer con el texto acumulado.
 ▪ La estructura intermedia List<Map<String,Object>> es la misma que en los ejemplos 1 y 2,
    por lo que el salto a Gson es inmediato y coherente.
*/