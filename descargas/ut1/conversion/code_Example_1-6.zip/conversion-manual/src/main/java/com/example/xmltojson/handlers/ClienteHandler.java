package com.example.xmltojson.handlers;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.*;


/**
 * Manejador SAX que procesa los eventos del parser y construye
 * una lista de clientes en memoria: List<Map<String, Object>>.
 *
 * ¿Cómo funciona SAX?
 *   • startElement(...)  → se llama al abrir una etiqueta (<cliente>, <nombre>, ...)
 *   • characters(...)    → se llama al leer texto dentro de una etiqueta
 *   • endElement(...)    → se llama al cerrar una etiqueta (</cliente>, </nombre>, ...)
 *
 * En este handler:
 *   - Cuando abre <cliente>, inicia un nuevo LinkedHashMap para ese cliente.
 *   - Cuando cierra <nombre> o <edad>, guarda el contenido en el mapa.
 *   - Cuando cierra </cliente>, añade el mapa a la lista principal.
 */

public class ClienteHandler extends DefaultHandler {

    // Lista acumulada de clientes (inyectada desde el main)
    private final List<Map<String, Object>> clientes;

    // Objeto temporal para el cliente que se está leyendo
    private Map<String, Object> clienteActual;

    // Buffer para acumular el texto (characters puede llegar fragmentado)
    private final StringBuilder texto = new StringBuilder();

    // Última etiqueta “abierta” (útil para depurar, no imprescindible)
    private String etiquetaActual;

    public ClienteHandler(List<Map<String, Object>> clientes) {
        this.clientes = clientes;
    }

    // Helper seguro para convertir String → Integer (o null si no es número)
    private static Integer safeParseInt(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        try {
            return Integer.parseInt(t);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // --------------------------------------------------------------
    // Evento: apertura de etiqueta <...>
    // --------------------------------------------------------------
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attrs)
            throws SAXException {
        etiquetaActual = qName;         // guardamos el nombre de etiqueta actual
        texto.setLength(0);             // limpiamos el buffer de texto

        if ("cliente".equals(qName)) {
            // Nuevo cliente → creamos un mapa ordenado para sus campos
            clienteActual = new LinkedHashMap<>();
            // Atributo id (p.ej., <cliente id="C01">)
            String id = attrs.getValue("id");
            if (id != null) {
                clienteActual.put("id", id);
            }
        }
    }

    // --------------------------------------------------------------
    // Evento: texto entre etiquetas
    //  - ¡OJO! Puede llegar en varios trozos. Por eso se acumula.
    // --------------------------------------------------------------
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        texto.append(ch, start, length);
    }

    // --------------------------------------------------------------
    // Evento: cierre de etiqueta </...>
    // --------------------------------------------------------------
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        String contenido = texto.toString().trim();

        if (clienteActual != null) {
            switch (qName) {
                case "nombre":
                    // Guardamos el texto tal cual (trim aplicado arriba)
                    clienteActual.put("nombre", contenido);
                    break;

                case "edad":
                    // Convertimos a número de forma segura (null si no es válido)
                    clienteActual.put("edad", safeParseInt(contenido));
                    break;

                case "cliente":
                    // Al cerrar </cliente>, añadimos el mapa a la lista principal
                    clientes.add(clienteActual);
                    clienteActual = null;
                    break;
            }
        }

        // Limpiar estado auxiliar
        etiquetaActual = null;
        texto.setLength(0);
    }
}