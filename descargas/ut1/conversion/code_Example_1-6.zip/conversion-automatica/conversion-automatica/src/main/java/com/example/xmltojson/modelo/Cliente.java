package com.example.xmltojson.modelo;

import jakarta.xml.bind.annotation.*;

/**
 * Modelo que representa una etiqueta <cliente> del XML.
 *
 * Relación con el XML:
 *   <cliente id="C01">
 *     <nombre>Ana</nombre>
 *     <edad>20</edad>
 *   </cliente>
 *
 * Anotaciones JAXB:
 *  - @XmlAccessorType(XmlAccessType.FIELD): JAXB accede directamente a los campos.
 *  - @XmlAttribute(name = "id"): mapea el atributo id del elemento <cliente>.
 *  - @XmlElement(name = "nombre") / @XmlElement(name = "edad"): mapean subelementos.
 *
 * Requisitos:
 *  - Constructor vacío (obligatorio para JAXB).
 *  - Getters/Setters para interoperar con otras librerías (Gson, frameworks…).
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class Cliente {

    @XmlAttribute(name = "id")
    private String id;

    @XmlElement(name = "nombre")
    private String nombre;

    @XmlElement(name = "edad")
    private Integer edad;

    public Cliente() { } // requerido por JAXB

    // Getters/Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Integer getEdad() { return edad; }
    public void setEdad(Integer edad) { this.edad = edad; }
}
