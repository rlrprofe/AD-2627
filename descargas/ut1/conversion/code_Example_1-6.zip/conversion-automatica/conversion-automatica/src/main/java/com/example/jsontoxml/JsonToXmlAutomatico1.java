package com.example.jsontoxml;

import com.example.jsontoxml.modelo.Cliente;
import com.example.jsontoxml.modelo.Clientes;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;

import java.io.FileReader;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.util.List;

/**
 * Conversión SEMI-AUTOMÁTICA de JSON → XML usando:
 *   1) Gson: JSON → objetos Java (List<Cliente> o Clientes)
 *   2) JAXB: objetos clase Java → XML (marshal)
 *
 * Estructuras de entrada admitidas:
 *   A) Array JSON directo:        [ { "id": "C01", "nombre": "Ana", "edad": 20 }, ... ]
 *   B) Objeto con array "clientes": { "clientes": [ {...}, {...} ] }
 */
public class JsonToXmlAutomatico1 {
 public static void main(String[] args) {
        // --------------------------------------------------------------
        // Definir rutas de entrada y salida
        // --------------------------------------------------------------
        Path in = Path.of("resources/clientes.json");
        Path outDir = Path.of("salida");
        Path out = outDir.resolve("clientes_binding.xml");

        try {
            // Crear carpeta "salida" si no existe
            Files.createDirectories(outDir);

            // --------------------------------------------------------------
            // 1) Leer JSON con Gson
            // --------------------------------------------------------------
            Gson gson = new Gson();
            var root = com.google.gson.JsonParser.parseReader(new FileReader(in.toFile()));

            // root contendrá la raíz del JSON (puede ser un array o un objeto)

            // --------------------------------------------------------------
            // 2) Normalizar el contenido a un objeto Clientes
            //    (la clase Clientes tiene una List<Cliente> lista)
            // --------------------------------------------------------------
            Clientes wrapper = new Clientes();

            if (root.isJsonArray()) {
                Type listType = new TypeToken<List<Cliente>>() {}.getType();
                List<Cliente> lista = gson.fromJson(root, listType);
                wrapper.setLista(lista);
            } else if (root.isJsonObject() && root.getAsJsonObject().has("clientes")) {
                wrapper = gson.fromJson(root, Clientes.class);
            } else {
                throw new IllegalArgumentException(
                    "Formato JSON no soportado. Se esperaba un array o un objeto con clave 'clientes'.");
            }

            // --------------------------------------------------------------
            // 3) JAXB: convertir objetos de clases Java → XML (marshal)
            // --------------------------------------------------------------
            JAXBContext ctx = JAXBContext.newInstance(Clientes.class);
            Marshaller m = ctx.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);// salida con sangrías
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");// codificación estándar

            // --------------------------------------------------------------
            // 4) Guardar el XML en disco
            // --------------------------------------------------------------
            try (var w = Files.newBufferedWriter(out)) {
                m.marshal(wrapper, w);
            }

            System.out.println("JSON leído con Gson y convertido a XML (JAXB) correctamente.");
            System.out.println("Archivo XML generado: " + out.toAbsolutePath());

        } catch (Exception e) {
            System.err.println("Error (JSON → JAXB → XML): " + e.getMessage());
        }
    }    
}
