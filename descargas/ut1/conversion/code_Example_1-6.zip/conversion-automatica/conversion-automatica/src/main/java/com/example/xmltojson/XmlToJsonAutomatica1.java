package com.example.xmltojson;

import com.example.xmltojson.modelo.Clientes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Conversión SEMI-AUTOMÁTICA de XML → JSON utilizando Binding (JAXB) + Gson.
 *
 * Idea clave:
 * 1) JAXB convierte el XML en objetos Java según las anotaciones de las clases
 * modelo.
 * 2) Gson serializa esos objetos a JSON legible.
 *
 * Estructura XML esperada:
*   <clientes>
*       <cliente id="C01">
*           <nombre>Ana</nombre>
*           <edad>20</edad>
*       </cliente>
*       ...
*   </clientes>
 *
 * Ventajas frente a DOM/SAX:
 * - No recorremos manualmente etiquetas: delegamos el mapeo a JAXB (binding).
 * - Código más corto y mantenible cuando el XML es estable y “mapeable” a  clases.
 */

public class XmlToJsonAutomatica1 {
    public static void main(String[] args) {
        // 0) Rutas
        Path in = Path.of("resources/clientes.xml");
        Path outDir = Path.of("salida");
        Path out = outDir.resolve("clientes_jaxb.json");

        try {
            Files.createDirectories(outDir);

            // 1) Preparar JAXB con la clase raíz anotada (@XmlRootElement)
            JAXBContext context = JAXBContext.newInstance(Clientes.class);

            // 2) Unmarshal: XML → Objetos Java
            Unmarshaller um = context.createUnmarshaller();
            Clientes objetosCliente = (Clientes) um.unmarshal(in.toFile());

            // 3) Gson: Objetos → JSON (pretty)
            Gson gson = new GsonBuilder()
                    .setPrettyPrinting()
                    .disableHtmlEscaping()
                    .create();

            // objetosCliente.getLista() es una List<Cliente>; Gson la convierte a un array
            // JSON
            String json = gson.toJson(objetosCliente.getLista());

            // 4) Guardar
            Files.writeString(out, json);

            System.out.println("XML leído con JAXB y convertido a JSON correctamente.");
            System.out.println("Archivo JSON generado en: " + out.toAbsolutePath());

        } catch (Exception e) {
            System.err.println("Error (JAXB → JSON): " + e.getMessage());
        }
    }
}
