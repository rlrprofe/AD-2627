package com.example.jsontoxml.modelo;



import jakarta.xml.bind.annotation.*;


/**
 * Clase modelo que representa a un <cliente> dentro del documento XML.
 *
 * Relación con el XML:
 * ----------------------------------------------------------
 *   <cliente id="C01">
 *       <nombre>Ana</nombre>
 *       <edad>20</edad>
 *   </cliente>
 * ----------------------------------------------------------
 *
 * Cada etiqueta <cliente> del XML se convertirá en un objeto Cliente.
 * 
 * Anotaciones JAXB utilizadas:
 *  - @XmlAccessorType(XmlAccessType.FIELD)
 *      Indica que JAXB accederá directamente a los atributos del campo.
 *
 *  - @XmlAttribute(name = "id")
 *      Mapea el atributo id del XML (<cliente id="C01">) al campo 'id'.
 *
 *  - @XmlElement(name = "nombre") y @XmlElement(name = "edad")
 *      Mapean las etiquetas hijas del XML a los campos correspondientes.
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
public class Cliente {

    @XmlAttribute(name = "id")
    private String id;

    @XmlElement(name = "nombre")
    private String nombre;

    @XmlElement(name = "edad")
    private Integer edad;

    public Cliente() {}  // requerido por JAXB

    // Getters y setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public Integer getEdad() { return edad; }
    public void setEdad(Integer edad) { this.edad = edad; }
}
