package com.example.jsontoxml.modelo;

/**
 * Clase raíz que representa al elemento <clientes> del documento XML.
 *
 * Estructura del XML asociada:
 * ----------------------------------------------------------
 *   <clientes>
 *      <cliente id="C01">...</cliente>
 *      <cliente id="C02">...</cliente>
 *   </clientes>
 * ----------------------------------------------------------
 *
 * El campo 'lista' contiene una colección de objetos Cliente,
 * cada uno correspondiente a una etiqueta <cliente> del XML.
 *
 * Anotaciones JAXB utilizadas:
 *  - @XmlRootElement(name = "clientes")
 *      Indica que esta clase es la raíz del documento XML.
 *
 *  - @XmlAccessorType(XmlAccessType.FIELD)
 *      Permite que JAXB lea directamente los atributos del campo sin
 *      necesidad de métodos getter/setter durante el parseo.
 *
 *  - @XmlElement(name = "cliente")
 *      Indica que dentro de <clientes> hay varios elementos <cliente>
 *      que deben mapearse a una lista de objetos Cliente.
 *
 */

import jakarta.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "clientes")
@XmlAccessorType(XmlAccessType.FIELD)
public class Clientes {

    @XmlElement(name = "cliente")
    private List<Cliente> lista;

    public Clientes() {}  // requerido por JAXB

    public List<Cliente> getLista() { return lista; }
    public void setLista(List<Cliente> lista) { this.lista = lista; }
}
