package com.example.xmltojson.modelo;


import jakarta.xml.bind.annotation.*;
import java.util.List;

/**
 * Clase raíz que mapea el elemento <clientes> del XML.
 *
 * Estructura asociada:
 *   <clientes>
 *     <cliente ...> ... </cliente>
 *     <cliente ...> ... </cliente>
 *   </clientes>
 *
 * Anotaciones JAXB:
 *  - @XmlRootElement(name = "clientes"): indica la raíz del documento.
 *  - @XmlAccessorType(XmlAccessType.FIELD): acceso por campo.
 *  - @XmlElement(name = "cliente"): cada <cliente> se mapea a un objeto Cliente de la lista.
 */
@XmlRootElement(name = "clientes")
@XmlAccessorType(XmlAccessType.FIELD)
public class Clientes {

    @XmlElement(name = "cliente")
    private List<Cliente> lista;

    public Clientes() { } // requerido por JAXB

    public List<Cliente> getLista() { return lista; }
    public void setLista(List<Cliente> lista) { this.lista = lista; }
}
