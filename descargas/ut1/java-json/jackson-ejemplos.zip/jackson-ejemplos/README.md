# Ejemplos de Jackson

Proyecto Maven para acompañar el minicurso **Jackson** de Acceso a Datos (2º DAM).

## Requisitos

- JDK 21
- Maven
- Jackson Databind 2.22.3

## Orden recomendado

1. `DemoJackson.java` — objeto Java ⇄ JSON.
2. `DemoListaJackson.java` — colecciones y `TypeReference`.
3. `GuardarAlumnosJackson.java` — guardar una colección en un fichero.
4. `LeerAlumnosJackson.java` — leer una colección desde un fichero.
5. `DemoJsonNode.java` — modelo de árbol con `JsonNode`.
6. `DemoAnotaciones.java` — personalización con anotaciones.

El proyecto está configurado con `<maven.compiler.release>21</maven.compiler.release>`.
