package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class DemoJackson {
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        Alumno original = new Alumno(1, "Ana", 8.5);

        String json = mapper.writeValueAsString(original);
        System.out.println("JSON:");
        System.out.println(json);

        Alumno recuperado = mapper.readValue(json, Alumno.class);
        System.out.println("\nObjeto recuperado:");
        System.out.println(recuperado);
    }
}
