package com.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Path;
import java.util.List;

public class LeerAlumnosJackson {
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        Path fichero = Path.of("data", "alumnos.json");

        List<Alumno> alumnos = mapper.readValue(
                fichero.toFile(),
                new TypeReference<List<Alumno>>() {}
        );

        alumnos.forEach(System.out::println);
    }
}
