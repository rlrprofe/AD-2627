package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class DemoAnotaciones {
    public static void main(String[] args) throws Exception {
        Alumno alumno = new Alumno(1, "Ana", 8.5);
        alumno.setObservaciones("Dato interno que no se serializa");

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(alumno);

        System.out.println(json);
        System.out.println("\nObserva que:");
        System.out.println("- nombre se representa como nombreCompleto.");
        System.out.println("- observaciones no aparece en el JSON.");
    }
}
