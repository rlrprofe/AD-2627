package com.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.List;

public class DemoListaJackson {
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        List<Alumno> alumnos = List.of(
                new Alumno(1, "Ana", 8.5),
                new Alumno(2, "Luis", 7.2),
                new Alumno(3, "Marta", 9.1)
        );

        String json = mapper.writeValueAsString(alumnos);
        System.out.println(json);

        List<Alumno> recuperados = mapper.readValue(
                json,
                new TypeReference<List<Alumno>>() {}
        );

        System.out.println("\nAlumnos recuperados:");
        recuperados.forEach(System.out::println);
    }
}
