package com.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DemoJsonNode {
    public static void main(String[] args) throws Exception {
        String json = """
                {
                  "id": 1,
                  "nombreCompleto": "Ana",
                  "nota": 8.5
                }
                """;

        ObjectMapper mapper = new ObjectMapper();
        JsonNode raiz = mapper.readTree(json);

        System.out.println("Nombre: " + raiz.get("nombreCompleto").asText());
        System.out.println("Nota: " + raiz.get("nota").asDouble());
    }
}
