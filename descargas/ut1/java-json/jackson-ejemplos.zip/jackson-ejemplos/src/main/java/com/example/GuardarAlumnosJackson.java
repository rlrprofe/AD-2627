package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class GuardarAlumnosJackson {
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        List<Alumno> alumnos = List.of(
                new Alumno(1, "Ana", 8.5),
                new Alumno(2, "Luis", 7.2),
                new Alumno(3, "Marta", 9.1)
        );

        Path carpeta = Path.of("data");
        Files.createDirectories(carpeta);

        Path fichero = carpeta.resolve("alumnos.json");
        mapper.writeValue(fichero.toFile(), alumnos);

        System.out.println("Datos guardados en: " + fichero.toAbsolutePath());
    }
}
