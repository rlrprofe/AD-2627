package com.example;

import org.json.JSONObject;

public class RecorrerJSONObject {
    public static void main(String[] args) {
        JSONObject alumno = new JSONObject();
        alumno.put("id", 1024);
        alumno.put("nombre", "Ana");
        alumno.put("notaMedia", 8.35);

        for (String clave : alumno.keySet()) {
            Object valor = alumno.get(clave);
            System.out.println(clave + " -> " + valor);
        }
    }
}
