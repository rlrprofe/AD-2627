package com.example;

import org.json.JSONObject;

public class DemoJSONObject {
    public static void main(String[] args) {
        JSONObject alumno = new JSONObject();
        alumno.put("id", 1024);
        alumno.put("nombre", "Ana");
        alumno.put("apellidos", "García López");
        alumno.put("notaMedia", 8.35);
        alumno.put("repetidor", false);

        System.out.println(alumno.toString(4));
        System.out.println("Nombre: " + alumno.getString("nombre"));
        System.out.println("Nota media: " + alumno.getDouble("notaMedia"));

        alumno.put("notaMedia", 9.10);
        System.out.println("Nota modificada: " + alumno.getDouble("notaMedia"));
    }
}
