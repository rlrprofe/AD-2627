package com.example;

import org.json.JSONArray;
import org.json.JSONObject;

public class DemoJSONArray {

    public static void main(String[] args) {

        // 1. Array de valores simples
        JSONArray modulos = new JSONArray();
        modulos.put("Acceso a Datos");
        modulos.put("Desarrollo de Interfaces");
        modulos.put("Programación de Servicios");

        System.out.println("ARRAY DE MÓDULOS");
        System.out.println(modulos.toString(4));

        // 2. Acceder a un elemento por su posición
        System.out.println("\nPrimer módulo: " + modulos.getString(0));

        // 3. Recorrer el array
        System.out.println("\nLISTADO DE MÓDULOS");
        for (int i = 0; i < modulos.length(); i++) {
            System.out.println(i + " -> " + modulos.getString(i));
        }

        // 4. Modificar y eliminar elementos
        modulos.put(1, "Sistemas de Gestión Empresarial");
        System.out.println("\nDespués de modificar la posición 1:");
        System.out.println(modulos.toString(4));

        modulos.remove(2);
        System.out.println("\nDespués de eliminar la posición 2:");
        System.out.println(modulos.toString(4));

        // 5. Array de objetos JSON
        JSONObject alumno1 = new JSONObject();
        alumno1.put("id", 1);
        alumno1.put("nombre", "Ana");
        alumno1.put("nota", 8.5);

        JSONObject alumno2 = new JSONObject();
        alumno2.put("id", 2);
        alumno2.put("nombre", "Luis");
        alumno2.put("nota", 7.2);

        JSONObject alumno3 = new JSONObject();
        alumno3.put("id", 3);
        alumno3.put("nombre", "Marta");
        alumno3.put("nota", 9.1);

        JSONArray alumnos = new JSONArray();
        alumnos.put(alumno1);
        alumnos.put(alumno2);
        alumnos.put(alumno3);

        System.out.println("\nARRAY DE ALUMNOS");
        System.out.println(alumnos.toString(4));

        // 6. Recorrer un array de JSONObject
        System.out.println("\nALUMNOS");
        for (int i = 0; i < alumnos.length(); i++) {
            JSONObject alumno = alumnos.getJSONObject(i);
            System.out.println(alumno.getInt("id") + " - "
                    + alumno.getString("nombre") + " - Nota: "
                    + alumno.getDouble("nota"));
        }

        // 7. Información del array
        System.out.println("\nNúmero de alumnos: " + alumnos.length());
        System.out.println("¿Está vacío?: " + alumnos.isEmpty());

        // 8. Acceso opcional a una posición inexistente
        String valor = modulos.optString(10, "No disponible");
        System.out.println("Posición 10: " + valor);
    }
}
