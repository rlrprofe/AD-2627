package com.example;

import org.json.JSONArray;
import org.json.JSONObject;

public class JSONArrayAnidado {

    public static void main(String[] args) {

        // 1. Módulos de Ana
        JSONArray modulosAna = new JSONArray();
        modulosAna.put("Acceso a Datos");
        modulosAna.put("Desarrollo de Interfaces");

        // 2. Alumna Ana
        JSONObject ana = new JSONObject();
        ana.put("id", 1);
        ana.put("nombre", "Ana");
        ana.put("modulos", modulosAna);

        // 3. Módulos de Luis
        JSONArray modulosLuis = new JSONArray();
        modulosLuis.put("Acceso a Datos");
        modulosLuis.put("Programación de Servicios");

        // 4. Alumno Luis
        JSONObject luis = new JSONObject();
        luis.put("id", 2);
        luis.put("nombre", "Luis");
        luis.put("modulos", modulosLuis);

        // 5. Array de alumnos
        JSONArray alumnos = new JSONArray();
        alumnos.put(ana);
        alumnos.put(luis);

        // 6. Objeto principal
        JSONObject grupo = new JSONObject();
        grupo.put("ciclo", "DAM");
        grupo.put("curso", 2);
        grupo.put("alumnos", alumnos);

        // 7. Mostrar la estructura completa
        System.out.println("JSON COMPLETO");
        System.out.println(grupo.toString(4));

        // 8. Recorrer la estructura anidada
        JSONArray listaAlumnos = grupo.getJSONArray("alumnos");

        System.out.println("\nALUMNOS Y MÓDULOS");
        for (int i = 0; i < listaAlumnos.length(); i++) {
            JSONObject alumno = listaAlumnos.getJSONObject(i);
            System.out.println("\nAlumno: " + alumno.getString("nombre"));

            JSONArray modulos = alumno.getJSONArray("modulos");
            for (int j = 0; j < modulos.length(); j++) {
                System.out.println("  - " + modulos.getString(j));
            }
        }
    }
}
