package com.example;

import org.json.JSONObject;

public class JSONObjectAnidado {
    public static void main(String[] args) {
        JSONObject alumno = new JSONObject();
        alumno.put("id", 1024);
        alumno.put("nombre", "Ana");

        JSONObject direccion = new JSONObject();
        direccion.put("ciudad", "Alcalá de Henares");
        direccion.put("codigoPostal", "28801");

        alumno.put("direccion", direccion);
        System.out.println(alumno.toString(4));

        JSONObject dir = alumno.getJSONObject("direccion");
        System.out.println("Ciudad: " + dir.getString("ciudad"));
    }
}
