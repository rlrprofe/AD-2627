package com.example;

import org.json.JSONObject;

public class JSONObjectOpcionales {
    public static void main(String[] args) {
        JSONObject alumno = new JSONObject();
        alumno.put("nombre", "Ana");
        alumno.put("email", JSONObject.NULL);

        String telefono = alumno.optString("telefono", "No disponible");
        System.out.println("Teléfono: " + telefono);
        System.out.println("¿Existe email?: " + alumno.has("email"));
        System.out.println("¿Email es null?: " + alumno.isNull("email"));

        if (alumno.has("nombre")) {
            System.out.println("Nombre: " + alumno.getString("nombre"));
        }
    }
}
