# Ejemplos de org.json

Proyecto Maven de apoyo al minicurso **JSON con Java: org.json** del módulo **Acceso a Datos de 2.º DAM**.

El proyecto está preparado para **JDK 21** y reúne, en un único proyecto, los ejemplos introductorios de `JSONObject` y `JSONArray` junto con los ejemplos de escritura y lectura de ficheros JSON mediante `JSONTokener`.

## Requisitos

- JDK 21.
- Maven.
- La dependencia `org.json` está declarada en `pom.xml`.

La configuración del compilador es:

```xml
<maven.compiler.release>21</maven.compiler.release>
```

La dependencia utilizada es:

```xml
<dependency>
    <groupId>org.json</groupId>
    <artifactId>json</artifactId>
    <version>20240303</version>
</dependency>
```

## Orden pedagógico recomendado

Los ejemplos están pensados para ejecutarse en el siguiente orden.

### Bloque 1. JSONObject

1. **`DemoOrgJson.java`**  
   Primera toma de contacto con `org.json`. Crea un `JSONObject`, añade datos con `put()`, lo muestra con `toString()` y recupera valores con `getString()` y `getInt()`.

2. **`DemoJSONObject.java`**  
   Amplía el ejemplo anterior utilizando diferentes tipos de datos, `toString(4)`, métodos `get...()` y modificación de propiedades.

3. **`JSONObjectOpcionales.java`**  
   Introduce datos opcionales y valores nulos mediante `optString()`, `has()`, `isNull()` y `JSONObject.NULL`.

4. **`JSONObjectAnidado.java`**  
   Construye un objeto dentro de otro objeto y muestra cómo acceder a él mediante `getJSONObject()`.

5. **`RecorrerJSONObject.java`**  
   Recorre todas las propiedades de un objeto mediante `keySet()` y recupera valores genéricos mediante `get()`.

### Bloque 2. JSONArray

6. **`DemoJSONArray.java`**  
   Introduce `JSONArray`: creación, `put()`, acceso por posición, `getString()`, `length()`, `isEmpty()`, modificación, eliminación, recorrido y arrays de `JSONObject`.

7. **`JSONArrayAnidado.java`**  
   Combina `JSONObject` y `JSONArray` en varios niveles. Construye un grupo con alumnos y módulos y recorre la estructura completa.

### Bloque 3. Guardar y leer un JSONObject

8. **`GuardarJSONv1.java`**  
   Crea un `JSONObject` y lo escribe en `data/persona.json` mediante `FileWriter` y `toString(4)`.

9. **`LeerJSONv1.java`**  
   Lee `data/persona.json` mediante `FileReader` y `JSONTokener`, reconstruye el `JSONObject` y recupera sus propiedades.

### Bloque 4. Guardar y leer un JSONArray de objetos

10. **`GuardarJSONv2.java`**  
    Solicita varias personas por teclado, crea un `JSONObject` para cada una, las incorpora a un `JSONArray` y guarda el resultado en `data/personas.json`.

11. **`LeerJSONv2.java`**  
    Ejemplo más completo de lectura. Utiliza `BufferedReader`, `JSONTokener.nextValue()` y comprueba si la raíz es un `JSONArray` o un `JSONObject`. También valida los datos antes de procesarlos.

## Progresión del aprendizaje

```text
JSONObject básico
      ↓
Tipos y operaciones
      ↓
Datos opcionales y null
      ↓
Objetos anidados
      ↓
Recorrer JSONObject
      ↓
JSONArray
      ↓
Arrays de JSONObject
      ↓
Estructuras anidadas
      ↓
Guardar JSONObject
      ↓
Leer JSONObject + JSONTokener
      ↓
Guardar JSONArray
      ↓
Leer JSONArray + JSONTokener
```

## Ficheros de datos

La carpeta `data` contiene los documentos utilizados por los ejemplos de lectura y escritura:

- `persona.json`: objeto JSON utilizado por los ejemplos v1.
- `personas.json`: array de objetos JSON utilizado por los ejemplos v2.

Los ejemplos de escritura pueden crear o sobrescribir estos ficheros.

## Estructura del proyecto

```text
org-json-ejemplos/
├── pom.xml
├── README.md
├── data/
│   ├── persona.json
│   └── personas.json
└── src/main/java/com/example/
    ├── DemoOrgJson.java
    ├── DemoJSONObject.java
    ├── JSONObjectOpcionales.java
    ├── JSONObjectAnidado.java
    ├── RecorrerJSONObject.java
    ├── DemoJSONArray.java
    ├── JSONArrayAnidado.java
    ├── GuardarJSONv1.java
    ├── LeerJSONv1.java
    ├── GuardarJSONv2.java
    └── LeerJSONv2.java
```

## Cómo utilizar el proyecto

1. Abrir la carpeta del proyecto en VS Code o en el IDE utilizado en clase.
2. Comprobar que el proyecto utiliza **JDK 21**.
3. Esperar a que Maven descargue la dependencia `org.json`.
4. Ejecutar los ejemplos siguiendo el orden pedagógico anterior.
5. Antes de los ejemplos de lectura, ejecutar el ejemplo de escritura correspondiente o comprobar que existe el fichero necesario en `data`.

Se recomienda consultar paralelamente los apuntes del minicurso para relacionar cada ejemplo con los conceptos explicados.
