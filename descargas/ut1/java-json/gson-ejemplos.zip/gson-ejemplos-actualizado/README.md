# Ejemplos Gson — Java 21

Proyecto Maven docente con ejemplos de Gson organizados por responsabilidades.

## Estructura

- `model`: clases del modelo de dominio (`Alumno`).
- `adapter`: adaptadores específicos de Gson (`LocalDateAdapter`).
- `config`: configuración centralizada de Gson (`GsonConfig`).
- `repository`: acceso a datos JSON (`AlumnoJsonRepository`).
- `app`: programas de demostración ejecutables.

## Por qué era necesario `LocalDateAdapter`

En Java 21, Gson no puede acceder por reflexión a los campos privados internos de
`java.time.LocalDate`. Si una clase contiene un atributo `LocalDate` y se usa un
`new Gson()` sin adaptador, puede aparecer `InaccessibleObjectException`.

La solución aplicada es registrar explícitamente un adaptador de `LocalDate` en
`GsonConfig` y utilizar esa configuración en todos los ejemplos.

No se recomienda solucionar este caso abriendo el módulo `java.time` mediante
opciones de la JVM: es preferible definir cómo se representa la fecha en JSON.

## Buenas prácticas aplicadas

- Java 21 mediante `maven.compiler.release`.
- Separación por paquetes y responsabilidades.
- Modelo independiente de Gson.
- Configuración de Gson centralizada.
- Persistencia aislada en un repositorio.
- UTF-8 explícito.
- `Path` y `Files` en lugar de APIs antiguas cuando se trabaja con ficheros.
- `try-with-resources` para lectores y escritores.
- Captura de `IOException` en la capa de aplicación.
- Comentarios docentes en los puntos relevantes.

## Compilar

```bash
mvn clean compile
```

Después se pueden ejecutar las clases del paquete `com.example.app` desde VS Code.
