package com.example.app;

import java.time.LocalDate;

import com.example.config.GsonConfig;
import com.example.model.Alumno;
import com.google.gson.Gson;

/**
 * Ejemplo específico de serialización y deserialización de LocalDate.
 */
public class DemoLocalDateGson {

    public static void main(String[] args) {
        Alumno alumno = new Alumno(
                1,
                "Ana",
                8.5,
                LocalDate.of(2005, 3, 15)
        );

        Gson gson = GsonConfig.crearGson();

        String json = gson.toJson(alumno);
        System.out.println("JSON generado:");
        System.out.println(json);

        Alumno recuperado = gson.fromJson(json, Alumno.class);
        System.out.println("\nAlumno recuperado:");
        System.out.println(recuperado);
    }
}
