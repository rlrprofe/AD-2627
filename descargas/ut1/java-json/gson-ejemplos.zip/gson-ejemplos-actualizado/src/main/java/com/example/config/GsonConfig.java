package com.example.config;

import java.time.LocalDate;

import com.example.adapter.LocalDateAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Centraliza la configuración de Gson para que todos los ejemplos utilicen
 * exactamente los mismos adaptadores y opciones.
 */
public final class GsonConfig {

    private GsonConfig() {
        // Evita instanciar esta clase de utilidades.
    }

    /**
     * Crea una instancia de Gson configurada para el proyecto.
     *
     * @return Gson con formato legible y soporte para LocalDate.
     */
    public static Gson crearGson() {
        return new GsonBuilder()
                .registerTypeAdapter(LocalDate.class, new LocalDateAdapter())
                .setPrettyPrinting()
                .create();
    }
}
