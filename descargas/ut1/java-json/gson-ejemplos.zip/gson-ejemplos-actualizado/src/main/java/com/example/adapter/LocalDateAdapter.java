package com.example.adapter;

import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

/**
 * Adaptador de Gson para convertir LocalDate a/desde una cadena ISO (yyyy-MM-dd).
 *
 * Gson no debe intentar acceder mediante reflexión a los campos internos de
 * java.time.LocalDate en Java 21. Este adaptador define explícitamente cómo
 * serializar y deserializar ese tipo.
 */
public class LocalDateAdapter
        implements JsonSerializer<LocalDate>, JsonDeserializer<LocalDate> {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;

    @Override
    public JsonElement serialize(LocalDate fecha, Type tipo,
                                 JsonSerializationContext contexto) {
        return new JsonPrimitive(fecha.format(FORMATTER));
    }

    @Override
    public LocalDate deserialize(JsonElement json, Type tipo,
                                 JsonDeserializationContext contexto)
            throws JsonParseException {
        try {
            return LocalDate.parse(json.getAsString(), FORMATTER);
        } catch (DateTimeParseException | IllegalStateException e) {
            throw new JsonParseException(
                    "Fecha no válida. Se esperaba el formato yyyy-MM-dd: " + json, e);
        }
    }
}
