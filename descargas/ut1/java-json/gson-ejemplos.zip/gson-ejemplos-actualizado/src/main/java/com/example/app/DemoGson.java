package com.example.app;

import com.example.config.GsonConfig;
import com.example.model.Alumno;
import com.google.gson.Gson;

/**
 * Ejemplo básico: objeto Java -> JSON -> objeto Java.
 */
public class DemoGson {

    public static void main(String[] args) {
        // Se usa la configuración común para evitar problemas con LocalDate.
        Gson gson = GsonConfig.crearGson();

        Alumno original = new Alumno(1, "Ana", 8.5);

        String json = gson.toJson(original);
        System.out.println("JSON generado:");
        System.out.println(json);

        Alumno recuperado = gson.fromJson(json, Alumno.class);
        System.out.println("\nAlumno recuperado:");
        System.out.println(recuperado);
    }
}
