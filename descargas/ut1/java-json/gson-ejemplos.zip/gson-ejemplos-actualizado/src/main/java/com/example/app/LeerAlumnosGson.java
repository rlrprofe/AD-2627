package com.example.app;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import com.example.config.GsonConfig;
import com.example.model.Alumno;
import com.example.repository.AlumnoJsonRepository;
import com.google.gson.Gson;

/**
 * Ejemplo de lectura de una lista de alumnos desde un fichero JSON.
 */
public class LeerAlumnosGson {

    public static void main(String[] args) {
        Gson gson = GsonConfig.crearGson();
        Path ruta = Path.of("data", "alumnos.json");
        AlumnoJsonRepository repository = new AlumnoJsonRepository(gson, ruta);

        try {
            List<Alumno> alumnos = repository.leerTodos();

            System.out.println("Alumnos leídos:");
            alumnos.forEach(System.out::println);
        } catch (IOException e) {
            System.err.println("Error al leer el fichero: " + e.getMessage());
        }
    }
}
