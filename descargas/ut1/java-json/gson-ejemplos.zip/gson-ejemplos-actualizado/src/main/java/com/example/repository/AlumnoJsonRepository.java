package com.example.repository;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import com.example.model.Alumno;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Encapsula el acceso al fichero JSON de alumnos.
 * Separa la persistencia del modelo y de las clases de demostración.
 */
public class AlumnoJsonRepository {

    private final Gson gson;
    private final Path ruta;

    public AlumnoJsonRepository(Gson gson, Path ruta) {
        this.gson = gson;
        this.ruta = ruta;
    }

    /**
     * Guarda la lista completa de alumnos.
     */
    public void guardar(List<Alumno> alumnos) throws IOException {
        Path padre = ruta.getParent();
        if (padre != null) {
            Files.createDirectories(padre);
        }

        // try-with-resources garantiza el cierre del escritor incluso si hay error.
        try (BufferedWriter writer =
                     Files.newBufferedWriter(ruta, StandardCharsets.UTF_8)) {
            gson.toJson(alumnos, writer);
        }
    }

    /**
     * Lee todos los alumnos almacenados.
     */
    public List<Alumno> leerTodos() throws IOException {
        Type tipoLista = new TypeToken<List<Alumno>>() { }.getType();

        // try-with-resources garantiza el cierre del lector.
        try (BufferedReader reader =
                     Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            List<Alumno> alumnos = gson.fromJson(reader, tipoLista);
            return alumnos != null ? alumnos : List.of();
        }
    }
}
