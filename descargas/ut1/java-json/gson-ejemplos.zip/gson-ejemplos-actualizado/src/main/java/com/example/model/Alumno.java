package com.example.model;

import java.time.LocalDate;

/**
 * Modelo de dominio que representa a un alumno.
 */
public class Alumno {
    private int id;
    private String nombre;
    private double nota;
    private LocalDate fechaNacimiento;

    /**
     * Constructor vacío necesario para distintos procesos de creación
     * y útil en ejemplos de persistencia/serialización.
     */
    public Alumno() {
    }

    public Alumno(int id, String nombre, double nota) {
        this(id, nombre, nota, null);
    }

    public Alumno(int id, String nombre, double nota, LocalDate fechaNacimiento) {
        this.id = id;
        this.nombre = nombre;
        this.nota = nota;
        this.fechaNacimiento = fechaNacimiento;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", nota=" + nota +
                ", fechaNacimiento=" + fechaNacimiento +
                '}';
    }
}
