package com.example.app;

import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import com.example.config.GsonConfig;
import com.example.model.Alumno;
import com.example.repository.AlumnoJsonRepository;
import com.google.gson.Gson;

/**
 * Ejemplo de escritura de una lista de alumnos en un fichero JSON.
 */
public class GuardarAlumnosGson {

    public static void main(String[] args) {
        List<Alumno> alumnos = List.of(
                new Alumno(1, "Ana", 8.5, LocalDate.of(2005, 3, 15)),
                new Alumno(2, "Luis", 7.2, LocalDate.of(2004, 11, 8)),
                new Alumno(3, "Marta", 9.1, LocalDate.of(2005, 7, 21))
        );

        Gson gson = GsonConfig.crearGson();
        Path ruta = Path.of("data", "alumnos.json");
        AlumnoJsonRepository repository = new AlumnoJsonRepository(gson, ruta);

        try {
            repository.guardar(alumnos);
            System.out.println("Fichero guardado en:");
            System.out.println(ruta.toAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error al guardar el fichero: " + e.getMessage());
        }
    }
}
