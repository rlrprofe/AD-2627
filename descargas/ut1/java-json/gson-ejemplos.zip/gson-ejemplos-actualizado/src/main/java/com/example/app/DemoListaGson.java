package com.example.app;

import java.lang.reflect.Type;
import java.util.List;

import com.example.config.GsonConfig;
import com.example.model.Alumno;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Ejemplo de conversión de colecciones con TypeToken.
 */
public class DemoListaGson {

    public static void main(String[] args) {
        List<Alumno> alumnos = List.of(
                new Alumno(1, "Ana", 8.5),
                new Alumno(2, "Luis", 7.2),
                new Alumno(3, "Marta", 9.1)
        );

        Gson gson = GsonConfig.crearGson();

        String json = gson.toJson(alumnos);
        System.out.println("JSON generado:");
        System.out.println(json);

        // Gson necesita conservar el tipo genérico List<Alumno>.
        Type tipoLista = new TypeToken<List<Alumno>>() { }.getType();
        List<Alumno> recuperados = gson.fromJson(json, tipoLista);

        System.out.println("\nAlumnos recuperados:");
        recuperados.forEach(System.out::println);
    }
}
