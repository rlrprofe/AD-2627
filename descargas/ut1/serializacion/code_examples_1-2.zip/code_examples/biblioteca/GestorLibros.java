package biblioteca;

import biblioteca.model.Libro;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Clase que contiene métodos estáticos para gestionar
 * la serialización y deserialización de objetos Libro.
 */
public class GestorLibros {

    // Nombre del fichero donde se guardan los libros
    private static final String FICHERO = "libros.dat";

    /**
     * Carga todos los libros del fichero.
     * @return Lista de libros leída del fichero o lista vacía si no hay datos.
     */
    public static List<Libro> cargarLibros() {
        File f = new File(FICHERO);
        if (!f.exists() || f.length() == 0) {
            // Si el fichero no existe o está vacío → no hay datos
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FICHERO))) {
            return (List<Libro>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /**
     * Guarda una lista completa de libros en el fichero.
     * Sobrescribe el contenido previo.
     * @param libros Lista de libros a guardar.
     */
    public static void guardarLibros(List<Libro> libros) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHERO))) {
            oos.writeObject(libros);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Añade un libro nuevo al fichero.
     * @param libro Libro a añadir.
     */
    public static void anadirLibro(Libro libro) {
        List<Libro> libros = cargarLibros();
        libros.add(libro); // Se añade a la colección
        guardarLibros(libros); // Se guarda la lista actualizada
    }

    /**
     * Elimina un libro por ISBN.
     * @param isbn ISBN del libro a eliminar.
     * @return true si se eliminó, false si no se encontró.
     */
    public static boolean eliminarLibro(String isbn) {
        List<Libro> libros = cargarLibros();
        boolean eliminado = false;

        // Recorremos con Iterator para eliminar de forma segura
        Iterator<Libro> it = libros.iterator();
        while (it.hasNext()) {
            Libro l = it.next();
            if (l.getIsbn().equals(isbn)) {
                it.remove();      // Elimina el libro actual
                eliminado = true; // Marcamos que se encontró y eliminó
            }
        }

        // Si se eliminó, guardamos la lista actualizada
        if (eliminado) {
            guardarLibros(libros);
        }
        return eliminado;
    }

    /**
     * Muestra todos los libros del fichero.
     * Si no hay libros, muestra un mensaje informativo.
     */
    public static void mostrarLibros() {
        List<Libro> libros = cargarLibros();
        if (libros.isEmpty()) {
            System.out.println("No hay datos registrados.");
        } else {
            System.out.println("Listado de libros:");
            for (Libro l : libros) {
                System.out.println(" - " + l);
            }
        }
    }
}

