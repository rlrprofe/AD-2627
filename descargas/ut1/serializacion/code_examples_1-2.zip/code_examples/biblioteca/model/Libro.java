package biblioteca.model;

import java.io.Serializable;

/**
 * Clase que representa un Libro dentro de la biblioteca.
 * Implementa Serializable para poder guardarse en ficheros binarios.
 */
public class Libro implements Serializable {

    // Control de versión de la clase para la serialización
    private static final long serialVersionUID = 1L;

    // Atributos básicos de un libro
    private String isbn;
    private String titulo;
    private String autor;
    private int anio;

    /**
     * Constructor de la clase Libro.
     * @param isbn   Identificador único del libro.
     * @param titulo Título del libro.
     * @param autor  Autor del libro.
     * @param anio   Año de publicación.
     */
    public Libro(String isbn, String titulo, String autor, int anio) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
    }

    /** @return ISBN del libro */
    public String getIsbn() { return isbn; }

    /** Representación en texto de un libro */
    @Override
    public String toString() {
        return "ISBN: " + isbn + " | Título: " + titulo +
               " | Autor: " + autor + " | Año: " + anio;
    }
}
