package model;

import java.io.Serializable;

/* Controla serialVersionUID */
public class Personav2 implements Serializable {
    private static final long serialVersionUID = 1L;

    private String nombre;
    private int edad;
    private transient String password;

    public Personav2(String nombre, int edad, String password) {
        this.nombre = nombre;
        this.edad = edad;
        this.password = password;
    }

    @Override
    public String toString() {
        return nombre + " (" + edad + ")";
    }
}
