package model;


import java.io.Serializable;

public class Persona implements Serializable {
    // Recomendado para control de versión de clases (ver 6.1)
    private static final long serialVersionUID = 1L;

    private String nombre;
    private int    edad;
    private transient String password; // No se serializa

    public Persona(String nombre, int edad, String password) {
        this.nombre = nombre;
        this.edad = edad;
        this.password = password;
    }

    @Override
    public String toString() {
        return nombre + " (" + edad + " años) pwd=" + password;
    }
}
