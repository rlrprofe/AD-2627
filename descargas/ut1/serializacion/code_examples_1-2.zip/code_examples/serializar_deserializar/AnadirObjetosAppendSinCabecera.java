package serializar_deserializar;

import model.Persona;
import java.io.*;
import java.util.List;


/* Patron B Reabrir fichero en append sin cabecera extra*/
public class AnadirObjetosAppendSinCabecera {
    private static final String FICHERO = "patronB.dat";

    public static void main(String[] args) {
        // 1ª tanda: escribe cabecera + objetos
        escribir(List.of(
                new Persona("Ana", 25, "a"),
                new Persona("Luis", 31, "b")
        ));

        // 2ª tanda: añade más objetos SIN reescribir cabecera
        escribir(List.of(
                new Persona("Marta", 28, "c")
        ));
    }

    private static void escribir(List<Persona> personas) {
        File f = new File(FICHERO);
        boolean existe = f.exists() && f.length() > 0;

        try (OutputStream fos = new FileOutputStream(f, true);
             ObjectOutputStream oos = existe
                     ? new AppendingObjectOutputStream(fos) // sin cabecera
                     : new ObjectOutputStream(fos))          // con cabecera
        {
            for (Persona p : personas) {
                oos.writeObject(p);
                System.out.println("Escrita persona: " + p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
