package serializar_deserializar;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import model.Persona;

/* OPCIÓN B: escribir y leer una colección entera */

public class DemoSerializarDeserializarVariosColeccion {
    public static void main(String[] args) {
        List<Persona> personas = new ArrayList<>();
        personas.add(new Persona("Ana", 25, "a"));
        personas.add(new Persona("Luis", 31, "b"));
        personas.add(new Persona("Marta", 28, "c"));

        // 1) Escribir la colección completa de una sola vez
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("personas_lista.dat"))) {
            oos.writeObject(personas);
            System.out.println("Colección serializada en personas_lista.dat");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 2) Leer la colección completa
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("personas_lista.dat"))) {
            List<Persona> leidas = (List<Persona>) ois.readObject();
            System.out.println("Colección recuperada:");
            for (Persona p : leidas) {
                System.out.println(" - " + p);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
