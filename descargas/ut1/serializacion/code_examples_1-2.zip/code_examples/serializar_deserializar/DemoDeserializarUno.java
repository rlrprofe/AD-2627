package serializar_deserializar;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import model.Persona;

public class DemoDeserializarUno {
    public static void main(String[] args) {
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream("persona.dat"))) {
            Persona p = (Persona) ois.readObject();
            System.out.println("Leído: " + p); // password será null (transient)
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error leyendo: " + e.getMessage());
        }
    }
}

