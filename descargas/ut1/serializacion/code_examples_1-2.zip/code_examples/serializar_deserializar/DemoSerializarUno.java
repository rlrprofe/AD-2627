package serializar_deserializar;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import model.Persona;



public class DemoSerializarUno {
    public static void main(String[] args) {
        Persona p = new Persona("Ana", 25, "secreto123");

        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("persona.dat"))) {
            oos.writeObject(p); // Serializa 'p'
            System.out.println("OK: Objeto escrito en persona.dat");
        } catch (IOException e) {
            System.err.println("Error escribiendo: " + e.getMessage());
        }
    }
}
