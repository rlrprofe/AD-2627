package serializar_deserializar;
import java.io.*;
import java.util.List;
import model.Persona;

/* OPCIÓN A: escribirlos seguidos y leer hasta EOF */

public class DemoSerializarDeserializarVariosEOF {
    public static void main(String[] args) {
        List<Persona> personas = List.of(
                new Persona("Ana", 25, "a"),
                new Persona("Luis", 31, "b"),
                new Persona("Marta", 28, "c")
        );

        // 1) Escribir varias personas seguidas
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("personas.dat"))) {
            for (Persona p : personas) {
                oos.writeObject(p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 2) Leer hasta EOFException
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("personas.dat"))) {
            while (true) {
                Persona p = (Persona) ois.readObject();
                System.out.println("Leída: " + p);
            }
        } catch (EOFException eof) {
            System.out.println("Fin de fichero.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
