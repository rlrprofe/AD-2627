package serializar_deserializar;
/**
 * Extensión de ObjectOutputStream para poder añadir objetos a un fichero
 * sin reescribir la cabecera del stream.
 */
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

/* Patrón B — Reabrir fichero en append sin cabecera extra */
// Clase especial que omite la cabecera en escrituras posteriores
public class AppendingObjectOutputStream extends ObjectOutputStream {
    public AppendingObjectOutputStream(OutputStream out) throws IOException {
        super(out);
    }

    @Override
    protected void writeStreamHeader() throws IOException {
        reset(); // evita escribir STREAM_MAGIC/STREAM_VERSION otra vez
    }
}
