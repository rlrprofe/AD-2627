package serializar_deserializar;

import model.Persona;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;

/* Patron A  Mantener un único ObjectOutputStream abierto */
public class AnadirObjetosPatronUnicoOOS {
    public static void main(String[] args) {
        List<Persona> personas = List.of(
                new Persona("Ana", 25, "a"),
                new Persona("Luis", 31, "b"),
                new Persona("Marta", 28, "c")
        );

        // Abrimos un único ObjectOutputStream
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("patronA.dat"))) {
            // Vamos escribiendo objetos uno a uno
            for (Persona p : personas) {
                oos.writeObject(p);  // cada llamada serializa un objeto
                System.out.println("Escrita persona: " + p);
            }
            // Al salir del try-with-resources se cierra automáticamente
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
