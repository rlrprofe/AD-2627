-- 1) Crear la base de datos
DROP DATABASE IF EXISTS demo_jpa_estados;
CREATE DATABASE demo_jpa_estados
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

-- 2) (Opcional) Verificar
-- SHOW DATABASES LIKE 'demo_jpa_estados';


