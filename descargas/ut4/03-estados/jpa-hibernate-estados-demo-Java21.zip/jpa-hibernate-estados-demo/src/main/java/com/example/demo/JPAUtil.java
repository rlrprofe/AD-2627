package com.example.demo;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Crea una única EntityManagerFactory para toda la aplicación (objeto "pesado").
 */
public final class JPAUtil {

    private static EntityManagerFactory emf;

    private JPAUtil() {}

    public static EntityManagerFactory getEmf() {
        if (emf == null) {
            emf = Persistence.createEntityManagerFactory("demoPU"); //"demoPU es nombre pusimos en persistence.xml"
        }
        return emf;
    }

    public static void close() {
        if (emf != null) {
            emf.close();
        }
    }
}
