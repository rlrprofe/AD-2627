package com.example.demo;

import com.example.model.Cliente;
import com.example.model.Pedido;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import org.hibernate.LazyInitializationException;

import java.util.List;

/**
 * Demo para comprobar estados de entidad con JPA (Jakarta Persistence) + Hibernate:
 * - Transient
 * - Persistent/Managed
 * - Detached
 * - Merge
 * - Remove
 * - LazyInitializationException (relación LAZY con EM cerrado)
 *
 * Ejecutar:
 *   mvn -q clean compile exec:java
 */
public class EstadosDemo {

    public static void main(String[] args) {
        try {
            escenarioTransientToManaged();
            Long idCliente = escenarioManagedDirtyChecking();
            Cliente detached = escenarioDetached(idCliente);
            escenarioMerge(detached);
            escenarioLazyLoading(idCliente);
            escenarioRemove(idCliente);
        } finally {
            JPAUtil.close();
        }
    }

    /**
     * 1) Transient -> Managed (persist)
     * El objetivo de este escenario es:
     *  - Cómo un objeto pasa del estado TRANSIENT al estado PERSISTENT (MANAGED) usando persist(),
        y qué ocurre antes, durante y después del commit.

        Se seguirá este recorrido:
            new Cliente()        → TRANSIENT
            persist(cliente)    → MANAGED
            commit + close EM   → DETACHED
     */
    private static void escenarioTransientToManaged() {
        System.out.println("\n=== ESCENARIO 1: Transient -> Managed (persist) ===");

        Cliente c = new Cliente("Ana", "ana@demo.es"); // transient
        System.out.println("Antes de persist: " + c + " (id = " + c.getId() + ")"); //imprimirá id null

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            em.persist(c); // pasa a managed
            System.out.println("Tras persist (antes commit): " + c + " (id = " + c.getId() + ")"); //ahora si tiene valor para id
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            em.close();
        }

        System.out.println("Tras commit y EM cerrado: " + c + " (id = " + c.getId() + ")");
        System.out.println("Nota: ahora c existe en BD, pero está DETACHED (EM cerrado).");
    }

    /**
     * 2) Managed + dirty checking (cambio automático con commit)
     * Devuelve el id para los siguientes escenarios.
     * 
     * Cuando una entidad está en estado MANAGED, Hibernate detecta automáticamente 
     * los cambios y ejecuta un UPDATE sin que el programador lo pida explícitamente.
       Este mecanismo se llama dirty checking.
     */
    private static Long escenarioManagedDirtyChecking() {
        System.out.println("\n=== ESCENARIO 2: Managed + dirty checking (update automático) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        Long id;
        try {
            tx.begin();

            Cliente c = new Cliente("Luis", "luis@demo.es");
            c.addPedido(new Pedido("Pedido 1"));
            c.addPedido(new Pedido("Pedido 2"));

            em.persist(c); // managed
            tx.commit();

            id = c.getId();
            System.out.println("Cliente creado: " + c);

        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            em.close();
        }

        // Ahora probamos dirty checking dentro de un EM activo
        em = JPAUtil.getEmf().createEntityManager();
        tx = em.getTransaction();

        try {
            tx.begin();
            Cliente managed = em.find(Cliente.class, id);
            System.out.println("Cargado (managed): " + managed);

            // Modificamos sin llamar a update
            managed.setNombre("Luis Modificado");
            System.out.println("Nombre modificado en memoria (managed). Al hacer commit, Hibernate generará UPDATE.");

            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            em.close();
        }

        return id;
    }

    /**
     * 3) Detached: se cierra EM y los cambios no se guardan automáticamente.
     * Devuelve el objeto detached
     * 
     * Cuando una entidad está en estado DETACHED, los cambios que hagamos sobre 
     * el objeto NO se guardan en la base de datos. Es decir:
            -El objeto existe en la BD.
            -El objeto existe en memoria.
            -Pero Hibernate ya no lo está gestionando.
        Por tanto: Cambiar el objeto no implica cambiar la base de datos..

        En este escenario haremos:
            find(cliente)      → MANAGED
            close EM           → DETACHED
            modificar objeto   → DETACHED
            find(cliente)      → BD SIN cambios
     */
    private static Cliente escenarioDetached(Long id) {
        System.out.println("\n=== ESCENARIO 3: Detached (cambios fuera de EM NO se guardan) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        Cliente c = em.find(Cliente.class, id); // managed
        System.out.println("Cargado (managed): " + c);
        em.close(); // pasa a detached

        System.out.println("EM cerrado. Ahora el objeto es DETACHED.");
        c.setNombre("Luis Cambiado Fuera De EM");
        System.out.println("Cambio en objeto detached: " + c);

        // Comprobación: volvemos a abrir EM y consultamos BD
        em = JPAUtil.getEmf().createEntityManager();
        Cliente enBd = em.find(Cliente.class, id);
        System.out.println("Valor en BD (tras cambio detached, sin merge): " + enBd);
        em.close();

        return c;
    }

    /**
     * 4) Merge: re-asociar un detached y persistir cambios.
     * Si el escenario 3 explica “por qué no se guardan los cambios”, 
     * el 4 explica “cómo hacer que se guarden cuando el objeto está detached”.
     * 
     * merge() permite volver a asociar un objeto DETACHED a un EntityManager
     * y sincronizar sus cambios con la base de datos. Es decir:
            -El objeto existe en la BD.
            -El objeto está en memoria.
            -Pero no está gestionado.
            -merge() es la forma estándar de JPA de reintegrarlo en el contexto de persistencia.

        Flujo general del escenario 4. El escenario sigue este recorrido:
                DETACHED
                ↓ merge()
                MANAGED (nuevo objeto)
                ↓ commit
                UPDATE en BD
     */
    private static void escenarioMerge(Cliente detached) {
        System.out.println("\n=== ESCENARIO 4: merge(detached) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Cliente managed = em.merge(detached);
            System.out.println("Objeto original (sigue detached): " + detached);
            System.out.println("Objeto devuelto por merge (managed): " + managed);

            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            em.close();
        }

        // Verificamos BD
        em = JPAUtil.getEmf().createEntityManager();
        Cliente enBd = em.find(Cliente.class, detached.getId());
        System.out.println("Valor en BD tras merge: " + enBd);
        em.close();
    }

    /**
     * 5) Lazy loading: acceder a colección LAZY con EM cerrado provoca excepción.
     * El Escenario 5 es el que suele generar más confusión al principio y, a la vez, 
     * el que mejor conecta los estados de entidad con las relaciones y el fetch
     * 
     * Una relación configurada como LAZY no puede cargarse si la entidad está 
     * en estado DETACHED (EntityManager cerrado).
     * El error resultante es la conocida: LazyInitializationException
        No es un error “raro”: es una consecuencia directa y lógica de cómo funciona ORM.

    Flujo general del escenario 5 El escenario sigue este recorrido:

        find(cliente)        → MANAGED
        close EntityManager  → DETACHED
        acceder a relación   → LazyInitializationException


La clave está en acceder a una relación LAZY cuando ya no hay contexto de persistencia.
     */
    private static void escenarioLazyLoading(Long id) {
        System.out.println("\n=== ESCENARIO 5: LazyInitializationException (relación LAZY con EM cerrado) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        Cliente c = em.find(Cliente.class, id); // managed
        System.out.println("Cargado (managed): " + c);

        em.close(); // detached
        System.out.println("EM cerrado. Intentamos acceder a c.getPedidos().size()...");

        try {
            int n = c.getPedidos().size(); // dispara lazy loading fuera de EM
            System.out.println("Pedidos: " + n);
        } catch (LazyInitializationException ex) {
            System.out.println("EXCEPCIÓN esperada: " + ex.getClass().getSimpleName());
            System.out.println("Motivo: la colección es LAZY y necesita un EntityManager abierto para cargarla.");
        }
    }

    /**
     * 6) Remove: borrado de entidad (managed + transacción).
     * Una entidad solo puede eliminarse correctamente cuando está en estado MANAGED.
        remove() no funciona sobre entidades DETACHED.

        Además, en el ejemplo también se ve:
            -cómo actúan las cascadas (cascade = ALL),
            -y qué ocurre con las entidades relacionadas (Pedidos).

        Flujo general del escenario 6
            find(cliente)        → MANAGED
            remove(cliente)      → marcado para borrado
            commit               → DELETE en BD (y cascadas)
            close EM             → DETACHED (ya no existe)
     */
    private static void escenarioRemove(Long id) {
        System.out.println("\n=== ESCENARIO 6: remove (borrado) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Cliente c = em.find(Cliente.class, id);
            System.out.println("A borrar (managed): " + c);

            em.remove(c);
            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            em.close();
        }

        // Verificamos
        em = JPAUtil.getEmf().createEntityManager();
        Cliente enBd = em.find(Cliente.class, id);
        System.out.println("Tras remove, find devuelve: " + enBd);
        em.close();
    }
}
