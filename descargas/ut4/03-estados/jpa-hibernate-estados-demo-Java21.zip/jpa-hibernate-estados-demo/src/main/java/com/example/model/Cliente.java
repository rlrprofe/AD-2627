/* Clase respresenta la tabla Cliente */
package com.example.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "clientes")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Clave primaria autogenerada (similar a AUTO_INCREMENT).
    private Long id; 

    @Column(nullable = false, length = 100) //Restricciones de columnas
    private String nombre;

    @Column(nullable = false, length = 150, unique = true) //Restricciones de columnas
    private String email;

    // Relación 1-N. LAZY para provocar el caso típico de LazyInitializationException
    @OneToMany(mappedBy = "cliente", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Pedido> pedidos = new ArrayList<>();

    /* Representa una relación 1-N (uno a muchos):
        Un Cliente puede tener muchos Pedidos.
        Cada Pedido pertenece a un solo Cliente 
    
        1) @OneToMany — Indica que:

                -La clase Cliente tiene una colección (List<Pedido>).
                -Esa colección representa muchos objetos Pedido.
                -En la base de datos esto se traduce en:
                        una tabla pedidos
                        con una clave foránea que apunta a clientes        
        2) mappedBy = "cliente" — quién es el dueño de la relación

                -Este es uno de los puntos más importantes
                -¿Qué significa mappedBy? mappedBy = "cliente" indica que:
                    -Esta relación NO se gestiona desde Cliente
                    -El lado propietario (dueño) de la relación es la clase Pedido
                    -Concretamente, el atributo cliente dentro de Pedido

        3) fetch = FetchType.LAZY — cuándo se cargan los pedidos Qué significa LAZY
            FetchType.LAZY indica que:
                    -Cuando cargas un Cliente, NO se cargan automáticamente sus pedidos.
                    -Hibernate solo trae los pedidos si y cuando los pides explícitamente.

        ¿Por qué usar LAZY? Porque:
            -Evita cargar datos innecesarios.
            -Mejora rendimiento.
            -Es el comportamiento por defecto recomendado en colecciones.
            -Regla práctica profesional: Las colecciones (List, Set) casi siempre deben ser LAZY.
    */


    public Cliente() {
        // Constructor vacío obligatorio
    }

    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    public void addPedido(Pedido p) {
        pedidos.add(p);
        p.setCliente(this);
    }

    public void removePedido(Pedido p) {
        pedidos.remove(p);
        p.setCliente(null);
    }

    public Long getId() {
        return id;
    }

    // Setter de id no suele usarse, pero lo dejamos para el ejemplo didáctico.
    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    @Override
    public String toString() {
        // Importante: NO accedemos a pedidos aquí (podría disparar lazy loading).
        return "Cliente{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
