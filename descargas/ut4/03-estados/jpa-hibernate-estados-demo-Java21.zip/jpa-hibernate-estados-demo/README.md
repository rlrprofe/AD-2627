# JPA + Hibernate: Demo de estados de entidad

Proyecto Maven (Java 17) para comprobar:
- Transient
- Persistent/Managed (dirty checking)
- Detached
- merge()
- remove()
- LazyInitializationException (LAZY con EntityManager cerrado)

## Requisitos
- JDK 17+
- Maven 3.8+

## Ejecutar
```bash
mvn -q clean compile exec:java
```

## Qué verás en consola
- Mensajes explicando cada escenario
- SQL generado por Hibernate (show_sql=true)
- Una LazyInitializationException provocada a propósito

## Base de datos
H2 en memoria (`jdbc:h2:mem:demo`), se crea y destruye automáticamente (`create-drop`).
