package com.example.demo;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Utilidad para crear y reutilizar el EntityManagerFactory.
 *
 * - EntityManagerFactory es "pesado": se crea una vez y se reutiliza.
 * - EntityManager es "ligero": se crea y se cierra por operación/escenario.
 */
public final class JPAUtil {

    private static final EntityManagerFactory EMF =
            Persistence.createEntityManagerFactory("demoPU");

    private JPAUtil() { }

    public static EntityManagerFactory getEmf() {
        return EMF;
    }

    public static void close() {
        if (EMF != null && EMF.isOpen()) {
            EMF.close();
        }
    }
}
