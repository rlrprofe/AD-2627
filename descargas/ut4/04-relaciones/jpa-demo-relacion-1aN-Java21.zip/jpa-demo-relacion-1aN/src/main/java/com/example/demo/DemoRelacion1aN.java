package com.example.demo;

import com.example.demo.model.Cliente;
import com.example.demo.model.Pedido;
import jakarta.persistence.EntityManager;

/**
 * Demo didáctica de relación 1-N (Cliente -> Pedido) con JPA/Hibernate.
 *
 * Objetivos:
 * 1) Ver que el lado propietario es Pedido (tiene la FK cliente_id).
 * 2) Guardar un Cliente con varios pedidos usando cascade.
 * 3) Probar orphanRemoval (quitar un pedido de la lista lo borra de la BD).
 * 4) Borrar el Cliente y ver el borrado en cascada de pedidos.
 */
public class DemoRelacion1aN {

    public static void main(String[] args) {
        try {
            crearClienteConPedidos();
            probarOrphanRemoval();
            borrarClienteConCascada();
        } finally {
            JPAUtil.close();
        }
    }

    private static void crearClienteConPedidos() {
        System.out.println("=== ESCENARIO 1: Crear Cliente y 2 Pedidos (cascade=PERSIST) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        em.getTransaction().begin();

        // Creamos el cliente (TRANSIENT)
        // Para poder ejecutar varias veces sin error de UNIQUE(email), hacemos el email único.
        Cliente c = new Cliente("Ana", "ana+" + System.currentTimeMillis() + "@demo.es");

        // Creamos pedidos (TRANSIENT)
        Pedido p1 = new Pedido("Pedido 1: Portátil");
        Pedido p2 = new Pedido("Pedido 2: Ratón");

        // Mantener coherencia en ambos lados:
        // - se añaden a la lista del cliente (lado 1)
        // - y se asigna el cliente en el pedido (lado N, propietario)
        c.addPedido(p1);
        c.addPedido(p2);

        // Persistimos SOLO el Cliente.
        // Gracias a cascade=ALL, Hibernate persistirá también p1 y p2.
        em.persist(c);

        em.getTransaction().commit();
        em.close();

        System.out.println("Cliente guardado con ID: " + c.getId());
        System.out.println("Pedidos creados: " + c.getPedidos().size());
        System.out.println();
    }

    private static void probarOrphanRemoval() {
        System.out.println("=== ESCENARIO 2: orphanRemoval (quitar un pedido => DELETE) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        em.getTransaction().begin();

        // Recuperamos el último cliente insertado (el de mayor ID).
        // Nota didáctica: para no introducir JPQL aún, usamos consulta nativa.
        Long ultimoId = ((Number) em.createNativeQuery("SELECT MAX(id) FROM clientes")
                .getSingleResult()).longValue();

        Cliente c = em.find(Cliente.class, ultimoId);

        System.out.println("Cliente cargado: " + c);

        // Accedemos a la lista dentro de la transacción (EM abierto)
        // para que LAZY pueda cargar los pedidos sin error.
        System.out.println("Pedidos antes: " + c.getPedidos().size());

        // Quitamos un pedido de la lista:
        // - orphanRemoval=true hará que Hibernate lo borre de BD en el commit.
        Pedido aBorrar = c.getPedidos().get(0);
        c.removePedido(aBorrar);

        em.getTransaction().commit();
        em.close();

        System.out.println("Se ha quitado 1 pedido. Al hacer commit, se elimina en BD (orphanRemoval).");
        System.out.println();
    }

    private static void borrarClienteConCascada() {
        System.out.println("=== ESCENARIO 3: remove Cliente (cascade=REMOVE borra pedidos) ===");

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        em.getTransaction().begin();

        Long ultimoId = ((Number) em.createNativeQuery("SELECT MAX(id) FROM clientes")
                .getSingleResult()).longValue();

        Cliente c = em.find(Cliente.class, ultimoId);

        // Importante: acceder a pedidos con EM abierto
        System.out.println("A borrar: " + c + " (pedidos actuales = " + c.getPedidos().size() + ")");

        // remove sobre una entidad MANAGED.
        // Con cascade=ALL, se borrarán pedidos asociados.
        em.remove(c);

        em.getTransaction().commit();
        em.close();

        System.out.println("Cliente borrado. Sus pedidos asociados también se han borrado (cascada).");
        System.out.println();
    }
}
