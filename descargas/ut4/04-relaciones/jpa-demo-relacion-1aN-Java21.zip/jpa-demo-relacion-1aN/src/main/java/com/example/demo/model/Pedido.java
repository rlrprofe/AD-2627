package com.example.demo.model;

import jakarta.persistence.*;

/**
 * ENTIDAD "Pedido"
 *
 * Relación N-1:
 *   Muchos pedidos pertenecen a un solo cliente.
 *
 * Esta entidad ES la PROPIETARIA de la relación,
 * porque aquí se define la clave foránea (cliente_id) con @JoinColumn.
 */
@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String descripcion;

    /**
     * Relación N-1 (lado N, PROPIETARIO).
     *
     * @ManyToOne: muchos pedidos pueden apuntar al mismo cliente.
     *
     * @JoinColumn(name = "cliente_id"):
     *  - crea la columna cliente_id en la tabla pedidos.
     *  - esa columna es una FK que apunta a clientes(id).
     *
     * nullable = false:
     *  - un pedido debe pertenecer a un cliente (en este ejemplo didáctico).
     */
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    public Pedido() { }

    public Pedido(String descripcion) {
        this.descripcion = descripcion;
    }

    public Long getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public Cliente getCliente() { return cliente; }

    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    @Override
    public String toString() {
        // Importante: no incluimos cliente completo para evitar cargas LAZY accidentales.
        return "Pedido{id=" + id + ", descripcion='" + descripcion + "'}";
    }
}
