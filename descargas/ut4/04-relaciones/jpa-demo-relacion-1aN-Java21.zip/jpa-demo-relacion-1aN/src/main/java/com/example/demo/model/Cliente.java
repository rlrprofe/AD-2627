package com.example.demo.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * ENTIDAD "Cliente"
 *
 * Relación 1-N:
 *   Un Cliente puede tener MUCHOS Pedidos.
 *
 * Importante en JPA:
 * - En 1-N, el lado "N" (Pedido) es el PROPIETARIO porque ahí está la FK.
 * - Por eso, en Cliente usamos mappedBy para indicar que NO somos propietarios.
 */
@Entity
@Table(name = "clientes",
       uniqueConstraints = @UniqueConstraint(name = "UK_clientes_email", columnNames = "email"))
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String nombre;

    @Column(nullable = false, length = 120)
    private String email;

    /**
     * Relación 1-N (lado 1, NO propietario).
     *
     * @OneToMany: un cliente tiene muchos pedidos.
     *
     * mappedBy = "cliente":
     *  - indica que la relación REAL se mantiene en Pedido.cliente (lado N).
     *  - es decir, Pedido contiene la clave foránea (cliente_id).
     *
     * fetch = LAZY:
     *  - NO se cargan los pedidos automáticamente al cargar el cliente.
     *  - Se cargarán cuando accedas a getPedidos(), si el EntityManager está abierto.
     *
     * cascade = CascadeType.ALL:
     *  - PERSIST: al persistir Cliente, se persisten también sus pedidos.
     *  - REMOVE: al borrar Cliente, se borran también sus pedidos (si existen).
     *  - MERGE/REFRESH/DETACH también se propagan.
     *
     * orphanRemoval = true:
     *  - si quitas un Pedido de esta lista (y rompes la relación),
     *    Hibernate lo considerará "huérfano" y lo borrará de la BD.
     */
    @OneToMany(mappedBy = "cliente",
            fetch = FetchType.LAZY,
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<Pedido> pedidos = new ArrayList<>();

    public Cliente() { }

    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    // Métodos auxiliares RECOMENDADOS:
    // Mantienen coherente la relación en ambos lados (Cliente <-> Pedido).

    public void addPedido(Pedido p) {
        // 1) Añadimos a la colección del cliente
        pedidos.add(p);
        // 2) Indicamos en el pedido quién es su cliente (lado propietario)
        p.setCliente(this);
    }

    public void removePedido(Pedido p) {
        // 1) Quitamos de la colección
        pedidos.remove(p);
        // 2) Rompemos la relación en el lado propietario
        p.setCliente(null);
    }

    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public List<Pedido> getPedidos() { return pedidos; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Cliente{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
