-- Base de datos para la demo 1-N (Cliente -> Pedido)
DROP DATABASE IF EXISTS demo_jpa_relacion_1an;
CREATE DATABASE demo_jpa_relacion_1an
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

-- Nota:
-- Las tablas se crean automáticamente al ejecutar el proyecto
-- (hibernate.hbm2ddl.auto=update).

