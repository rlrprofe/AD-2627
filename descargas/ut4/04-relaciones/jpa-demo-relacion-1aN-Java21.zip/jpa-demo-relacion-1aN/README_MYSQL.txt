README (Demo JPA/Hibernate 1-N con MySQL)

1) Ejecuta el script de BD:
   src/main/resources/sql/01_crear_bd.sql

2) Lanza la demo:
   mvn -q clean compile exec:java

Qué demuestra:
- Relación 1-N Cliente -> Pedido
- Quién es el propietario (Pedido, porque tiene la FK cliente_id)
- Uso de mappedBy en Cliente
- cascade = ALL (persist/remove en cascada)
- orphanRemoval = true (si quitas un pedido de la lista, se borra en BD)
