DROP DATABASE IF EXISTS mapped_superclass;
CREATE DATABASE mapped_superclass;
USE mapped_superclass;

CREATE TABLE alumno (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    curso VARCHAR(50)
);

CREATE TABLE profesor (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    departamento VARCHAR(50)
);