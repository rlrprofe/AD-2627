package com.ejemplo.mappedsuperclass.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "profesor")
public class Profesor extends PersonaBase {

    private String departamento;

    public Profesor() {}

    public Profesor(String nombre, String departamento) {
        this.nombre = nombre;
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }
}