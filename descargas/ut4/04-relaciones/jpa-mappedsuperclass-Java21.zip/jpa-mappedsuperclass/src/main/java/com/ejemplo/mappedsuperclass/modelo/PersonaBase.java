package com.ejemplo.mappedsuperclass.modelo;

import jakarta.persistence.*;

/**
 * Clase base NO persistente.
 *
 * Se utiliza @MappedSuperclass cuando:
 * - Queremos compartir atributos y mapeos entre varias entidades.
 * - NO queremos que exista una tabla para esta clase.
 * - NO queremos poder hacer consultas JPQL sobre ella.
 *
 * Importante:
 * - Esta clase NO es una entidad.
 * - Hibernate NO crea una tabla para PersonaBase.
 * - Sus atributos se copian en las tablas de las entidades hijas.
 */
@MappedSuperclass
public abstract class PersonaBase {

    /**
     * Identificador común heredado por las entidades hijas.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    /**
     * Atributo común heredado por las entidades hijas.
     */
    protected String nombre;

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }
}