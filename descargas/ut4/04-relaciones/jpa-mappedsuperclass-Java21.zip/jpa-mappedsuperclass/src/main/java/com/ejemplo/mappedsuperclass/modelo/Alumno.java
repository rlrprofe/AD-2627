package com.ejemplo.mappedsuperclass.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "alumno")
public class Alumno extends PersonaBase {

    private String curso;

    public Alumno() {}

    public Alumno(String nombre, String curso) {
        this.nombre = nombre;
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }
}