package com.ejemplo.mappedsuperclass.app;

import com.ejemplo.mappedsuperclass.modelo.*;
import com.ejemplo.mappedsuperclass.util.JPAUtil;
import jakarta.persistence.EntityManager;

public class Main {

    public static void main(String[] args) {

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        em.getTransaction().begin();

        em.persist(new Alumno("Ana", "2 DAM"));
        em.persist(new Profesor("Luis", "Informática"));

        em.getTransaction().commit();
        em.close();

        JPAUtil.close();
    }
}