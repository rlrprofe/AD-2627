# Ejemplo JPA – @MappedSuperclass

Proyecto de ejemplo para mostrar el uso de @MappedSuperclass con JPA, Hibernate y MySQL.

## Características

- PersonaBase NO es una entidad
- NO existe tabla Persona
- Los campos comunes se copian en las tablas hijas

## Ejecución

1. Ejecutar el script SQL en src/main/resources/sql/schema.sql
2. Revisar usuario y contraseña de MySQL
3. Ejecutar Main.java

## Uso recomendado

- Compartir campos comunes
- No usar herencia JPA real