# Proyecto Demo JPA - Herencia JOINED

## Descripción
Proyecto Maven de demostración de la estrategia de herencia **JOINED** en JPA/Hibernate.

- Cada clase tiene su propia tabla
- Modelo relacional normalizado
- Uso de JPAUtil para gestionar EntityManagerFactory

---

## Diagrama de clases

```mermaid
classDiagram
    Persona <|-- Alumno
    Persona <|-- Profesor

    class Persona {
        Long id
        String nombre
    }

    class Alumno {
        String curso
    }

    class Profesor {
        String departamento
    }
```


## Esquema de base de datos

- PERSONA(id, nombre)
- ALUMNO(id, curso)
- PROFESOR(id, departamento)

Las tablas ALUMNO y PROFESOR usan la misma clave primaria que PERSONA.


## Tecnologías
- Java 17
- Maven
- JPA (Jakarta Persistence)
- Hibernate ORM
- MySQL 8


## Ejecución

1. Ejecutar `schema.sql` en MySQL
2. Abrir el proyecto en el IDE
3. Ejecutar `Main.java`
4. Analizar los JOINs generados


## Objetivo didáctico

- Comprender la estrategia JOINED
- Compararla con SINGLE_TABLE
- Analizar normalización vs rendimiento
