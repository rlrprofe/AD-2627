/**
 * Clase principal de la aplicación de demostración.
 *
 * Este ejemplo muestra:
 * - Cómo trabajar con herencia JOINED en JPA/Hibernate.
 * - Cómo usar EntityManager y transacciones correctamente.
 * - Cómo persistir entidades de distintas subclases de forma polimórfica.
 *
 */
package com.ejemplo.herencia.app;

import com.ejemplo.herencia.modelo.*;
import com.ejemplo.herencia.util.JPAUtil;
import jakarta.persistence.EntityManager;

public class Main {

    public static void main(String[] args) {
        /*
         * Obtenemos un EntityManager a partir de la EntityManagerFactory
         * centralizada en la clase JPAUtil.
         *
         * Recordatorio:
         * - La EntityManagerFactory se crea una sola vez.
         * - El EntityManager se crea para cada unidad de trabajo.
         */

        EntityManager em = JPAUtil.getEmf().createEntityManager();


        /*
         * Toda operación que modifique la base de datos
         * (INSERT, UPDATE, DELETE) debe ejecutarse dentro
         * de una transacción.
         */
        em.getTransaction().begin();

         /*
         * Creamos objetos usando referencias del tipo Persona.
         *
         * Esto demuestra el polimorfismo:
         * - a1 es un Alumno
         * - p1 es un Profesor
         * Ambos se manejan como Persona.
         */
        Persona a1 = new Alumno("Ana", "2 DAM");
        Persona p1 = new Profesor("Luis", "Informática");

          /*
         * Persistimos las entidades.
         *
         * En estrategia JOINED, Hibernate ejecuta:
         * 1) Un INSERT en la tabla PERSONA
         * 2) Un INSERT en la tabla específica (ALUMNO o PROFESOR)
         *
         * Todo ello se realiza de forma automática.
         */
        em.persist(a1);
        em.persist(p1);


        /*
         * Confirmamos la transacción.
         *
         * En este punto:
         * - Se ejecutan los INSERT reales en la base de datos.
         * - Las entidades pasan al estado MANAGED.
         */
        em.getTransaction().commit();

        /*
         * Cerramos el EntityManager.
         *
         * A partir de este momento:
         * - Las entidades pasan a estado DETACHED.
         * - No se pueden realizar operaciones lazy.
         */

        em.close();



        /*
         * Cerramos la EntityManagerFactory.
         *
         * En aplicaciones reales:
         * - Esto se haría al apagar la aplicación.
         * - Nunca dentro de un bucle o método repetido.
         */
        JPAUtil.close();
    }
}
