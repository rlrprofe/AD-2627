/**
 * Clase base de la jerarquía de herencia.
 *
 * Esta clase representa el concepto general de Persona y define
 * los atributos comunes a todas las subclases.
 *
 * En esta versión se utiliza la estrategia de herencia JOINED:
 * - Existe una tabla PERSONA con los atributos comunes.
 * - Cada subclase tiene su propia tabla.
 * - Las tablas de las subclases se relacionan con PERSONA
 *   mediante la clave primaria.
 */
package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;

/*
 * Indica que se utiliza la estrategia JOINED.
 *
 * JOINED significa:
 * - La tabla PERSONA almacena los campos comunes.
 * - Cada subclase (Alumno, Profesor) tiene su propia tabla.
 * - Al recuperar una entidad concreta, Hibernate realiza
 *   JOINs entre las tablas necesarias.
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)

public abstract class Persona {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Identificador único de la entidad. Es la clave primaria de la tabla PERSONA.
                                                        // Las tablas de las subclases reutilizan este mismo id como clave primaria y como clave foránea.
    protected Long id;

    protected String nombre; //Atributo común a todas las personas

    public Persona() {} //Constructor por defecto JPA

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }
}
