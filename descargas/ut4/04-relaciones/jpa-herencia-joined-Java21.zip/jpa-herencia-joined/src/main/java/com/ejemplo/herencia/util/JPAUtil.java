
/**
 * Utilidad para crear y reutilizar la EntityManagerFactory.
 *
 * - La EntityManagerFactory se crea una sola vez.
 * - Abrir/cerrar la EMF es costoso.
 * - Se centraliza aquí siguiendo buenas prácticas.
 */
package com.ejemplo.herencia.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public final class JPAUtil {

    private static EntityManagerFactory emf;

    private JPAUtil() {}

    public static EntityManagerFactory getEmf() {
        if (emf == null) {
            emf = Persistence.createEntityManagerFactory("demoPU");
        }
        return emf;
    }

    public static void close() {
        if (emf != null) {
            emf.close();
            emf = null;
        }
    }
}
