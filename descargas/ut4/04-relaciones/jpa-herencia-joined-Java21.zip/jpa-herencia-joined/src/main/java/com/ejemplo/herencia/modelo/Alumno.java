/**
 * Clase Alumno.
 *
 * Representa una especialización de la clase Persona
 * dentro de una jerarquía de herencia con estrategia JOINED.
 *
 * En JOINED:
 * - Existe una tabla ALUMNO.
 * - Esta tabla SOLO contiene los atributos específicos del alumno.
 * - Su clave primaria es también clave foránea que apunta a PERSONA.
 */

package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;

/*
 * @Table no es estrictamente obligatorio si el nombre de la tabla
 * coincide con el de la clase, pero se incluye para dejar claro
 * el mapeo y facilitar la comprensión del alumnado.
 */
@Entity
@Table(name = "alumno")


public class Alumno extends Persona {

    
    
    /*Atributo específico del alumno.
     *
     * - Solo existe en la tabla ALUMNO.
     * - No se repite en la tabla PERSONA.
     * - Permite mantener el modelo relacional normalizado. 
     * */
    private String curso; 

    public Alumno() {}

    public Alumno(String nombre, String curso) {
        super(nombre);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }
}
