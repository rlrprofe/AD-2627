/**
 * Clase Profesor.
 *
 * Representa una especialización de la clase Persona
 * dentro de una jerarquía de herencia con estrategia JOINED.
 *
 * En JOINED:
 * - Existe una tabla PROFESOR.
 * - Esta tabla SOLO contiene los atributos específicos del profesor.
 * - Su clave primaria es también clave foránea que apunta a PERSONA.
 */
package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;

/*
 * @Table se utiliza para dejar explícito el nombre de la tabla
 * y facilitar la lectura del modelo relacional.
 */
@Entity
@Table(name = "profesor")


public class Profesor extends Persona {

    /**
     * Atributo específico del profesor.
     *
     * - Solo existe en la tabla PROFESOR.
     * - No se almacena en la tabla PERSONA.
     * - Permite mantener el modelo relacional normalizado.
     */
    private String departamento;

    public Profesor() {}

    public Profesor(String nombre, String departamento) {
        super(nombre);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }
}
