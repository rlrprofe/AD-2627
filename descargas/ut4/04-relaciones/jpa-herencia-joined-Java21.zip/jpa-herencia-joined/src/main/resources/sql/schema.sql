CREATE DATABASE IF NOT EXISTS herencia_joined;
USE herencia_joined;

CREATE TABLE persona (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE alumno (
    id BIGINT PRIMARY KEY,
    curso VARCHAR(50),
    CONSTRAINT fk_alumno_persona FOREIGN KEY (id) REFERENCES persona(id)
);

CREATE TABLE profesor (
    id BIGINT PRIMARY KEY,
    departamento VARCHAR(50),
    CONSTRAINT fk_profesor_persona FOREIGN KEY (id) REFERENCES persona(id)
);
