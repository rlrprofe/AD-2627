/*
=====================================================
 BASE DE DATOS: herencia_table_per_class
 ESTRATEGIA: TABLE_PER_CLASS
=====================================================

 En esta estrategia:
 - NO existe tabla para la clase base (Persona).
 - Cada subclase tiene su propia tabla.
 - Los atributos comunes se repiten en cada tabla.
 - Hibernate necesita una tabla auxiliar para generar IDs.
*/

/*---------------------------------------------------
 1. Eliminamos la base de datos si existe
---------------------------------------------------*/
DROP DATABASE IF EXISTS herencia_table_per_class;

/*---------------------------------------------------
 2. Creamos la base de datos
---------------------------------------------------*/
CREATE DATABASE herencia_table_per_class
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

/*---------------------------------------------------
 3. Usamos la base de datos
---------------------------------------------------*/
USE herencia_table_per_class;

/*---------------------------------------------------
 4. Tabla auxiliar para generación de identificadores
---------------------------------------------------

 Esta tabla es OBLIGATORIA en TABLE_PER_CLASS.

 Hibernate la utiliza para:
 - Guardar el último ID generado.
 - Asegurar que los identificadores son únicos
   entre todas las subclases.

 Sin esta tabla:
 - La aplicación NO ARRANCA.
*/
CREATE TABLE hibernate_ids (
    gen_name  VARCHAR(50) PRIMARY KEY,
    gen_value BIGINT
);

/*---------------------------------------------------
 5. Inicializamos el generador de IDs
---------------------------------------------------

 gen_name = 'persona'
 coincide con pkColumnValue del @TableGenerator
*/
INSERT INTO hibernate_ids (gen_name, gen_value)
VALUES ('persona', 0);

/*---------------------------------------------------
 6. Tabla ALUMNO
---------------------------------------------------

 Contiene:
 - Atributos comunes (id, nombre)
 - Atributos específicos (curso)
*/
CREATE TABLE alumno (
    id BIGINT PRIMARY KEY,
    nombre VARCHAR(100),
    curso VARCHAR(50)
);

/*---------------------------------------------------
 7. Tabla PROFESOR
---------------------------------------------------

 Contiene:
 - Atributos comunes (id, nombre)
 - Atributos específicos (departamento)
*/
CREATE TABLE profesor (
    id BIGINT PRIMARY KEY,
    nombre VARCHAR(100),
    departamento VARCHAR(50)
);
