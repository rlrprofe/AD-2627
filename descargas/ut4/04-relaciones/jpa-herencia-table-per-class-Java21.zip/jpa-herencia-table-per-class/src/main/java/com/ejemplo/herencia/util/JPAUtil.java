package com.ejemplo.herencia.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Utilidad para gestionar la EntityManagerFactory.
 */
public final class JPAUtil {

    private static EntityManagerFactory emf;

    private JPAUtil() {}

    public static EntityManagerFactory getEmf() {
        if (emf == null) {
            emf = Persistence.createEntityManagerFactory("demoPU");
        }
        return emf;
    }

    public static void close() {
        if (emf != null) {
            emf.close();
            emf = null;
        }
    }
}
