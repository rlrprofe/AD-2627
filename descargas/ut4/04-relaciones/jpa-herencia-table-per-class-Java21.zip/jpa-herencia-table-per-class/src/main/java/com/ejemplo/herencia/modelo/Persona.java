/**
 * Clase base de la jerarquía.
 *
 * Estrategia TABLE_PER_CLASS:
 * - NO existe una tabla para Persona.
 * - Cada subclase tiene su propia tabla completa.
 * - Los atributos comunes se repiten en cada tabla.
 */
package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;

/*
 * @Inheritance con estrategia JOINED indica que:
 * - La clase base tiene su propia tabla.
 * - Cada subclase tendrá una tabla adicional.
 * - Hibernate realizará JOINs automáticos al recuperar entidades.
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Persona {

    /**
     * Identificador de la entidad.
     *
     * IMPORTANTE:
     * En TABLE_PER_CLASS Hibernate NO permite usar:
     * - GenerationType.IDENTITY
     * - GenerationType.AUTO
     *
     * Motivo:
     * - No existe una tabla común donde generar los IDs.
     *
     * SOLUCIÓN:
     * - Usar GenerationType.TABLE con una tabla auxiliar
     * que almacena el último identificador usado.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "persona_gen")
    @TableGenerator(name = "persona_gen", //nombre del generador.
                    table = "hibernate_ids", //Indica el nombre de la tabla que Hibernate utilizará para generar los identificadores.Solo almacena contadores numéricos.
                    pkColumnName = "gen_name", //Indica el nombre de la columna que identifica el generador dentro de la tabla.
                    valueColumnName = "gen_value", //Indica la columna donde se almacena el valor del identificador.
                    pkColumnValue = "persona", //Es el valor identificador del generador dentro de la tabla.
                    allocationSize = 1) //ncrementa el identificador de uno en uno.
    
    /** La anotación @TableGenerator se utiliza para definir un generador de identificadores basado en una tabla de la base de datos.
    ** En el caso de la estrategia TABLE_PER_CLASS, este generador es necesario para asegurar que los identificadores sean únicos 
    ** en toda la jerarquía de herencia.**/
    
    protected Long id;










    /**
     * Atributo común.
     *
     * Se repite en todas las tablas de las subclases.
     */
    protected String nombre;

    public Persona() {
    }

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }
}
