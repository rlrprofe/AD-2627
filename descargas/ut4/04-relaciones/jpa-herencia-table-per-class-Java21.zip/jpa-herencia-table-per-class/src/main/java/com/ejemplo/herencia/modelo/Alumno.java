/**
 * Clase Alumno.
 *
 * Representa una especialización de la clase Persona
 * dentro de una jerarquía de herencia con estrategia JOINED.
 *
 * En JOINED:
 * - Existe una tabla ALUMNO.
 * - Esta tabla SOLO contiene los atributos específicos del alumno.
 * - Su clave primaria es también clave foránea que apunta a PERSONA.
 */

package com.ejemplo.herencia.modelo;

import jakarta.persistence.*;

/*
 * @Table se utiliza para dejar explícito el nombre de la tabla y facilitar la comprensión del modelo relacional.
 */
@Entity
@Table(name = "alumno")
public class Alumno extends Persona {

    /**
     * Atributo específico del alumno.
     *
     * Características:
     * - Solo se almacena en la tabla ALUMNO.
     * - No se duplica en la tabla PERSONA.
     * - Permite mantener el modelo relacional normalizado.
     */
    private String curso;

    public Alumno() {}

    public Alumno(String nombre, String curso) {
        super(nombre);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }
}
