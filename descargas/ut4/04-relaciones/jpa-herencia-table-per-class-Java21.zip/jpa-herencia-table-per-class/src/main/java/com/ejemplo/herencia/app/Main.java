package com.ejemplo.herencia.app;

import com.ejemplo.herencia.modelo.*;
import com.ejemplo.herencia.util.JPAUtil;
import jakarta.persistence.EntityManager;

/**
 * Demo de herencia con estrategia TABLE_PER_CLASS.
 */
public class Main {

    public static void main(String[] args) {

        EntityManager em = JPAUtil.getEmf().createEntityManager();
        em.getTransaction().begin();

        /*
         * Persistimos entidades de distintas subclases.
         *
         * En TABLE_PER_CLASS:
         * - Cada entidad se inserta en SU PROPIA tabla.
         * - No existe tabla PERSONA.
         */
        Persona a1 = new Alumno("Ana", "2 DAM");
        Persona p1 = new Profesor("Luis", "Informática");

        em.persist(a1);
        em.persist(p1);

        em.getTransaction().commit();

        em.close();
        JPAUtil.close();
    }
}
