# Proyecto Demo JPA - Herencia TABLE_PER_CLASS

## Descripción
Proyecto Maven de demostración de la estrategia de herencia **TABLE_PER_CLASS** en JPA/Hibernate.

- Cada subclase tiene su propia tabla completa
- No existe tabla para la clase base
- Los atributos comunes se duplican


## Diagrama de clases

```mermaid
classDiagram
    Persona <|-- Alumno
    Persona <|-- Profesor
```


## Esquema de base de datos

- ALUMNO(id, nombre, curso)
- PROFESOR(id, nombre, departamento)



## Tecnologías
- Java 17
- Maven
- JPA (Jakarta Persistence)
- Hibernate ORM
- MySQL 8


## Ejecución

1. Ejecutar `schema.sql` en MySQL
2. Abrir el proyecto en el IDE
3. Ejecutar `Main.java`
4. Analizar las tablas creadas


## Observaciones didácticas

- TABLE_PER_CLASS no está normalizada
- Consultas polimórficas son más costosas
- Estrategia poco usada en proyectos reales
