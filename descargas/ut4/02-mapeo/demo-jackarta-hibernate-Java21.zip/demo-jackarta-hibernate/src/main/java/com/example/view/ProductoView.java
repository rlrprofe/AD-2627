package com.example.view;

import com.example.model.Producto;

import java.util.List;

/**
 * VISTA del submenú de Productos.
 * - Muestra el menú de productos.
 * - Muestra listados de productos.
 */
public class ProductoView {

    public void mostrarMenu() {
        System.out.println("\n--- PRODUCTOS ---");
        System.out.println("1. Alta");
        System.out.println("2. Listar");
        System.out.println("3. Eliminar");
        System.out.println("0. Volver");
    }

    /**
     * Muestra un listado de productos.
     */
    public void mostrarListado(List<Producto> productos) {
        System.out.println("\nListado de productos:");

        if (productos == null || productos.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }

        for (Producto p : productos) {
            System.out.println(" - " + p);
        }
    }
}
