package com.example.controller;

import com.example.service.ClienteService;
import com.example.util.ConsoleUtil;
import com.example.view.ClienteView;

/**
 * CONTROLADOR (MVC)
 * - Gestiona el flujo del menú de clientes.
 * - No accede directamente a la base de datos:
 *     - delega en la capa Service (ClienteService)
 * - No imprime “bonito” por sí mismo:
 *     - delega en la capa View (ClienteView)
 *
 * Responsabilidad:
 * - Leer opciones del usuario
 * - Llamar a la lógica (Service)
 * - Pedir a la Vista que muestre resultados
 */
public class ClienteController {

    // Capa de servicio: encapsula casos de uso (alta, listado, etc.)
    private final ClienteService service = new ClienteService();

    // Vista: presenta menús y listados por consola
    private final ClienteView view = new ClienteView();

    /**
     * Bucle principal del submenú de clientes.
     * Se ejecuta hasta que el usuario elige "0. Volver".
     */
    public void ejecutar() {

        int opcion;

        do {
            // 1) Mostramos el menú (Vista)
            view.mostrarMenu();

            // 2) Leemos opción validada (0..3)
            opcion = ConsoleUtil.leerEnteroEntre("Opción: ", 0, 3);

            // 3) Ejecutamos la opción seleccionada
            if (opcion == 1) {
                // ALTA
                altaCliente();

            } else if (opcion == 2) {
                // LISTAR
                listarClientes();

            } else if (opcion == 3) {
                // ELIMINAR
                eliminarCliente();
            }

            // Si opción == 0, sale del bucle y vuelve al menú principal
        } while (opcion != 0);
    }

    /**
     * Caso de uso: Alta de cliente.
     * - Pide datos al usuario
     * - Llama al service para persistir
     * - Muestra resultado
     */
    private void altaCliente() {
        String nombre = ConsoleUtil.leerNoVacio("Nombre: ");
        String email = ConsoleUtil.leerEmail("Email: ");

        // Service crea la entidad y delega en DAO para persistir
        Integer id = service.alta(nombre, email);

        System.out.println("Cliente creado con id: " + id);
    }

    /**
     * Caso de uso: Listar clientes.
     * - Recupera lista desde Service
     * - La pasa a la Vista para mostrarla
     */
    private void listarClientes() {
        view.mostrarListado(service.listar());
    }

    /**
     * Caso de uso: Eliminar cliente por id.
     * - Pide id al usuario
     * - Llama al service
     * - Informa del resultado
     */
    private void eliminarCliente() {
        int id = ConsoleUtil.leerEntero("Id cliente: ");
        boolean ok = service.eliminar(id);

        System.out.println(ok ? "Cliente eliminado." : "No existe ese cliente.");
    }
}

