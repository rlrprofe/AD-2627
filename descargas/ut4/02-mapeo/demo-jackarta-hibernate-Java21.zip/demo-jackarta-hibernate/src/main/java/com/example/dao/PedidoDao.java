package com.example.dao;

import com.example.model.Cliente;
import com.example.model.Pedido;
import com.example.model.Producto;
import com.example.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * DAO para Pedido.
 *
 * Puntos clave:
 * - El Pedido tiene relaciones (cliente, productos).
 * - Debemos crear el pedido usando un único EntityManager y una única transacción.
 * - Para listar con detalle (productos) necesitamos JOIN FETCH (evitar LAZY error).
 */
public class PedidoDao {

    /**
     * Crea un pedido para un cliente, añadiendo productos por id.
     *
     * Reglas de esta práctica:
     * - Si el cliente no existe -> devolver null
     * - Si algún producto no existe -> simplemente se ignora (no se añade)
     *
     * Importante:
     * - Se hace todo con el MISMO EntityManager dentro de la transacción,
     *   para que Cliente y Productos queden asociados correctamente al Pedido.
     *
     * @return id del pedido creado o null si el cliente no existe
     */
    public Integer crearPedido(int clienteId, List<Integer> idsProductos) {

        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // 1) Buscar cliente (managed dentro de este EntityManager)
            Cliente cliente = em.find(Cliente.class, clienteId);
            if (cliente == null) {
                tx.commit();
                return null;
            }

            // 2) Crear pedido asociado al cliente
            Pedido pedido = new Pedido(cliente);

            // 3) Buscar y añadir productos
            if (idsProductos != null) {
                for (Integer idProd : idsProductos) {
                    if (idProd != null) {
                        Producto prod = em.find(Producto.class, idProd);
                        if (prod != null) {
                            pedido.addProducto(prod);
                        }
                    }
                }
            }

            // 4) Persistir pedido
            // Gracias al @ManyToMany, al persistir el Pedido se insertará:
            // - fila en pedidos
            // - filas en pedidos_productos (tabla intermedia) para cada producto asociado
            em.persist(pedido);

            tx.commit();

            return pedido.getId();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }

    /**
     * Lista pedidos de forma simple (sin forzar carga de productos).
     *
     * Esta opción es útil para evitar problemas LAZY y mostrar el "Pedido básico".
     */
    public List<Pedido> listar() {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("FROM Pedido", Pedido.class).getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Lista pedidos con sus productos y cliente en la misma consulta.
     *
     * ¿Por qué?
     * - p.productos está marcado como LAZY.
     * - Si cerramos el EntityManager y luego intentamos imprimir productos, fallará.
     * - JOIN FETCH fuerza la carga dentro de la consulta, antes de cerrar.
     *
     * - distinct evita pedidos duplicados por el join N:M.
     */
    public List<Pedido> listarConProductos() {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery(
                "select distinct p from Pedido p " +
                "left join fetch p.productos " +
                "left join fetch p.cliente",
                Pedido.class
            ).getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Elimina un pedido por id.
     *
     * Nota didáctica:
     * - En un N:M, eliminar el pedido suele eliminar la fila de pedidos
     *   y las filas correspondientes en la tabla intermedia.
     * - Si hubiera restricciones especiales, podría requerir más control.
     */
    public boolean eliminarPorId(int id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Pedido p = em.find(Pedido.class, id);
            if (p == null) {
                tx.commit();
                return false;
            }

            em.remove(p);
            tx.commit();
            return true;

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }
}
