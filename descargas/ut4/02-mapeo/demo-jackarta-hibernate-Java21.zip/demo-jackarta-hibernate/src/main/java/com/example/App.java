package com.example;

import com.example.controller.ClienteController;
import com.example.controller.PedidoController;
import com.example.controller.ProductoController;
import com.example.util.ConsoleUtil;
import com.example.util.JPAUtil;
import com.example.view.MenuView;

/**
 * Punto de entrada de la aplicación (main).
 *
 * Responsabilidad:
 * - Mostrar el menú principal (usando la Vista)
 * - Leer la opción elegida (ConsoleUtil)
 * - Delegar el flujo a cada Controller
 * - Cerrar recursos al finalizar (EntityManagerFactory)
 */
public class App {

    public static void main(String[] args) {

        // Vista del menú principal (solo imprime opciones)
        MenuView menuView = new MenuView();

        // Controladores (gestionan el flujo de cada apartado)
        ClienteController clienteController = new ClienteController();
        ProductoController productoController = new ProductoController();
        PedidoController pedidoController = new PedidoController();

        int opcion;

        // Bucle principal
        do {
            menuView.mostrarMenuPrincipal();

            // Leemos opción validada (0..3)
            opcion = ConsoleUtil.leerEnteroEntre("Opción: ", 0, 3);

            // Delegamos al controlador correspondiente
            if (opcion == 1) {
                clienteController.ejecutar();

            } else if (opcion == 2) {
                productoController.ejecutar();

            } else if (opcion == 3) {
                pedidoController.ejecutar();
            }

            // Si opción == 0, termina el bucle y se cierra la app
        } while (opcion != 0);

        // Cerrar EntityManagerFactory al finalizar (libera recursos del provider)
        JPAUtil.close();

        System.out.println("Fin del programa.");
    }
}

