package com.example.model;

import jakarta.persistence.*;

/**
 * Entidad JPA que representa la tabla "productos".
 */
@Entity
@Table(name = "productos")
public class Producto {

    /**
     * Clave primaria autogenerada (AUTO_INCREMENT en MySQL).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * Nombre del producto.
     * nullable=false -> NOT NULL
     * length=120 -> VARCHAR(120)
     */
    @Column(nullable = false, length = 120)
    private String nombre;

    /**
     * Precio del producto.
     * nullable=false -> NOT NULL
     * (El tipo SQL exacto lo decide el provider; para prácticas es suficiente).
     */
    @Column(nullable = false)
    private double precio;

    public Producto() { }

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    @Override
    public String toString() {
        return "Producto{id=" + id + ", nombre='" + nombre + "', precio=" + precio + "}";
    }
}
