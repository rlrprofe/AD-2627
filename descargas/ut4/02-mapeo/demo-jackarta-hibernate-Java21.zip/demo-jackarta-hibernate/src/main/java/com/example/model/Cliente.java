package com.example.model;

import jakarta.persistence.*;

/**
 * Entidad JPA que representa la tabla "clientes".
 * Cada objeto Cliente <-> una fila en la tabla.
 */
@Entity
// @Table permite personalizar el nombre de la tabla y sus restricciones
@Table(
    name = "clientes",
    // Restricción UNIQUE a nivel BD para el email (evita duplicados)
    uniqueConstraints = @UniqueConstraint(
        name = "UK_clientes_email",
        columnNames = "email"
    )
)
public class Cliente {

    /**
     * @Id indica que este campo es la clave primaria (PRIMARY KEY).
     * @GeneratedValue indica que el valor lo genera la BD automáticamente.
     * IDENTITY se corresponde con AUTO_INCREMENT en MySQL.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * @Column configura la columna:
     * - nullable=false -> NOT NULL en BD
     * - length=100 -> tamaño de VARCHAR
     */
    @Column(nullable = false, length = 100)
    private String nombre;

    /**
     * Columna email:
     * - NOT NULL
     * - tamaño máximo 120
     * La unicidad la impone la @UniqueConstraint de @Table.
     */
    @Column(nullable = false, length = 120)
    private String email;

    // Constructor vacío obligatorio para JPA
    public Cliente() { }

    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Cliente{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
