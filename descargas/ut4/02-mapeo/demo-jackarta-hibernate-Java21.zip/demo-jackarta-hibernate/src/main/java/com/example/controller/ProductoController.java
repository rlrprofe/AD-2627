package com.example.controller;

import com.example.service.ProductoService;
import com.example.util.ConsoleUtil;
import com.example.view.ProductoView;

/**
 * CONTROLADOR (MVC) para Productos
 * - Gestiona el submenú de productos.
 * - Orquesta entrada/salida: ConsoleUtil + View
 * - Delegación de lógica y persistencia: Service -> DAO
 */
public class ProductoController {

    private final ProductoService service = new ProductoService();
    private final ProductoView view = new ProductoView();

    /**
     * Bucle del submenú de productos.
     * Opciones:
     * 1 Alta, 2 Listar, 3 Eliminar, 0 Volver
     */
    public void ejecutar() {

        int opcion;

        do {
            view.mostrarMenu();
            opcion = ConsoleUtil.leerEnteroEntre("Opción: ", 0, 3);

            if (opcion == 1) {
                altaProducto();

            } else if (opcion == 2) {
                listarProductos();

            } else if (opcion == 3) {
                eliminarProducto();
            }

        } while (opcion != 0);
    }

    /**
     * Alta de producto:
     * - Pide nombre y precio
     * - Persiste usando Service
     */
    private void altaProducto() {
        String nombre = ConsoleUtil.leerNoVacio("Nombre: ");
        double precio = ConsoleUtil.leerDouble("Precio: ");

        Integer id = service.alta(nombre, precio);
        System.out.println("Producto creado con id: " + id);
    }

    /**
     * Listado de productos.
     */
    private void listarProductos() {
        view.mostrarListado(service.listar());
    }

    /**
     * Eliminación por id.
     */
    private void eliminarProducto() {
        int id = ConsoleUtil.leerEntero("Id producto: ");
        boolean ok = service.eliminar(id);

        System.out.println(ok ? "Producto eliminado." : "No existe ese producto.");
    }
}
