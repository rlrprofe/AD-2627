package com.example.service;

import com.example.dao.ProductoDao;
import com.example.model.Producto;

import java.util.List;

/**
 * SERVICE para Producto.
 *
 * Misma filosofía:
 * - casos de uso
 * - validaciones/reglas (si procede)
 * - delegación a DAO
 */
public class ProductoService {

    private final ProductoDao dao = new ProductoDao();

    /**
     * Alta de producto.
     *
     * Aquí podrías añadir reglas como:
     * - precio > 0
     * - nombre no vacío
     * En esta práctica ya se controla parte en ConsoleUtil.
     */
    public Integer alta(String nombre, double precio) {

        // Ejemplo de regla simple (opcional):
        // si precio <= 0, podrías lanzar excepción o corregir.
        // Para no complicar al alumnado, lo dejamos como está.

        Producto p = new Producto(nombre, precio);
        return dao.insertar(p);
    }

    /**
     * Listado de productos.
     */
    public List<Producto> listar() {
        return dao.listar();
    }

    /**
     * Buscar producto por id.
     */
    public Producto buscar(int id) {
        return dao.buscarPorId(id);
    }

    /**
     * Eliminar producto por id.
     */
    public boolean eliminar(int id) {
        return dao.eliminarPorId(id);
    }

    /**
     * Actualizar producto (preparado para ampliación).
     */
    public void actualizar(Producto p) {
        dao.actualizar(p);
    }
}
