package com.example.controller;

import com.example.service.PedidoService;
import com.example.util.ConsoleUtil;
import com.example.view.PedidoView;

import java.util.ArrayList;
import java.util.List;

/**
 * CONTROLADOR (MVC) para Pedidos
 * Aquí es donde más se ve la “orquestación”:
 * - Para crear un pedido necesitamos:
 *   1) id de cliente
 *   2) varios ids de productos
 *
 * Nota didáctica:
 * - Para listar pedidos “con productos” usamos un método especial en el DAO
 *   con JOIN FETCH (listarConProductos), para evitar problemas de LAZY.
 */
public class PedidoController {

    private final PedidoService service = new PedidoService();
    private final PedidoView view = new PedidoView();

    /**
     * Submenú de pedidos.
     * Incluimos dos listados:
     * - simple (sin productos)
     * - con productos (JOIN FETCH)
     *
     * Esto permite explicar LAZY de forma práctica.
     */
    public void ejecutar() {

        int opcion;

        do {
            view.mostrarMenu();
            opcion = ConsoleUtil.leerEnteroEntre("Opción: ", 0, 4);

            if (opcion == 1) {
                crearPedido();

            } else if (opcion == 2) {
                // Listado simple: no muestra productos (evita LAZY)
                view.mostrarListadoSimple(service.listar());

            } else if (opcion == 3) {
                // Listado con detalle: usa JOIN FETCH para cargar productos dentro del DAO
                view.mostrarListadoConDetalle(service.listarConProductos());

            } else if (opcion == 4) {
                eliminarPedido();
            }

        } while (opcion != 0);
    }

    /**
     * Caso de uso: crear pedido.
     * Flujo:
     * 1) pedir id de cliente
     * 2) pedir lista de ids de producto hasta que se introduzca 0
     * 3) llamar al service para crear el pedido
     */
    private void crearPedido() {
        int clienteId = ConsoleUtil.leerEntero("Id del cliente: ");

        // Vamos almacenando ids de productos en una lista
        System.out.println("Introduce ids de productos (0 para terminar):");
        List<Integer> idsProductos = new ArrayList<>();

        int idProd;
        do {
            idProd = ConsoleUtil.leerEntero("Id producto: ");
            if (idProd != 0) {
                idsProductos.add(idProd);
            }
        } while (idProd != 0);

        // Service delega en DAO. Devuelve:
        // - null si no existe el cliente
        // - id del pedido si se creó correctamente
        Integer pedidoId = service.crearPedido(clienteId, idsProductos);

        if (pedidoId == null) {
            System.out.println("No existe ese cliente.");
        } else {
            System.out.println("Pedido creado con id: " + pedidoId);
        }
    }

    /**
     * Caso de uso: eliminar pedido.
     */
    private void eliminarPedido() {
        int id = ConsoleUtil.leerEntero("Id pedido: ");
        boolean ok = service.eliminar(id);

        System.out.println(ok ? "Pedido eliminado." : "No existe ese pedido.");
    }
}
