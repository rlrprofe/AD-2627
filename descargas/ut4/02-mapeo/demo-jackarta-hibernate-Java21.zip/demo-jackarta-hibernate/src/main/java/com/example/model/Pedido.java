package com.example.model;

import jakarta.persistence.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Entidad JPA que representa la tabla "pedidos".
 * Incluye relaciones:
 * - N:1 con Cliente (muchos pedidos pertenecen a un cliente)
 * - N:M con Producto (un pedido tiene varios productos y un producto puede estar en varios pedidos)
 */
@Entity
@Table(name = "pedidos")
public class Pedido {

    /**
     * Clave primaria autogenerada (AUTO_INCREMENT).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * Fecha del pedido.
     * @Temporal se usa con java.util.Date para indicar si queremos DATE o TIMESTAMP.
     * TIMESTAMP incluye fecha + hora.
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    private Date fecha;

    /**
     * Total del pedido.
     */
    @Column(nullable = false)
    private double total;

    /**
     * Relación N:1 (ManyToOne):
     * Muchos pedidos -> un cliente.
     *
     * fetch=LAZY:
     *   El cliente no se carga automáticamente; se carga cuando se accede a getCliente().
     *   Es más eficiente en listados.
     *
     * optional=false:
     *   Indica que el pedido debe tener siempre cliente (no puede ser null).
     *
     * @JoinColumn:
     *   Define la columna FK en la tabla "pedidos" (cliente_id).
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
        name = "cliente_id",
        nullable = false,
        foreignKey = @ForeignKey(name = "FK_pedidos_clientes")
    )
    private Cliente cliente;

    /**
     * Relación N:M (ManyToMany):
     * Un pedido puede tener muchos productos y un producto puede estar en muchos pedidos.
     *
     * fetch=LAZY:
     *   La colección de productos NO se carga hasta que se accede a ella.
     *
     * @JoinTable:
     *   Define la tabla intermedia "pedidos_productos" y sus columnas:
     *   - pedido_id (FK a pedidos)
     *   - producto_id (FK a productos)
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "pedidos_productos",
        joinColumns = @JoinColumn(name = "pedido_id"),
        inverseJoinColumns = @JoinColumn(name = "producto_id")
    )
    private Set<Producto> productos = new HashSet<>();

    public Pedido() { }

    public Pedido(Cliente cliente) {
        this.cliente = cliente;
        this.fecha = new Date();
        this.total = 0.0;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Set<Producto> getProductos() { return productos; }
    public void setProductos(Set<Producto> productos) { this.productos = productos; }

    /**
     * Añade un producto al pedido y actualiza el total.
     * Nota: en un proyecto real, el total se calcularía con más control (cantidades, impuestos, etc.).
     */
    public void addProducto(Producto p) {
        if (p != null) {
            productos.add(p);
            total += p.getPrecio();
        }
    }

    @Override
    public String toString() {
        // Importante: no acceder aquí a productos.size() porque productos es LAZY.
        // Si el EntityManager está cerrado, daría un error de inicialización diferida.
        return "Pedido{id=" + id + ", fecha=" + fecha + ", total=" + total +
               ", clienteId=" + (cliente != null ? cliente.getId() : null) + "}";
    }
}
