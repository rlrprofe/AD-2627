package com.example.view;

/**
 * VISTA (MVC) del menú principal.
 *
 * Responsabilidad:
 * - Mostrar por consola las opciones del menú principal.
 *
 * Importante:
 * - La Vista NO accede a BD.
 * - La Vista NO contiene lógica de negocio.
 * - Solo presenta información (texto, listados, mensajes).
 */
public class MenuView {

    public void mostrarMenuPrincipal() {
        System.out.println("\n=== TIENDA ORM (JPA + Hibernate) ===");
        System.out.println("1. Gestión de clientes");
        System.out.println("2. Gestión de productos");
        System.out.println("3. Gestión de pedidos");
        System.out.println("0. Salir");
    }
}
