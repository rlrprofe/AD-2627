package com.example.service;

import com.example.dao.PedidoDao;
import com.example.model.Pedido;

import java.util.List;

/**
 * SERVICE para Pedido.
 *
 * Es especialmente útil porque el caso de uso "crear pedido"
 * implica varias decisiones y validaciones posibles:
 * - el cliente debe existir
 * - los productos deben existir
 * - el pedido debe tener al menos 1 producto (regla opcional)
 *
 * En este ejemplo:
 * - si el cliente no existe, devolvemos null (DAO lo implementa así)
 * - productos inexistentes se ignoran
 *
 * Si quisieras “subir nivel”, aquí sería el sitio natural para imponer reglas:
 * - "no permitir pedido sin productos"
 * - "no permitir total = 0"
 * - etc.
 */
public class PedidoService {

    private final PedidoDao dao = new PedidoDao();

    /**
     * Caso de uso: crear pedido.
     *
     * @param clienteId id del cliente
     * @param idsProductos lista de ids de productos seleccionados
     * @return id del pedido creado, o null si el cliente no existe
     */
    public Integer crearPedido(int clienteId, List<Integer> idsProductos) {

        // En un proyecto real, podríamos validar aquí:
        // - idsProductos no vacío
        // - no duplicados
        // - etc.
        // Para prácticas, delegamos directamente.
        return dao.crearPedido(clienteId, idsProductos);
    }

    /**
     * Listado simple (sin productos).
     * Útil para explicar el problema LAZY.
     */
    public List<Pedido> listar() {
        return dao.listar();
    }

    /**
     * Listado con productos y cliente cargados (JOIN FETCH).
     * Esto permite imprimir detalles sin LazyInitializationException.
     */
    public List<Pedido> listarConProductos() {
        return dao.listarConProductos();
    }

    /**
     * Eliminar pedido por id.
     */
    public boolean eliminar(int id) {
        return dao.eliminarPorId(id);
    }

    /**
     * (Opcional) Buscar pedido por id.
     * No lo usamos en el menú, pero se deja para ampliación.
     */
    public Pedido buscar(int id) {
        // No tenemos método en DAO ahora mismo; se podría añadir si lo necesitas.
        // return dao.buscarPorId(id);
        return null;
    }
}
