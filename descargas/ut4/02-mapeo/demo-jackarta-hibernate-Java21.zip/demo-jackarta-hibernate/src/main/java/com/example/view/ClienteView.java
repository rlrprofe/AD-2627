package com.example.view;

import com.example.model.Cliente;

import java.util.List;

/**
 * VISTA del submenú de Clientes.
 * - Muestra el menú de clientes.
 * - Muestra listados de clientes.
 */
public class ClienteView {

    public void mostrarMenu() {
        System.out.println("\n--- CLIENTES ---");
        System.out.println("1. Alta");
        System.out.println("2. Listar");
        System.out.println("3. Eliminar");
        System.out.println("0. Volver");
    }

    /**
     * Muestra un listado de clientes de forma legible.
     */
    public void mostrarListado(List<Cliente> clientes) {
        System.out.println("\nListado de clientes:");

        if (clientes == null || clientes.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }

        for (Cliente c : clientes) {
            System.out.println(" - " + c);
        }
    }
}
