package com.example.util;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * UTILIDAD DE CONSOLA
 *
 * Objetivo:
 * - Centralizar lectura de datos por consola con validación básica.
 * - Evitar repetir código en Views/Controllers.
 *
 * Decisiones de diseño (didácticas):
 * - Usamos un único Scanner estático para toda la aplicación.
 *   (En consola es habitual; evita problemas de cerrar System.in.)
 * - Validamos:
 *   - enteros
 *   - enteros en rango
 *   - doubles
 *   - cadenas no vacías
 *   - email con regex simple (nivel básico)
 */
public class ConsoleUtil {

    // Scanner único para toda la aplicación (System.in)
    private static final Scanner SC = new Scanner(System.in);

    /**
     * Regex de email básica (no pretende validar todos los emails reales).
     * Solo comprueba que tenga: texto@texto.punto
     */
    private static final Pattern EMAIL_BASIC =
            Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    private ConsoleUtil() {
        // Constructor privado para impedir instanciación
    }

    /**
     * Lee un entero, repitiendo hasta que el usuario introduzca un valor correcto.
     */
    public static int leerEntero(String prompt) {
        Integer n = null;

        while (n == null) {
            System.out.print(prompt);
            String line = SC.nextLine().trim();

            try {
                n = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debes introducir un número entero.");
            }
        }

        return n;
    }

    /**
     * Lee un entero entre min y max (ambos inclusive).
     * Útil para validar opciones de menú.
     */
    public static int leerEnteroEntre(String prompt, int min, int max) {
        Integer n = null;

        while (n == null) {
            int v = leerEntero(prompt);

            if (v < min || v > max) {
                System.out.println("Opción no válida. Debe estar entre " + min + " y " + max + ".");
            } else {
                n = v;
            }
        }

        return n;
    }

    /**
     * Lee un double, repitiendo hasta que sea correcto.
     * Admite coma o punto (se reemplaza la coma por punto).
     */
    public static double leerDouble(String prompt) {
        Double d = null;

        while (d == null) {
            System.out.print(prompt);
            String line = SC.nextLine().trim().replace(',', '.');

            try {
                d = Double.parseDouble(line);
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debes introducir un número (ej.: 12.5).");
            }
        }

        return d;
    }

    /**
     * Lee una cadena no vacía (no permite blanco).
     */
    public static String leerNoVacio(String prompt) {
        String s = "";

        while (s.isBlank()) {
            System.out.print(prompt);
            s = SC.nextLine().trim();

            if (s.isBlank()) {
                System.out.println("No puede estar vacío.");
            }
        }

        return s;
    }

    /**
     * Lee un email con validación básica por regex.
     * Repite hasta que el formato sea válido.
     */
    public static String leerEmail(String prompt) {
        String email = "";

        while (email.isBlank() || !EMAIL_BASIC.matcher(email).matches()) {
            System.out.print(prompt);
            email = SC.nextLine().trim();

            if (!EMAIL_BASIC.matcher(email).matches()) {
                System.out.println("Email no válido (validación básica).");
            }
        }

        return email;
    }
}

