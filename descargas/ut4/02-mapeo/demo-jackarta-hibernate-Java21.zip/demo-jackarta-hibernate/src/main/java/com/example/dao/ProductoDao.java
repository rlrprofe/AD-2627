package com.example.dao;

import com.example.model.Producto;
import com.example.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * DAO para Producto.
 * Mismo patrón CRUD que ClienteDao.
 */
public class ProductoDao {

    /**
     * Inserta un producto y devuelve el id generado.
     */
    public Integer insertar(Producto p) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            em.persist(p);
            tx.commit();
            return p.getId();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }

    /**
     * Busca producto por id (o null si no existe).
     */
    public Producto buscarPorId(int id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.find(Producto.class, id);
        } finally {
            em.close();
        }
    }

    /**
     * Lista todos los productos.
     */
    public List<Producto> listar() {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("FROM Producto", Producto.class).getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Actualiza producto (merge).
     */
    public void actualizar(Producto p) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            em.merge(p);
            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }

    /**
     * Elimina producto por id.
     * @return true si existía y se eliminó
     */
    public boolean eliminarPorId(int id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Producto p = em.find(Producto.class, id);
            if (p == null) {
                tx.commit();
                return false;
            }

            em.remove(p);
            tx.commit();
            return true;

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }
}
