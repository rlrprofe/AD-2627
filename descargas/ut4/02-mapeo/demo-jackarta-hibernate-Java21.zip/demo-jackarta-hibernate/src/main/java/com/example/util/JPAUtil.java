package com.example.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * UTILIDAD JPA
 *
 * Objetivo:
 * - Crear y reutilizar un único EntityManagerFactory durante toda la ejecución.
 *
 * Conceptos clave:
 * - EntityManagerFactory (EMF) es "pesado":
 *     - carga configuración de persistence.xml
 *     - prepara el provider (Hibernate)
 *     - puede inicializar metadatos, conexiones, etc.
 *   Por eso se crea una sola vez (patrón singleton simple).
 *
 * - EntityManager (EM) NO se gestiona aquí:
 *     - El EM es ligero y de ciclo corto (se crea/cierra por operación en los DAO).
 */
public class JPAUtil {

    // Instancia única (singleton) de la fábrica de EntityManagers
    private static EntityManagerFactory emf;

    private JPAUtil() {
        // Constructor privado: evita que se creen objetos JPAUtil
    }

    /**
     * Devuelve la EntityManagerFactory, creándola si aún no existe.
     *
     * IMPORTANTE:
     * - "tiendaPU" debe coincidir con el name del <persistence-unit> en persistence.xml.
     */
    public static EntityManagerFactory getEntityManagerFactory() {
        if (emf == null) {
            // Crea la fábrica leyendo META-INF/persistence.xml
            emf = Persistence.createEntityManagerFactory("tiendaPU");
        }
        return emf;
    }

    /**
     * Cierra la fábrica al terminar la aplicación.
     * Se suele llamar desde App.main al salir del programa.
     */
    public static void close() {
        if (emf != null) {
            emf.close();
        }
    }
}
