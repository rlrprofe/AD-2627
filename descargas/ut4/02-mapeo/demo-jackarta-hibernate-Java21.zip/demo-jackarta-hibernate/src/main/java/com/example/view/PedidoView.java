package com.example.view;

import com.example.model.Pedido;
import com.example.model.Producto;

import java.util.List;

/**
 * VISTA del submenú de Pedidos.
 *
 * Punto didáctico clave:
 * - Pedido tiene una colección de productos (N:M) que suele ser LAZY.
 * - Si listamos pedidos con un DAO "simple" y cerramos el EntityManager,
 *   intentar acceder a p.getProductos() podría fallar.
 *
 * Por eso, en este proyecto se ofrecen dos listados:
 * - "simple": no imprime productos
 * - "con detalle": imprime productos (usando JOIN FETCH en DAO)
 */
public class PedidoView {

    public void mostrarMenu() {
        System.out.println("\n--- PEDIDOS ---");
        System.out.println("1. Crear pedido");
        System.out.println("2. Listar pedidos (simple)");
        System.out.println("3. Listar pedidos (con productos)");
        System.out.println("4. Eliminar pedido");
        System.out.println("0. Volver");
    }

    /**
     * Listado simple: imprime solo datos básicos del pedido.
     * No intenta recorrer productos para evitar problemas con LAZY.
     */
    public void mostrarListadoSimple(List<Pedido> pedidos) {
        System.out.println("\nListado de pedidos:");

        if (pedidos == null || pedidos.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }

        for (Pedido p : pedidos) {
            System.out.println(" - " + p);
        }
    }

    /**
     * Listado con detalle: imprime los productos del pedido.
     *
     * Requisito:
     * - El DAO debe haber cargado la colección con JOIN FETCH,
     *   si no, podría fallar al cerrar el EntityManager.
     */
    public void mostrarListadoConDetalle(List<Pedido> pedidos) {
        System.out.println("\nListado de pedidos (con productos):");

        if (pedidos == null || pedidos.isEmpty()) {
            System.out.println("(sin registros)");
            return;
        }

        for (Pedido p : pedidos) {
            // Mostramos el pedido
            System.out.println(" - " + p);

            // Mostramos el detalle de productos
            if (p.getProductos() == null || p.getProductos().isEmpty()) {
                System.out.println("     (sin productos)");
            } else {
                System.out.println("     Productos:");
                for (Producto prod : p.getProductos()) {
                    System.out.println("       * " + prod.getId()
                            + " - " + prod.getNombre()
                            + " (" + prod.getPrecio() + "€)");
                }
            }
        }
    }
}
