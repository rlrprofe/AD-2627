package com.example.dao;

import com.example.model.Cliente;
import com.example.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * DAO (Data Access Object) de Cliente.
 *
 * Responsabilidad:
 * - Ejecutar operaciones CRUD contra la base de datos usando JPA (EntityManager).
 *
 * Nota importante:
 * - El DAO NO pide datos por consola ni muestra menús.
 * - Solo hace persistencia.
 *
 * Patrón de uso:
 * 1) Crear EntityManager
 * 2) (Si hay escritura) abrir transacción (tx.begin)
 * 3) Operación (persist, find, merge, remove, query)
 * 4) commit o rollback
 * 5) cerrar EntityManager
 */
public class ClienteDao {

    /**
     * Inserta un cliente en la base de datos.
     *
     * JPA:
     * - persist(c) hace que el objeto pase a estado "managed"
     * - al hacer commit, se ejecuta el INSERT
     * - el id se asigna automáticamente (si @GeneratedValue)
     *
     * @return id generado para el cliente
     */
    public Integer insertar(Cliente c) {

        // 1) EntityManager (equivale conceptualmente a Session en Hibernate nativo)
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();

        // 2) Transacción (equivale conceptualmente a Transaction)
        EntityTransaction tx = em.getTransaction();

        try {
            // 3) Iniciamos transacción de escritura
            tx.begin();

            // 4) Insert: JPA usa persist()
            em.persist(c);

            // 5) Confirmamos cambios -> ejecuta INSERT en BD
            tx.commit();

            // 6) JPA asigna el id (por IDENTITY normalmente tras el commit)
            return c.getId();

        } catch (Exception e) {
            // Si algo falla, revertimos para mantener consistencia
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;

        } finally {
            // 7) Siempre cerramos el EntityManager
            em.close();
        }
    }

    /**
     * Busca un cliente por su id.
     *
     * JPA:
     * - find(Clase, id) devuelve la entidad o null si no existe.
     * - No requiere transacción para lectura en este tipo de práctica.
     */
    public Cliente buscarPorId(int id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }

    /**
     * Lista todos los clientes.
     *
     * JPA:
     * - Se usa JPQL, no SQL.
     * - "FROM Cliente" significa "desde la entidad Cliente", no desde la tabla.
     */
    public List<Cliente> listar() {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("FROM Cliente", Cliente.class).getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Actualiza un cliente.
     *
     * JPA:
     * - merge(c) actualiza la entidad en BD.
     * - Importante: merge devuelve la instancia "managed" (gestionada).
     *   En este ejemplo no necesitamos capturarla, pero conviene saberlo.
     */
    public void actualizar(Cliente c) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // Update en JPA: merge()
            em.merge(c);

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }

    /**
     * Elimina un cliente por id.
     *
     * JPA:
     * - primero se recupera con find()
     * - si existe, se elimina con remove()
     *
     * @return true si se eliminó, false si no existía
     */
    public boolean eliminarPorId(int id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Cliente c = em.find(Cliente.class, id);
            if (c == null) {
                // No hay nada que borrar; confirmamos y salimos
                tx.commit();
                return false;
            }

            em.remove(c);
            tx.commit();
            return true;

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;

        } finally {
            em.close();
        }
    }
}
