package com.example.service;

import com.example.dao.ClienteDao;
import com.example.model.Cliente;

import java.util.List;

/**
 * SERVICE (capa de servicio / lógica de aplicación)
 *
 * En MVC, el Service:
 * - Representa "casos de uso" (alta de cliente, eliminar, etc.)
 * - Centraliza reglas de negocio y validaciones (si las hay)
 * - Oculta detalles de persistencia (DAO) al Controller
 *
 * Ventajas didácticas/profesionales:
 * - El Controller queda más limpio (solo orquesta menú y entradas/salidas).
 * - Si mañana cambias la persistencia (DAO), el Controller no cambia.
 * - Puedes reutilizar la lógica desde otra interfaz (GUI, API REST, etc.)
 */
public class ClienteService {

    // El Service delega la persistencia en el DAO
    private final ClienteDao dao = new ClienteDao();

    /**
     * Caso de uso: alta de cliente.
     *
     * Aquí es buen sitio para meter reglas, por ejemplo:
     * - comprobar que el email tenga formato
     * - comprobar que no exista ya
     * En esta práctica, la validación básica del email la hace ConsoleUtil (en la Vista/entrada),
     * pero el lugar correcto para reglas "de negocio" sería el Service.
     *
     * @return id del cliente creado
     */
    public Integer alta(String nombre, String email) {

        // 1) Construimos el objeto del modelo (entidad)
        Cliente c = new Cliente(nombre, email);

        // 2) Delegamos en DAO el insert
        return dao.insertar(c);
    }

    /**
     * Caso de uso: listar clientes.
     */
    public List<Cliente> listar() {
        return dao.listar();
    }

    /**
     * Caso de uso: buscar cliente por id.
     */
    public Cliente buscar(int id) {
        return dao.buscarPorId(id);
    }

    /**
     * Caso de uso: eliminar cliente por id.
     * @return true si se eliminó, false si no existía
     */
    public boolean eliminar(int id) {
        return dao.eliminarPorId(id);
    }

    /**
     * Caso de uso: actualizar cliente.
     * En el ejemplo básico no lo estamos usando desde el menú,
     * pero se deja preparado para ampliaciones.
     */
    public void actualizar(Cliente c) {
        dao.actualizar(c);
    }
}
