-- 1) Crear base de datos
CREATE DATABASE IF NOT EXISTS tienda_orm_jackarta
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- 2) Crear usuario (si no existe)
CREATE USER IF NOT EXISTS 'tienda_user'@'localhost'
  IDENTIFIED BY 'CAMBIAR_PASSWORD';

-- 3) (Opcional) Forzar el método de autenticación para evitar
-- "Public Key Retrieval is not allowed" cuando useSSL=false
ALTER USER 'tienda_user'@'localhost'
  IDENTIFIED WITH mysql_native_password BY 'CAMBIAR_PASSWORD';

-- 4) Dar permisos al usuario sobre la BD
GRANT ALL PRIVILEGES ON tienda_orm_jackarta.* TO 'tienda_user'@'localhost';

-- 5) Aplicar cambios
FLUSH PRIVILEGES;

