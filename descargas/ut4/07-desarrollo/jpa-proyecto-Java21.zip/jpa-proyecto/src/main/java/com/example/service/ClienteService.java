package com.example.service;

import com.example.dao.ClienteDao;
import com.example.model.Cliente;

import java.util.List;

/**
 * Capa Service:
 * - Aplica reglas de negocio sencillas (validaciones)
 * - Orquesta operaciones DAO
 * - Devuelve resultados comprensibles a la UI
 */
public class ClienteService {

    private final ClienteDao clienteDao = new ClienteDao();

    public Cliente altaCliente(String nombre, String email) {
        // Regla simple: email único
        Cliente existente = clienteDao.findByEmail(email);
        if (existente != null) {
            return null; // la UI mostrará un mensaje de duplicado
        }
        Cliente c = new Cliente(nombre, email);
        return clienteDao.create(c);
    }

    public List<Cliente> listarClientes() {
        return clienteDao.findAllOrderedByNombre();
    }

    public Cliente buscarPorId(Long id) {
        return clienteDao.findById(id);
    }

    public Cliente modificarNombre(Long id, String nuevoNombre) {
        return clienteDao.updateNombreManaged(id, nuevoNombre);
    }

    /**
     * Demuestra el caso "Detached + merge":
     * 1) Cargamos un cliente con EM cerrado => DETACHED
     * 2) Modificamos el detached
     * 3) merge => se guarda
     */
    public Cliente demoDetachedYMerge(Long id, String nuevoNombre) {
        Cliente detached = clienteDao.findById(id); // se carga y se cierra EM => DETACHED
        if (detached == null) return null;

        detached.setNombre(nuevoNombre + " (detached)");
        Cliente managed = clienteDao.mergeDetached(detached);
        return managed;
    }

    public boolean borrarCliente(Long id) {
        return clienteDao.deleteById(id);
    }

    /**
     * Devuelve el cliente con pedidos cargados (JOIN FETCH).
     */
    public Cliente buscarClienteConPedidos(Long id) {
        return clienteDao.findByIdWithPedidos(id);
    }
}
