package com.example.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Entidad Cliente.
 *
 * Puntos didácticos:
 * - @Table con uniqueConstraints: el email no puede repetirse.
 * - Relación 1-N con Pedido:
 *   * mappedBy="cliente" => este lado NO es propietario; el propietario es Pedido (ManyToOne).
 *   * LAZY => la lista de pedidos se carga bajo demanda. Si el EM está cerrado => LazyInitializationException.
 *   * cascade=ALL => operaciones en Cliente se propagan a sus pedidos (persist/remove/merge...).
 *   * orphanRemoval=true => si quitamos un pedido de la lista, Hibernate lo borra de la BD.
 */
@Entity
@Table(name = "clientes",
        uniqueConstraints = @UniqueConstraint(name = "UK_clientes_email", columnNames = "email"))
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String nombre;

    @Column(nullable = false, length = 180)
    private String email;

    @OneToMany(mappedBy = "cliente",
            fetch = FetchType.LAZY,
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<Pedido> pedidos = new ArrayList<>();

    public Cliente() {}

    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    /** Método de conveniencia para mantener la relación consistente en ambos lados. */
    public void addPedido(Pedido p) {
        pedidos.add(p);
        p.setCliente(this); // lado propietario
    }

    /** Método de conveniencia para romper la relación y activar orphanRemoval (si aplica). */
    public void removePedido(Pedido p) {
        pedidos.remove(p);
        p.setCliente(null);
    }

    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public List<Pedido> getPedidos() { return pedidos; }

    @Override
    public String toString() {
        // IMPORTANTE: NO accedemos a pedidos.size() aquí para evitar LazyInitializationException.
        return "Cliente{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
