package com.example.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Utilidad para centralizar la creación del EntityManagerFactory (EMF).
 *
 * - El EMF es un objeto "pesado": se crea una sola vez y se reutiliza.
 * - Los EntityManager (EM) se crean a partir del EMF y son "ligeros": se abren/cierran por operación.
 */
public final class JPAUtil {

    private static final EntityManagerFactory EMF =
            Persistence.createEntityManagerFactory("demoPU");

    private JPAUtil() {}

    public static EntityManagerFactory getEmf() {
        return EMF;
    }

    public static void shutdown() {
        if (EMF != null && EMF.isOpen()) {
            EMF.close();
        }
    }
}
