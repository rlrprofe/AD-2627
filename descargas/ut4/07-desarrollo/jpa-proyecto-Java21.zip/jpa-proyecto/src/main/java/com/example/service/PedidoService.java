package com.example.service;

import com.example.dao.ClienteDao;
import com.example.dao.PedidoDao;
import com.example.model.Cliente;
import com.example.model.Pedido;

import java.util.List;

/**
 * Capa Service para pedidos.
 */
public class PedidoService {

    private final PedidoDao pedidoDao = new PedidoDao();
    private final ClienteDao clienteDao = new ClienteDao();

    public Pedido crearPedido(Long idCliente, String descripcion) {
        // Necesitamos el cliente (managed dentro de transacción si persistimos desde el cliente).
        // Aquí optamos por:
        // 1) cargar cliente en una operación sin tx (queda detached),
        // 2) y crear pedido asociándolo; pero para persistir correctamente:
        //    persistimos el pedido y Hibernate gestionará la FK.
        Cliente c = clienteDao.findById(idCliente);
        if (c == null) return null;

        Pedido p = new Pedido(descripcion);
        p.setCliente(c); // asignamos el lado propietario (ManyToOne)
        return pedidoDao.create(p);
    }

    public List<Pedido> listarPedidosDeCliente(Long idCliente) {
        return pedidoDao.findByClienteId(idCliente);
    }

    public boolean borrarPedido(Long idPedido) {
        return pedidoDao.deleteById(idPedido);
    }
}
