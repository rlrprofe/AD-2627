package com.example.dao;

import com.example.model.Pedido;

import java.util.List;

/**
 * DAO de Pedido.
 */
public class PedidoDao extends DaoSupport {

    public Pedido create(Pedido p) {
        return inTransaction(em -> {
            em.persist(p);
            return p;
        });
    }

    public Pedido findById(Long id) {
        return withoutTransaction(em -> em.find(Pedido.class, id));
    }

    public List<Pedido> findByClienteId(Long idCliente) {
        return withoutTransaction(em ->
                em.createQuery("SELECT p FROM Pedido p WHERE p.cliente.id = :id ORDER BY p.fechaCreacion DESC", Pedido.class)
                  .setParameter("id", idCliente)
                  .getResultList()
        );
    }

    public boolean deleteById(Long id) {
        return inTransaction(em -> {
            Pedido p = em.find(Pedido.class, id);
            if (p == null) return false;
            em.remove(p);
            return true;
        });
    }
}
