package com.example.ui;

import java.util.Scanner;

/**
 * Utilidad de lectura por consola con validaciones sencillas.
 * Evita repetir try/catch en todos los menús.
 */
public class Console {

    private static final Scanner SC = new Scanner(System.in);

    private Console() {}

    public static int leerEnteroEntre(String msg, int min, int max) {
        int v;
        boolean ok = false;
        do {
            System.out.print(msg);
            String line = SC.nextLine();
            try {
                v = Integer.parseInt(line.trim());
                if (v < min || v > max) {
                    System.out.println("Opción inválida. Debe estar entre " + min + " y " + max + ".");
                } else {
                    ok = true;
                    return v;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Introduce un número.");
            }
        } while (!ok);
        return min; // no se alcanza
    }

    public static long leerLong(String msg) {
        while (true) {
            System.out.print(msg);
            String line = SC.nextLine();
            try {
                return Long.parseLong(line.trim());
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Introduce un número entero largo.");
            }
        }
    }

    public static String leerTexto(String msg) {
        System.out.print(msg);
        return SC.nextLine().trim();
    }

    public static void cerrar() {
        SC.close();
    }
}
