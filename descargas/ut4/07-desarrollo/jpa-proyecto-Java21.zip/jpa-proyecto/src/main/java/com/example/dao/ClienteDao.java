package com.example.dao;

import com.example.model.Cliente;
import jakarta.persistence.TypedQuery;

import java.util.List;

/**
 * DAO de Cliente.
 * Contiene operaciones de persistencia (CRUD) a bajo nivel.
 *
 * Nota: en esta UT, el Service se encarga de la lógica (validaciones, mensajes),
 * y el DAO se centra en acceso a datos.
 */
public class ClienteDao extends DaoSupport {

    public Cliente create(Cliente c) {
        return inTransaction(em -> {
            em.persist(c); // Transient -> Managed (INSERT al commit)
            return c;
        });
    }

    public Cliente findById(Long id) {
        return withoutTransaction(em -> em.find(Cliente.class, id));
    }

    public Cliente findByEmail(String email) {
        return withoutTransaction(em -> {
            TypedQuery<Cliente> q = em.createQuery(
                    "SELECT c FROM Cliente c WHERE c.email = :email",
                    Cliente.class
            );
            q.setParameter("email", email);
            List<Cliente> list = q.getResultList();
            return list.isEmpty() ? null : list.get(0);
        });
    }

    public List<Cliente> findAllOrderedByNombre() {
        return withoutTransaction(em ->
                em.createQuery("SELECT c FROM Cliente c ORDER BY c.nombre", Cliente.class)
                  .getResultList()
        );
    }

    /**
     * UPDATE por dirty checking: cargamos el managed y modificamos.
     */
    public Cliente updateNombreManaged(Long id, String nuevoNombre) {
        return inTransaction(em -> {
            Cliente c = em.find(Cliente.class, id); // managed
            if (c != null) {
                c.setNombre(nuevoNombre); // dirty checking => UPDATE al commit
            }
            return c;
        });
    }

    /**
     * UPDATE por merge: útil cuando recibimos un objeto DETACHED desde la capa UI/service.
     */
    public Cliente mergeDetached(Cliente detached) {
        return inTransaction(em -> em.merge(detached)); // devuelve una instancia managed
    }

    public boolean deleteById(Long id) {
        return inTransaction(em -> {
            Cliente c = em.find(Cliente.class, id);
            if (c == null) return false;
            em.remove(c); // DELETE al commit (con cascade si procede)
            return true;
        });
    }

    /**
     * Recupera un cliente con sus pedidos ya cargados (evita LazyInitializationException).
     * Usa JOIN FETCH: trae Cliente y su colección en una sola consulta.
     */
    public Cliente findByIdWithPedidos(Long id) {
        return withoutTransaction(em -> {
            List<Cliente> list = em.createQuery(
                    "SELECT c FROM Cliente c LEFT JOIN FETCH c.pedidos WHERE c.id = :id",
                    Cliente.class
            ).setParameter("id", id).getResultList();
            return list.isEmpty() ? null : list.get(0);
        });
    }
}
