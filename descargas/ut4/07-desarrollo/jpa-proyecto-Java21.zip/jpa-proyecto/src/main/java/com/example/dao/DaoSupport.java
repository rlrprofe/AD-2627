package com.example.dao;

import com.example.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.function.Function;

/**
 * Clase base con plantilla para ejecutar código JPA con transacción.
 * Evita duplicar try/catch/rollback en todos los DAOs.
 */
public abstract class DaoSupport {

    protected <T> T inTransaction(Function<EntityManager, T> work) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            T result = work.apply(em);
            tx.commit();
            return result;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }

    protected <T> T withoutTransaction(Function<EntityManager, T> work) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            return work.apply(em);
        } finally {
            em.close();
        }
    }
}
