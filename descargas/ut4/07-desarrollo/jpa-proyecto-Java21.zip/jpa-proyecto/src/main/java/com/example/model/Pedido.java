package com.example.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Entidad Pedido.
 *
 * Puntos didácticos:
 * - ManyToOne es el lado PROPIETARIO en una relación 1-N (aquí vive la FK).
 * - fetch=LAZY: el cliente se carga bajo demanda (mejor rendimiento).
 * - @JoinColumn define:
 *   * name="cliente_id": columna FK en la tabla pedidos
 *   * nullable=false: un pedido SIEMPRE tiene cliente
 *   * foreignKey con nombre: facilita depuración de errores de integridad
 */
@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String descripcion;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion = LocalDateTime.now();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id",
            nullable = false,
            foreignKey = @ForeignKey(name = "FK_pedidos_cliente"))
    private Cliente cliente;

    public Pedido() {}

    public Pedido(String descripcion) {
        this.descripcion = descripcion;
        this.fechaCreacion = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    @Override
    public String toString() {
        // No accedemos a cliente.getNombre() para no forzar carga LAZY fuera de EM.
        return "Pedido{id=" + id + ", descripcion='" + descripcion + "', fechaCreacion=" + fechaCreacion + "}";
    }
}
