package com.example.app;

import com.example.model.Cliente;
import com.example.model.Pedido;
import com.example.service.ClienteService;
import com.example.service.PedidoService;
import com.example.ui.Console;
import com.example.util.JPAUtil;
import org.hibernate.LazyInitializationException;

import java.util.List;

/**
 * Aplicación de consola en capas (UI -> Service -> DAO -> JPA).
 *
 * Objetivo didáctico:
 * - Practicar operaciones CRUD con JPA/Hibernate.
 * - Ver estados de entidad:
 *   * Managed (dirty checking)
 *   * Detached (cambios fuera del EM NO se guardan)
 *   * merge(detached) (sí se guardan)
 * - Entender LazyInitializationException con relaciones LAZY.
 */
public class Main {

    private static final ClienteService clienteService = new ClienteService();
    private static final PedidoService pedidoService = new PedidoService();

    public static void main(String[] args) {
        try {
            menuPrincipal();
        } finally {
            // Cierre ordenado de recursos
            JPAUtil.shutdown();
            Console.cerrar();
        }
    }

    private static void menuPrincipal() {
        int op;
        do {
            System.out.println("\n=== APP CONSOLA ORM (JPA + Hibernate) ===");
            System.out.println("1. CRUD Clientes");
            System.out.println("2. CRUD Pedidos");
            System.out.println("3. Demos (Detached / Merge / Lazy)");
            System.out.println("0. Salir");
            op = Console.leerEnteroEntre("Opción: ", 0, 3);

            switch (op) {
                case 1 -> menuClientes();
                case 2 -> menuPedidos();
                case 3 -> menuDemos();
                case 0 -> System.out.println("Fin.");
            }
        } while (op != 0);
    }

    private static void menuClientes() {
        int op;
        do {
            System.out.println("\n--- CLIENTES ---");
            System.out.println("1. Alta");
            System.out.println("2. Listar");
            System.out.println("3. Buscar por ID");
            System.out.println("4. Modificar nombre (managed + dirty checking)");
            System.out.println("5. Borrar");
            System.out.println("0. Volver");
            op = Console.leerEnteroEntre("Opción: ", 0, 5);

            switch (op) {
                case 1 -> altaCliente();
                case 2 -> listarClientes();
                case 3 -> buscarCliente();
                case 4 -> modificarNombreCliente();
                case 5 -> borrarCliente();
                case 0 -> {}
            }
        } while (op != 0);
    }

    private static void altaCliente() {
        String nombre = Console.leerTexto("Nombre: ");
        String email = Console.leerTexto("Email: ");

        Cliente creado = clienteService.altaCliente(nombre, email);
        if (creado == null) {
            System.out.println("No se puede crear: ya existe un cliente con ese email (UNIQUE).");
        } else {
            System.out.println("Creado: " + creado);
        }
    }

    private static void listarClientes() {
        List<Cliente> list = clienteService.listarClientes();
        if (list.isEmpty()) {
            System.out.println("No hay clientes.");
        } else {
            list.forEach(System.out::println);
        }
    }

    private static void buscarCliente() {
        long id = Console.leerLong("ID cliente: ");
        Cliente c = clienteService.buscarPorId(id);
        System.out.println(c == null ? "No existe." : c.toString());
    }

    private static void modificarNombreCliente() {
        long id = Console.leerLong("ID cliente: ");
        String nuevo = Console.leerTexto("Nuevo nombre: ");
        Cliente c = clienteService.modificarNombre(id, nuevo);
        System.out.println(c == null ? "No existe." : "Actualizado (dirty checking): " + c);
    }

    private static void borrarCliente() {
        long id = Console.leerLong("ID cliente a borrar: ");
        boolean ok = clienteService.borrarCliente(id);
        System.out.println(ok ? "Borrado." : "No existe.");
    }

    private static void menuPedidos() {
        int op;
        do {
            System.out.println("\n--- PEDIDOS ---");
            System.out.println("1. Crear pedido para cliente");
            System.out.println("2. Listar pedidos de un cliente");
            System.out.println("3. Borrar pedido por ID");
            System.out.println("0. Volver");
            op = Console.leerEnteroEntre("Opción: ", 0, 3);

            switch (op) {
                case 1 -> crearPedido();
                case 2 -> listarPedidosDeCliente();
                case 3 -> borrarPedido();
                case 0 -> {}
            }
        } while (op != 0);
    }

    private static void crearPedido() {
        long idCliente = Console.leerLong("ID cliente: ");
        String desc = Console.leerTexto("Descripción: ");
        Pedido p = pedidoService.crearPedido(idCliente, desc);
        System.out.println(p == null ? "No existe el cliente." : "Creado: " + p);
    }

    private static void listarPedidosDeCliente() {
        long idCliente = Console.leerLong("ID cliente: ");
        List<Pedido> pedidos = pedidoService.listarPedidosDeCliente(idCliente);
        if (pedidos.isEmpty()) {
            System.out.println("No hay pedidos para ese cliente.");
        } else {
            pedidos.forEach(System.out::println);
        }
    }

    private static void borrarPedido() {
        long id = Console.leerLong("ID pedido: ");
        boolean ok = pedidoService.borrarPedido(id);
        System.out.println(ok ? "Pedido borrado." : "No existe.");
    }

    private static void menuDemos() {
        int op;
        do {
            System.out.println("\n--- DEMOS (Estados / Lazy) ---");
            System.out.println("1. Detached sin merge (cambio NO se guarda)");
            System.out.println("2. Detached + merge (cambio SÍ se guarda)");
            System.out.println("3. Provocar LazyInitializationException");
            System.out.println("4. Evitar LazyInitializationException con JOIN FETCH");
            System.out.println("0. Volver");
            op = Console.leerEnteroEntre("Opción: ", 0, 4);

            switch (op) {
                case 1 -> demoDetachedSinMerge();
                case 2 -> demoDetachedConMerge();
                case 3 -> demoLazyException();
                case 4 -> demoJoinFetch();
                case 0 -> {}
            }
        } while (op != 0);
    }

    /**
     * DEMO 1: Detached sin merge
     * - Cargamos Cliente con un EM que se cierra (DAO -> withoutTransaction)
     * - Modificamos el objeto (DETACHED) en memoria
     * - Volvemos a consultar en BD: el cambio NO se guardó
     */
    private static void demoDetachedSinMerge() {
        long id = Console.leerLong("ID cliente: ");
        Cliente detached = clienteService.buscarPorId(id);
        if (detached == null) {
            System.out.println("No existe.");
            return;
        }

        System.out.println("Cargado (DETACHED): " + detached);
        detached.setNombre(detached.getNombre() + " (cambio fuera EM)");

        // Volvemos a consultar desde BD para comprobar que NO se guardó
        Cliente enBd = clienteService.buscarPorId(id);
        System.out.println("Tras cambio detached SIN merge, en BD sigue: " + enBd);
    }

    /**
     * DEMO 2: Detached + merge
     * - Igual que antes, pero esta vez llamamos a merge desde el service.
     */
    private static void demoDetachedConMerge() {
        long id = Console.leerLong("ID cliente: ");
        String nuevo = Console.leerTexto("Nuevo nombre base: ");
        Cliente managed = clienteService.demoDetachedYMerge(id, nuevo);
        System.out.println(managed == null ? "No existe." : "Tras merge, en BD: " + clienteService.buscarPorId(id));
    }

    /**
     * DEMO 3: LazyInitializationException
     * - Cargamos Cliente (DETACHED) y luego intentamos acceder a la colección LAZY con EM cerrado.
     */
    private static void demoLazyException() {
        long id = Console.leerLong("ID cliente: ");
        Cliente c = clienteService.buscarPorId(id); // DETACHED
        if (c == null) {
            System.out.println("No existe.");
            return;
        }

        System.out.println("Cliente DETACHED: " + c);
        System.out.println("Intentamos acceder a c.getPedidos().size() con EM cerrado...");

        try {
            int n = c.getPedidos().size(); // aquí debería saltar LazyInitializationException
            System.out.println("Pedidos: " + n);
        } catch (LazyInitializationException ex) {
            System.out.println("EXCEPCIÓN esperada: LazyInitializationException");
            System.out.println("Motivo: relación LAZY + EntityManager cerrado.");
        }
    }

    /**
     * DEMO 4: JOIN FETCH para evitar LazyInitializationException
     * - Recuperamos el Cliente con su colección ya inicializada en la consulta (JOIN FETCH).
     * - Así, aunque el EM se cierre, la colección ya está en memoria.
     */
    private static void demoJoinFetch() {
        long id = Console.leerLong("ID cliente: ");
        Cliente c = clienteService.buscarClienteConPedidos(id); // JOIN FETCH
        if (c == null) {
            System.out.println("No existe.");
            return;
        }

        System.out.println("Cliente (con pedidos cargados): " + c);
        System.out.println("Pedidos cargados: " + c.getPedidos().size());
        c.getPedidos().forEach(System.out::println);
    }
}
