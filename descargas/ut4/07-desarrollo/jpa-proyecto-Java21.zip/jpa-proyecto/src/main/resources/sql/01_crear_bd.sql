-- =========================================================
-- Script de creación de BD y tablas para la app por consola (JPA)
-- BD: demo_consola_orm
-- Usuario: root  Password: CAMBIAR_PASSWORD
-- =========================================================

DROP DATABASE IF EXISTS demo_consola_orm;
CREATE DATABASE demo_consola_orm CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE demo_consola_orm;

CREATE TABLE clientes (
  id BIGINT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT UK_clientes_email UNIQUE (email)
) ENGINE=InnoDB;

CREATE TABLE pedidos (
  id BIGINT NOT NULL AUTO_INCREMENT,
  descripcion VARCHAR(200) NOT NULL,
  fecha_creacion DATETIME NOT NULL,
  cliente_id BIGINT NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT FK_pedidos_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Datos 
INSERT INTO clientes(nombre, email) VALUES ('Ana', 'ana@demo.es'), ('Luis', 'luis@demo.es');

INSERT INTO pedidos(descripcion, fecha_creacion, cliente_id) VALUES
('Pedido inicial 1', NOW(), 1),
('Pedido inicial 2', NOW(), 1),
('Pedido inicial 3', NOW(), 2);
