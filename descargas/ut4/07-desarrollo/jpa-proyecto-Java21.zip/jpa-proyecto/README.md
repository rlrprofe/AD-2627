# App por consola (JPA + Hibernate) 

Proyecto didáctico para Acceso a Datos.  
Incluye **CRUD completo por consola** + demos de **estados de entidad** y **LazyInitializationException**.

## Tecnologías
- Java 17
- Maven
- JPA (Jakarta Persistence) + Hibernate ORM
- MySQL (usuario `root`, contraseña `CAMBIAR_PASSWORD`)

## Estructura en capas
- `ui` : lectura por consola y menús (sin lógica de BD)
- `service` : lógica de aplicación y reglas simples
- `dao` : acceso a datos (EntityManager, transacciones, JPQL)
- `model` : entidades JPA (`Cliente`, `Pedido`)
- `util` : utilidades (JPAUtil)

## 1) Crear la base de datos
Ejecuta el script:

`src/main/resources/sql/01_crear_bd.sql`

Crea:
- BD `demo_consola_orm`
- tablas `clientes` y `pedidos`
- datos semilla opcionales

> Nota: en `persistence.xml` se usa `hibernate.hbm2ddl.auto=validate`, por lo que si no ejecutas el script, el proyecto fallará al arrancar.

##  2) Ejecutar la app
Desde la carpeta del proyecto:

```bash
mvn -q clean compile exec:java
```

## 3) Qué se practica (lo aprendido en el tema)
### CRUD
- Alta, listado, búsqueda, modificación y borrado de Clientes.
- Alta, listado y borrado de Pedidos.

### Estados de entidad y ORM
Menú **Demos**:
- Detached sin merge: el cambio NO se guarda
- Detached + merge: el cambio SÍ se guarda
- LazyInitializationException (LAZY + EntityManager cerrado)
- Solución con JOIN FETCH

## 4) Logging
Se incluye `simplelogger.properties` para que solo aparezcan errores por consola.
