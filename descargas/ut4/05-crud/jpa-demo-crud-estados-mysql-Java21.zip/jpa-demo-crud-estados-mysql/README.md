# Demo CRUD + Estados de entidad (JPA/Hibernate) con MySQL

## Objetivo didáctico
Esta demo muestra por consola:
- CREATE (`persist`)
- READ (`find`)
- UPDATE (dirty checking)
- DETACHED sin merge (no se guarda)
- `merge(detached)` (sí se guarda)
- `LazyInitializationException` en relación LAZY con EM cerrado
- DELETE (`remove`) con cascada en 1-N

## Requisitos
- Java 17+
- Maven
- MySQL en localhost:3306
- Usuario: root
- Password: CAMBIAR_PASSWORD

## Preparación BD
Ejecuta: `src/main/resources/sql/01_crear_bd.sql`

## Ejecutar
```bash
mvn -q clean compile exec:java
```

## Notas
- Si ejecutas muchas veces y te da duplicado de email, cambia el email en la demo o vacía la tabla.
