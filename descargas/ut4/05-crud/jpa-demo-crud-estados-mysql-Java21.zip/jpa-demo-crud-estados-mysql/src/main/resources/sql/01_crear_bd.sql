-- Script mínimo: crea la BD (las tablas las crea Hibernate con hbm2ddl.auto=update)
DROP DATABASE IF EXISTS demo_jpa_crud_estados;
CREATE DATABASE demo_jpa_crud_estados CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
-- Si ejecutas muchas veces y te da duplicado de email, cambia el email en la demo o vacía la tabla.