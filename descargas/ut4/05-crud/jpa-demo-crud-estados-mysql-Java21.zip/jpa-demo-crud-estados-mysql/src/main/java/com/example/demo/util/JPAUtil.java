package com.example.demo.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Clase utilitaria para centralizar la creación de EntityManagerFactory (EMF).
 *
 * Regla: la EMF es "pesada" y debe crearse UNA vez.
 * En consola (demo), la almacenamos en un atributo estático.
 */
public final class JPAUtil {

    private static final EntityManagerFactory EMF =
            Persistence.createEntityManagerFactory("demoPU");

    private JPAUtil() { }

    public static EntityManagerFactory getEmf() {
        return EMF;
    }

    public static void shutdown() {
        if (EMF != null && EMF.isOpen()) {
            EMF.close();
        }
    }
}
