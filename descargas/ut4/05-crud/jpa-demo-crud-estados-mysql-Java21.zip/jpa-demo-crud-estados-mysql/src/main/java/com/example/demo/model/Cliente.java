package com.example.demo.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Entidad Cliente.
 *
 * Relación 1-N con Pedido:
 * - Un Cliente puede tener muchos Pedidos.
 * - Cada Pedido pertenece a un único Cliente.
 *
 * En JPA, el lado PROPIETARIO de la relación 1-N es el lado N (Pedido),
 * porque es donde existe la FK (cliente_id). Por eso aquí usamos mappedBy.
 */
@Entity
@Table(name = "clientes",
       uniqueConstraints = {
           @UniqueConstraint(name = "UK_clientes_email", columnNames = "email")
       })
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String nombre;

    @Column(nullable = false, length = 120)
    private String email;

    /**
     * Colección de pedidos del cliente.
     *
     * fetch = LAZY:
     *  - Los pedidos NO se cargan automáticamente al cargar el Cliente.
     *  - Se cargan cuando accedemos a c.getPedidos() (si el EntityManager sigue abierto).
     *  - Si el EntityManager está cerrado -> LazyInitializationException (escenario de la demo).
     *
     * cascade = CascadeType.ALL:
     *  - Propaga operaciones del Cliente a sus Pedidos.
     *  - PERSIST: al guardar Cliente, se guardan los pedidos.
     *  - REMOVE: al borrar Cliente, se borran sus pedidos.
     *
     * orphanRemoval = true:
     *  - Si quitamos un Pedido de la lista (removePedido), se elimina de BD.
     */
    @OneToMany(mappedBy = "cliente",
               fetch = FetchType.LAZY,
               cascade = CascadeType.ALL,
               orphanRemoval = true)
    private List<Pedido> pedidos = new ArrayList<>();

    public Cliente() { }

    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    // Métodos de ayuda para mantener coherencia en ambos lados
    public void addPedido(Pedido p) {
        pedidos.add(p);
        p.setCliente(this); // el lado propietario es Pedido
    }

    public void removePedido(Pedido p) {
        pedidos.remove(p);
        p.setCliente(null);
    }

    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public List<Pedido> getPedidos() { return pedidos; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Cliente{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
