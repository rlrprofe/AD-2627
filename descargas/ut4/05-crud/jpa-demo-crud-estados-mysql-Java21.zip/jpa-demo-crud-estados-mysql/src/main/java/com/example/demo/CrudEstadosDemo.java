package com.example.demo;

import com.example.demo.dao.ClienteDao;
import com.example.demo.model.Cliente;
import com.example.demo.util.JPAUtil;
import org.hibernate.LazyInitializationException;

import java.util.List;

/**
 * DEMO: CRUD + Estados de entidad + LazyInitializationException.
 *
 * Ejecuta varios escenarios en orden para que el alumnado vea:
 * - CREATE (persist)
 * - READ (find)
 * - UPDATE (dirty checking)
 * - DETACHED sin merge (no se guarda)
 * - merge(detached) (sí se guarda)
 * - LazyInitializationException por relación LAZY con EntityManager cerrado
 * - DELETE (remove) con cascade/orphanRemoval
 */
public class CrudEstadosDemo {

    public static void main(String[] args) {
        ClienteDao dao = new ClienteDao();

        try {
            System.out.println("=== DEMO CRUD + ESTADOS (JPA/Hibernate, MySQL) ===");

            // ESCENARIO 1: CREATE
            System.out.println("\n=== ESCENARIO 1: CREATE (persist) Cliente + 2 Pedidos ===");
            Cliente c1 = dao.crearClienteConPedidos(
                    "Ana",
                    "ana_crud@demo.es",
                    List.of("Pedido A", "Pedido B")
            );
            System.out.println("Creado: " + c1 + " (nota: ahora está DETACHED porque el EM se cerró)");

            Long idAna = c1.getId();

            // ESCENARIO 2: READ
            System.out.println("\n=== ESCENARIO 2: READ (find por id) ===");
            Cliente c2 = dao.buscarPorId(idAna);
            System.out.println("Leído: " + c2 + " (nota: ya está DETACHED porque buscarPorId cierra el EM)");

            // ESCENARIO 3: UPDATE con dirty checking
            System.out.println("\n=== ESCENARIO 3: UPDATE (dirty checking) ===");
            Cliente c3 = dao.actualizarNombreDirtyChecking(idAna, "Ana Modificada");
            System.out.println("Tras update (managed dentro del tx): " + c3);

            // ESCENARIO 4: DETACHED sin merge -> NO se guarda
            System.out.println("\n=== ESCENARIO 4: DETACHED sin merge (cambios NO persisten) ===");
            Cliente detached = dao.buscarPorId(idAna); // devuelve detached
            detached.setNombre("Ana Cambiada Fuera del EM");
            System.out.println("Objeto modificado en memoria (detached): " + detached);

            Cliente comprobacion = dao.buscarPorId(idAna);
            System.out.println("Valor en BD (sin merge): " + comprobacion);
            System.out.println("Observa que el nombre NO cambió en BD.");

            // ESCENARIO 5: merge(detached) -> SÍ se guarda
            System.out.println("\n=== ESCENARIO 5: merge(detached) (cambios SÍ persisten) ===");
            detached.setNombre("Ana Actualizada Con MERGE");
            Cliente managedAfterMerge = dao.mergeCliente(detached);
            System.out.println("Objeto devuelto por merge (managed durante el tx): " + managedAfterMerge);

            Cliente comprobacion2 = dao.buscarPorId(idAna);
            System.out.println("Valor en BD tras merge: " + comprobacion2);

            // ESCENARIO 6: LazyInitializationException
            System.out.println("\n=== ESCENARIO 6: LazyInitializationException (LAZY con EM cerrado) ===");
            Cliente cLazy = dao.buscarPorId(idAna); // detached
            System.out.println("Cliente leído (detached): " + cLazy);
            System.out.println("EM cerrado. Intentamos acceder a cLazy.getPedidos().size()...");

            try {
                int n = cLazy.getPedidos().size();
                System.out.println("Pedidos: " + n + " (si ves esto, no se reprodujo el caso LAZY)");
            } catch (LazyInitializationException ex) {
                System.out.println("EXCEPCIÓN esperada: LazyInitializationException");
                System.out.println("Motivo: la colección 'pedidos' es LAZY y requiere un EntityManager abierto.");
            }

            // ESCENARIO 7: Forma correcta de acceder a LAZY
            System.out.println("\n=== ESCENARIO 7: Acceso correcto a LAZY (dentro de EM abierto) ===");
            int pedidos = dao.contarPedidosDentroDeEm(idAna);
            System.out.println("Número de pedidos (accediendo dentro del EM): " + pedidos);

            // ESCENARIO 8: DELETE
            System.out.println("\n=== ESCENARIO 8: DELETE (remove) Cliente (cascade ALL borra pedidos) ===");
            dao.eliminarCliente(idAna);
            Cliente trasBorrado = dao.buscarPorId(idAna);
            System.out.println("Tras borrar, find devuelve: " + trasBorrado);

            System.out.println("\n=== FIN DEMO ===");
        } finally {
            JPAUtil.shutdown();
        }
    }
}
