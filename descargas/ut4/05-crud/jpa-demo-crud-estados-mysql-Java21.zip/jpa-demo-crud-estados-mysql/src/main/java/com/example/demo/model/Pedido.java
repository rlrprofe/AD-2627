package com.example.demo.model;

import jakarta.persistence.*;

/**
 * Entidad Pedido.
 *
 * Lado PROPIETARIO de la relación 1-N:
 * - Aquí se define la FK mediante @JoinColumn(name="cliente_id").
 */
@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String descripcion;

    /**
     * Muchos pedidos pertenecen a un cliente.
     * nullable=false: un pedido no puede existir sin cliente en esta demo.
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "cliente_id", nullable = false,
            foreignKey = @ForeignKey(name = "FK_pedidos_cliente"))
    private Cliente cliente;

    public Pedido() { }

    public Pedido(String descripcion) {
        this.descripcion = descripcion;
    }

    public Long getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public Cliente getCliente() { return cliente; }

    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    @Override
    public String toString() {
        return "Pedido{id=" + id + ", descripcion='" + descripcion + "'}";
    }
}
