package com.example.demo.dao;

import com.example.demo.model.Cliente;
import com.example.demo.model.Pedido;
import com.example.demo.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * DAO sencillo para encapsular operaciones CRUD.
 *
 * Nota didáctica:
 * - En proyectos reales separaríamos servicios/DAO y controlaríamos mejor los errores.
 * - En esta demo el objetivo es ver CRUD + estados (managed/detached/merge) de forma clara.
 */
public class ClienteDao {

    public Cliente crearClienteConPedidos(String nombre, String email, List<String> descripcionesPedidos) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Cliente c = new Cliente(nombre, email);
            for (String d : descripcionesPedidos) {
                Pedido p = new Pedido(d);
                c.addPedido(p);
            }

            em.persist(c); // CREATE: Transient -> Managed
            tx.commit();

            return c; // al cerrar EM, este objeto queda DETACHED
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public Cliente buscarPorId(Long id) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close(); // la entidad pasa a DETACHED
        }
    }

    public Cliente actualizarNombreDirtyChecking(Long id, String nuevoNombre) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Cliente c = em.find(Cliente.class, id); // Managed
            if (c != null) {
                c.setNombre(nuevoNombre); // UPDATE por dirty-checking
            }

            tx.commit();
            return c;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public Cliente mergeCliente(Cliente clienteDetached) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // UPDATE con entidad DETACHED:
            // merge devuelve un objeto MANAGED (puede ser distinto al original)
            Cliente managed = em.merge(clienteDetached);

            tx.commit();
            return managed;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public void eliminarCliente(Long id) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            Cliente c = em.find(Cliente.class, id); // Managed
            if (c != null) {
                em.remove(c); // DELETE (cascade ALL borra pedidos)
            }

            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public int contarPedidosDentroDeEm(Long clienteId) {
        EntityManager em = JPAUtil.getEmf().createEntityManager();
        try {
            Cliente c = em.find(Cliente.class, clienteId); // Managed
            if (c == null) return 0;

            // LAZY: funciona aquí porque EM está abierto
            return c.getPedidos().size();
        } finally {
            em.close();
        }
    }
}
